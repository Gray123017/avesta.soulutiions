# Avesta — upload and start

This package is **already built**. Nothing compiles on the server, so there is
no build step to fail and nothing to install.

## Put it up

1. In hPanel, open **Websites → Node.js apps → Create application**
   (Business or any Cloud plan; not Premium).
2. Upload this zip as the application, or drop its contents into the
   application folder with File Manager and extract.
3. Set:

   | Setting | Value |
   |---|---|
   | Node version | 20 or newer |
   | Install command | `npm install` (there is nothing to install; it finishes at once) |
   | Build command | *leave empty* |
   | Start command | `npm start` |
   | Port | as provided — the server reads `PORT` |

## Add the settings

Copy the names from `.env.example` into **Environment variables** in the
application settings. Never upload a `.env` file.

The five Supabase values are required. Everything else is optional: without
them the site runs, and only that feature stays quiet.

| Variable | Without it |
|---|---|
| `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` | nobody can sign in |
| `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY` | admin pages and the assistant's records fail |
| `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` | the AI chat says it is not configured; the 43 written topics still answer |
| `SEARCH_API_KEY` | "Look it up online" is unavailable |
| `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | emails are skipped and logged |
| `CRON_SECRET` | scheduled jobs are refused |

`SUPABASE_SERVICE_ROLE_KEY` bypasses all row security. It belongs only in the
server settings — never in the browser, a repository, or a support ticket.

## Before it serves customers

Run every file in `drizzle/migrations` (in the source package) against your
Supabase project, in order, 0000 to 0005.

## Check it worked

- `https://avesta.solutions/healthz` — says which settings it found. No values,
  only yes or no. This is also the address for an uptime monitor.
- The home page over `https://` with no warning.
- `/it-help` answers a question — that works with no keys at all.
- Sign in and out. Failure here means the Supabase values are wrong.
- On Android Chrome, **Install app** appears.

## Updating later

Rebuild from the source package (`npm install && npm run build`), then replace
the `.output` folder here and restart the application.
