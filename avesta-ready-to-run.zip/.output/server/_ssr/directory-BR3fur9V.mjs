import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { D as Clock, _ as Mail, a as Star, c as ShieldCheck, d as Phone, g as MapPin, m as MessageCircle, n as Wrench, r as Wallet, t as X, w as Globe, x as Landmark } from "../_libs/lucide-react.mjs";
import { n as AppHeader } from "./AppHeader-DG15xa67.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/directory-BR3fur9V.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GOOGLE_REVIEW_URL = "https://www.google.com/search?q=Avesta+Enterprises+Ndola#lrd=reviews";
var WA = "260769974200";
/** Reviews live on Google — we never show made-up reviews here. */
function GoogleReviews() {
	const [stars, setStars] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-labelledby": "directory-reviews",
		className: "my-6 rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: "directory-reviews",
				className: "font-display text-lg font-semibold",
				children: "Rate Avesta Enterprises on Google"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Borrowed from us or had your tech fixed? Pick a rating, then leave your review on our Google listing — it helps other people in Ndola find us."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-1",
				role: "radiogroup",
				"aria-label": "Your rating",
				children: [
					1,
					2,
					3,
					4,
					5
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "radio",
					"aria-checked": stars === n,
					"aria-label": `${n} star${n > 1 ? "s" : ""}`,
					onClick: () => setStars(n),
					className: "rounded p-1 transition-transform hover:scale-110",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-7 ${n <= stars ? "fill-primary text-primary" : "text-foreground/40"}` })
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "copper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: GOOGLE_REVIEW_URL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: stars ? `Post my ${stars}-star review on Google` : "Write a review on Google"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "glass",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: GOOGLE_REVIEW_URL,
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Read our Google reviews"
					})
				})]
			})
		]
	});
}
function WhatsAppChat() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	const quick = [
		"I'd like to apply for a loan",
		"What's the status of my loan?",
		"I want to talk about repaying my loan"
	];
	const send = (msg) => window.open(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`, "_blank", "noopener,noreferrer");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed bottom-4 right-4 z-50",
		children: [open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "page-enter mb-3 w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-foreground/10 bg-card shadow-soft",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between bg-primary px-4 py-3 text-primary-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Avesta on WhatsApp"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs opacity-80",
					children: "0971 013 108 · a real person replies"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Close chat",
					onClick: () => setOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl bg-foreground/10 p-3",
						children: "Hello! Ask us about your loan, or apply online first so we can see your details."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: quick.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => send(q),
							className: "rounded-full border border-foreground/20 px-3 py-1 text-xs hover:bg-foreground/10",
							children: q
						}, q))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							if (text.trim()) {
								send(text.trim());
								setText("");
							}
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": "Your message",
							value: text,
							onChange: (e) => setText(e.target.value),
							placeholder: "Type your message…",
							className: "h-9 flex-1 rounded-md border border-input bg-transparent px-3",
							maxLength: 500
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "copper",
							type: "submit",
							children: "Send"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/apply",
						className: "block text-center text-xs underline",
						children: "Apply for a loan online"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "copper",
			className: "ml-auto flex rounded-full shadow-soft",
			onClick: () => setOpen((o) => !o),
			"aria-expanded": open,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" }), " Chat on WhatsApp"]
		})]
	});
}
var GOOGLE_MAPS_URL = "https://www.google.com/maps/search/?api=1&query=Avesta+Enterprises%2C+House+No.+3%2C+Thom+Avenue%2C+Kansenshi%2C+Ndola%2C+Zambia";
var GOOGLE_BUSINESS_URL = "https://www.google.com/search?q=Avesta+Enterprises+Ndola";
var categories = [
	"Financial services — short-term loans",
	"IT consulting & support",
	"Computer repairs & networking",
	"CCTV & security systems",
	"Websites, databases & training"
];
var serviceAreas = [
	"Ndola",
	"Kitwe",
	"Lusaka",
	"Copperbelt Province",
	"All of Zambia — remote support"
];
var registrations = [
	{
		label: "Money Lenders Licence",
		status: "In progress"
	},
	{
		label: "PACRA registration",
		status: "In progress"
	},
	{
		label: "TPIN (ZRA)",
		status: "In progress"
	}
];
function Row({ icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-foreground/10 text-primary",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pt-1 text-sm leading-6 text-foreground/85",
			children
		})]
	});
}
function DirectoryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-enter mx-auto max-w-4xl px-5 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Breadcrumb",
					className: "mb-4 text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "flex flex-wrap items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "underline hover:text-foreground",
								children: "Home"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								"aria-hidden": "true",
								children: "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								"aria-current": "page",
								children: "Business directory"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-2 font-display text-4xl font-semibold leading-tight",
					children: "Avesta Enterprises — Ndola"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 text-sm text-muted-foreground",
					children: "Zambian business directory · Loans & IT services in Ndola, Copperbelt"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mb-6 rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold uppercase tracking-[0.12em] text-primary",
								children: "Verified listing"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-accent/15 px-3 py-1 text-xs font-semibold uppercase tracking-[0.12em] text-accent",
								children: "Ndola · Copperbelt"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 leading-7 text-foreground/85",
							children: "Avesta Enterprises is a Zambian company offering two connected services from one office in Kansenshi, Ndola: fair short-term lending with clear, stated terms, and hands-on IT support — repairs, networks, CCTV, cybersecurity, websites and training — for homes and businesses across Zambia."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-labelledby": "directory-categories",
							className: "mt-7 grid gap-6 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "directory-categories",
								className: "font-display text-sm font-semibold uppercase tracking-[0.12em] text-primary",
								children: "Categories"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-2 text-sm text-foreground/85",
								children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 size-1.5 shrink-0 rounded-full bg-accent",
										"aria-hidden": "true"
									}), category]
								}, category))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-sm font-semibold uppercase tracking-[0.12em] text-primary",
								children: "Areas served"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-2 text-sm text-foreground/85",
								children: serviceAreas.map((area) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 size-1.5 shrink-0 rounded-full bg-accent",
										"aria-hidden": "true"
									}), area]
								}, area))
							})] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "directory-contact",
						className: "rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								id: "directory-contact",
								className: "mb-4 flex items-center gap-2 font-display text-lg font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-4 text-primary",
									"aria-hidden": "true"
								}), " Contact details"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "underline hover:text-foreground",
												href: "tel:+260971013108",
												children: "0971 013 108"
											}),
											" · ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "underline hover:text-foreground",
												href: "tel:+260769974200",
												children: "0769 974 200"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "underline hover:text-foreground",
											href: "https://wa.me/260769974200",
											target: "_blank",
											rel: "noopener noreferrer",
											children: "WhatsApp: 0971 013 108"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "underline hover:text-foreground",
												href: "mailto:info@avasta.solutions",
												children: "info@avasta.solutions"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "underline hover:text-foreground",
												href: "mailto:avestaenterprises4@gmail.com",
												children: "avestaenterprises4@gmail.com"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "underline hover:text-foreground",
											href: "https://avesta.solutions/",
											children: "avesta.solutions"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: [
											"House No. 3, Thom Avenue,",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											"Kansenshi, Ndola, Zambia",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "text-primary underline",
												href: GOOGLE_MAPS_URL,
												target: "_blank",
												rel: "noopener noreferrer",
												children: "Find us on Google Maps"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										children: "Monday – Saturday, 08:00 – 17:00"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 rounded-xl border border-foreground/10 bg-foreground/5 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: "Avesta Enterprises on Google"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: "See our Ndola location, opening hours and reviews on Google."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex flex-wrap gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "copper",
											size: "sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: GOOGLE_BUSINESS_URL,
												target: "_blank",
												rel: "noopener noreferrer",
												children: "View our Google listing"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "glass",
											size: "sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: GOOGLE_MAPS_URL,
												target: "_blank",
												rel: "noopener noreferrer",
												children: "Open in Maps"
											})
										})]
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-labelledby": "directory-services",
							className: "rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "directory-services",
								className: "mb-4 font-display text-lg font-semibold",
								children: "Services offered"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Short-term loans" }),
										" — 1 to 4 weeks, 15–30% flat interest, terms stated before you sign.",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/apply",
											className: "text-primary underline",
											children: "Apply for a loan"
										}),
										" · ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/tools",
											className: "text-primary underline",
											children: "Loan calculator"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "IT services" }),
										" — repairs, networking, CCTV, cybersecurity, websites and databases.",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/it-help",
											className: "text-primary underline",
											children: "Get instant IT help"
										})
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							"aria-labelledby": "directory-registration",
							className: "rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									id: "directory-registration",
									className: "mb-4 flex items-center gap-2 font-display text-lg font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
										className: "size-4 text-primary",
										"aria-hidden": "true"
									}), " Registration"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2 text-sm text-foreground/85",
									children: registrations.map((registration) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 border-b border-foreground/5 pb-2 last:border-b-0 last:pb-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: registration.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-foreground/10 px-2.5 py-0.5 text-xs text-muted-foreground",
											children: registration.status
										})]
									}, registration.label))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 flex items-start gap-2 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
										className: "mt-0.5 size-3.5 shrink-0 text-accent",
										"aria-hidden": "true"
									}), "Official licence numbers are being finalised and will be published here once issued."]
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "account-strip my-6 grid gap-5 rounded-xl px-5 py-5 sm:grid-cols-[1fr_auto] sm:items-center sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base font-semibold",
						children: "Need a loan or IT help today?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Apply online in minutes, or reach us on WhatsApp — a real person replies."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "copper",
							size: "roomy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/apply",
								children: "Apply now"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "glass",
							size: "roomy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://wa.me/260769974200",
								target: "_blank",
								rel: "noopener noreferrer",
								children: "WhatsApp us"
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleReviews, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppChat, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-6 border-t border-foreground/10 pt-6 text-sm text-muted-foreground",
				children: [
					"Avesta Enterprises · Ndola, Zambia ·",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/legal",
						className: "underline hover:text-foreground",
						children: "Privacy & terms"
					})
				]
			})
		]
	});
}
//#endregion
export { DirectoryPage as component };
