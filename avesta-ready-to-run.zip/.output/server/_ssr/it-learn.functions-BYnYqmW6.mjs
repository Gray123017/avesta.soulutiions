import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { i as stringType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/it-learn.functions-BYnYqmW6.js
/**
* Reads the web. Any search service with a Tavily-shaped API works; set
* SEARCH_API_URL and SEARCH_API_KEY. Without them, research is simply off and
* the assistant says so rather than guessing from memory.
*/
var researchProblem = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator(objectType({ question: stringType().min(5).max(500) })).handler(createSsrRpc("a73d567cc28864a011e4fcedfbdcc42e1cbfd275c17e01f4e757761858ae5474"));
/** Every question, matched or not. This list is what the assistant learns from. */
var logQuestion = createServerFn({ method: "POST" }).validator(objectType({
	question: stringType().min(3).max(500),
	matchedTitle: stringType().max(200).nullable()
})).handler(createSsrRpc("fcba44fb66e3d752caf4434acc8dcaa2bef62c5a9e5dec23c0de2fbff49abf06"));
/** The approved topics, merged into the troubleshooter alongside the built-in ones. */
var learnedTopics = createServerFn({ method: "GET" }).handler(createSsrRpc("69793c98f1f20d448fcf554129068c698815fa86c684ebbf0e716f4e02a820f8"));
/** What the topics could not answer, most asked first. Admins only. */
var learningQueue = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("33f85d20a6c0eabf1f0637584e258ff456e03893e25c5eb1ef6b660a171dde2d"));
/** Turns an answer into a permanent topic. A person decides; nothing is automatic. */
var promoteToTopic = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator(objectType({
	logId: stringType().uuid(),
	title: stringType().min(4).max(120),
	answer: stringType().min(10).max(1200),
	try: arrayType(stringType().max(400)).max(7),
	stop: stringType().max(400),
	service: stringType().max(120),
	match: arrayType(stringType().max(80)).min(1).max(30)
})).handler(createSsrRpc("11684e41ed203e62d7509cf305928814bd8c675219aed3c8af5d55b7f1152b28"));
//#endregion
export { researchProblem as a, promoteToTopic as i, learningQueue as n, logQuestion as r, learnedTopics as t };
