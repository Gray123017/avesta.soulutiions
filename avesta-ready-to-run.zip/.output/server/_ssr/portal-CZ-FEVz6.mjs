import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal-CZ-FEVz6.js
var $$splitComponentImporter = () => import("./portal-VmCYexCj.mjs");
var Route = createFileRoute("/_authenticated/portal")({
	head: () => ({ meta: [
		{ title: "Borrower portal — Avesta Enterprises" },
		{
			name: "description",
			content: "Track your loan application status, upload documents and see your next steps."
		},
		{
			property: "og:title",
			content: "Avesta borrower portal"
		},
		{
			property: "og:description",
			content: "Your application status, documents and next steps."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
