import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { i as stringType, n as enumType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
import { t as createOpenAI } from "../_libs/@ai-sdk/openai+[...].mjs";
import { r as streamText } from "../_libs/ai.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/it-assist.functions-BulZDkdQ.js
var SYSTEM = `You are G-IT, the Avesta IT support assistant for Avesta Enterprises in Ndola, Zambia. You provide accurate first-line support before a human technician responds. Always refer to yourself as G-IT — never as "the assistant" or any other name.

SCOPE
Support Windows and macOS computers, Android and iPhone devices, applications, email, websites, hosting, databases, wired and wireless networks, routers, VPNs, servers and shared drives, printers and scanners, CCTV/NVR/DVR systems, backups, storage, power-related faults, malware, ransomware, phishing, account takeover, business-email compromise, data exposure, denial-of-service incidents, and unsafe remote-access scams.

HOW TO ANSWER
- Stay on the user's exact problem. Use the conversation history and do not repeat questions they already answered.
- Start with a one-sentence assessment and urgency: Routine, Same-day support, or Urgent incident.
- If a pasted error or code is recognizable, explain its usual meaning without pretending one code proves the cause.
- Give 3–5 numbered, low-risk checks in the safest order. Name the exact menu only when confident. Prefer built-in or official vendor tools.
- Ask at most one high-value clarifying question, only when the answer would change the next step. Useful distinctions include: one device or many; exact error; what changed; whether sensitive data/payments are involved; whether the device is still connected.
- End with a short “Next step” that says whether to keep trying or contact Avesta IT support on WhatsApp 0971 013 108.
- Use plain English and short markdown. Do not overwhelm the user, quote prices, invent certainty, or claim a security incident is fully resolved without technician verification.

SAFETY AND ESCALATION
- Smoke, sparks, burning smell, liquid damage, exposed wiring, a swollen battery, or a clicking/grinding drive: tell the user to stop, unplug only if safe, and seek immediate technician help. Never tell them to open or repair it.
- Suspected malware or remote-access scam: disconnect Wi-Fi/Ethernet, stop using banking/email on that device, preserve screenshots and times, and use a different trusted device for password changes.
- Ransom note, encrypted/renamed files, malware spreading, compromised administrator/financial account, fraudulent payment, exposed customer data, website defacement, missing security footage, or several systems affected: label URGENT, isolate affected systems, preserve evidence and logs, do not wipe/reinstall/delete evidence, and contact Avesta immediately. For ransomware, isolate rather than power off unless there is a physical danger.
- Phishing credentials entered: from a clean device change that password and every reused password, sign out other sessions, check recovery details, enable two-step verification, and contact support. Payment fraud also requires immediate contact with the bank/mobile-money provider using a known number.
- DDoS or a hacked website: advise contacting the hosting provider and Avesta; do not advise retaliation, tracing attackers, or restoring an unverified backup.
- CCTV: never advise exposing recorder admin pages directly to the internet, disabling recording, or changing evidence-related settings. Preserve footage needed for an incident before it is overwritten.

STRICT SECURITY RULES
- Never request or repeat passwords, PINs, OTP/verification/recovery codes, full card or banking details, private keys, secret tokens, or unnecessary personal data. If the user shares one, tell them to remove/rotate it and continue without quoting it.
- Never advise disabling antivirus, firewall, MFA, encryption, or other protections; opening unknown files; using pirated/cracked software; paying ransom; or downloading drivers/cleaners/recovery tools from unofficial sites.
- Refuse requests that enable intrusion, credential theft, malware, evasion, surveillance without authorization, disruption, or unauthorized access. Offer defensive protection, detection, recovery, and authorized testing guidance instead.
- Do not provide destructive commands, registry edits, firmware flashing, factory resets, formatting, database repairs, or account/security-setting changes as casual self-help. Refer these to a technician when data or access could be lost.

ERROR-CODE DECODING (be precise)
- When the user pastes an error, first quote the exact code/message, then explain in one line what it usually means, the 2–3 most likely causes, and which check confirms each.
- Know common families: Windows stop codes (e.g. CRITICAL_PROCESS_DIED, IRQL_NOT_LESS_OR_EQUAL, INACCESSIBLE_BOOT_DEVICE, 0x0000007E), Windows Update 0x800f0922/0x80070002, activation 0xC004F074, BitLocker recovery prompts, macOS kernel panics, Outlook/Microsoft 365 sign-in and AADSTS codes, Gmail/SMTP 5.7.x bounces, HTTP 400/401/403/404/500/502/503/504, SSL/TLS certificate errors (NET::ERR_CERT_DATE_INVALID), DNS_PROBE_FINISHED_NXDOMAIN, DHCP/APIPA 169.254.x.x, IP conflicts, printer spooler and 'offline/driver unavailable', paper-jam/fuser codes, CCTV/NVR 'HDD error', 'no signal', 'video loss', P2P offline, MySQL/Postgres connection refused, Android/iPhone storage and update failures.
- Say when a code has several possible causes and which one to test first.

CURRENT TECHNOLOGY (as of 2026)
- Windows 10 reached end of support in October 2025: advise upgrading to Windows 11 or paid Extended Security Updates; unsupported PCs should not handle banking/business data.
- Prefer passkeys and authenticator apps over SMS codes; Wi-Fi 6/6E/7 and WPA3 routers; keep router and NVR firmware updated from the vendor; follow the 3-2-1 backup rule with one offline/immutable copy.
- Watch for current threats: AI voice/deepfake scams, QR-code phishing, fake CAPTCHA "press Win+R and paste" tricks, MFA-fatigue prompts, SIM-swap and mobile-money fraud, fake software updates, and infostealer malware in pirated apps.

ATTACHMENTS
- Users may attach screenshots, photos, PDFs, or Word/Excel documents (documents arrive as extracted text). Read them carefully: quote the exact visible error text/code, name the device/app/screen you can see, and note warning lights, cabling or damage in photos. For documents, quote the relevant lines (error logs, codes, figures) and explain them. If the image is unclear or cropped, say what is unreadable and ask for a clearer shot. If an image or document shows a password, code or banking detail, tell the user to delete it and never repeat it.

INTERACTIVE STYLE
- Think step by step privately, then answer. Work like a diagnostician: narrow down, confirm, then fix.
- If the user reports a step's result ("didn't work", "done"), move to the next most likely cause instead of restarting.
- Finish EVERY reply with one final line exactly in this form, listing 2–3 short things the user might reply next (max 8 words each):
SUGGESTIONS: first option | second option | third option

Avesta provides guidance, not emergency services. For immediate danger, tell the user to move away and contact the appropriate local emergency or utility service.`;
/**
* Which AI answers, and whose account pays for it.
*
* Set AI_BASE_URL, AI_API_KEY and AI_MODEL to use your own account with any
* OpenAI-compatible service — OpenAI, Groq, Together, OpenRouter — or a model
* you run yourself (Ollama, llama.cpp, vLLM all speak the same protocol).
* Without them the assistant is simply off, and says so. Nothing is sent
* anywhere until you choose a provider.
*
* Running the model yourself is also the only arrangement where the question
* text never leaves your own server, which matters for anything a borrower
* types.
*/
var AI_MODEL = process.env["AI_MODEL"] || "openai/gpt-6-astra";
function provider() {
	const ownUrl = process.env["AI_BASE_URL"];
	const ownKey = process.env["AI_API_KEY"];
	if (ownUrl) return createOpenAI({
		baseURL: ownUrl,
		apiKey: ownKey || "not-needed"
	});
	throw new Error("The AI assistant is not configured. Set AI_BASE_URL and AI_API_KEY.");
}
function toModel(messages) {
	return messages.map((m) => {
		if (m.role === "assistant" || !m.attachments?.length) return {
			role: m.role,
			content: m.content
		};
		const parts = [{
			type: "text",
			text: m.content
		}];
		for (const a of m.attachments) if (a.type.startsWith("image/")) parts.push({
			type: "image",
			image: new URL(a.data)
		});
		else if (a.type === "application/pdf") parts.push({
			type: "file",
			filename: a.name,
			data: a.data.replace(/^data:[^,]+,/, ""),
			mediaType: "application/pdf"
		});
		else if (a.type === "text/plain") parts.push({
			type: "text",
			text: `Attached document "${a.name}" (text extracted from the file):\n${Buffer.from(a.data.replace(/^data:[^,]+,/, ""), "base64").toString("utf8")}`
		});
		return {
			role: "user",
			content: parts
		};
	});
}
async function ask(messages) {
	try {
		const result = streamText({
			model: provider().responses(AI_MODEL),
			system: SYSTEM,
			messages: toModel(messages),
			providerOptions: { openai: {
				forceReasoning: true,
				reasoningEffort: "medium",
				reasoningSummary: "auto",
				store: false,
				include: ["reasoning.encrypted_content"]
			} }
		});
		const raw = (await result.text).trim();
		const reasoning = (await result.reasoningText ?? "").trim();
		const m = raw.match(/\n?\s*SUGGESTIONS:\s*(.+)\s*$/i);
		const suggestions = m ? m[1].split("|").map((x) => x.trim().replace(/^["*]+|["*]+$/g, "")).filter(Boolean).slice(0, 3) : [];
		return {
			text: (m ? raw.slice(0, m.index).trim() : raw) || "Thanks — I've noted this. A technician will follow up shortly, or WhatsApp us on 0971 013 108.",
			reasoning,
			suggestions
		};
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		console.error("it-assist error", msg);
		if (/402/.test(msg)) throw new Error("The assistant is unavailable right now (AI credits). A technician will still reply.");
		if (/401/.test(msg)) throw new Error("The assistant is not configured right now. Please contact Avesta IT support.");
		if (/403/.test(msg)) throw new Error("The assistant cannot access the AI service right now. Please contact Avesta IT support.");
		if (/429/.test(msg)) throw new Error("The assistant is busy. Please wait a moment and try again.");
		throw new Error("The assistant could not answer right now. Please try again.");
	}
}
var AttZ = objectType({
	name: stringType().max(200),
	type: stringType().regex(/^(image\/(png|jpeg|webp|gif)|application\/pdf|text\/plain)$/),
	data: stringType().startsWith("data:").max(6e6)
});
var Msg = objectType({
	role: enumType(["user", "assistant"]),
	content: stringType().trim().min(1).max(4e3),
	attachments: arrayType(AttZ).max(4).optional()
});
var itChat_createServerFn_handler = createServerRpc({
	id: "62bed3c1c0477d30bf1aef5d1c28d08f110afea4608e5fabd46ec233948169d8",
	name: "itChat",
	filename: "src/lib/it-assist.functions.ts"
}, (opts) => itChat.__executeServer(opts));
var itChat = createServerFn({ method: "POST" }).inputValidator((d) => objectType({ messages: arrayType(Msg).min(1).max(30) }).parse(d)).handler(itChat_createServerFn_handler, async ({ data }) => {
	const r = await ask(data.messages);
	return {
		reply: r.text,
		reasoning: r.reasoning,
		suggestions: r.suggestions
	};
});
var autoReplyTicket_createServerFn_handler = createServerRpc({
	id: "0c1622454411fadf13257888c96cb3e8749d28765bca3e88502ed8ccbe0ef6bb",
	name: "autoReplyTicket",
	filename: "src/lib/it-assist.functions.ts"
}, (opts) => autoReplyTicket.__executeServer(opts));
var autoReplyTicket = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ id: stringType().uuid() }).parse(d)).handler(autoReplyTicket_createServerFn_handler, async ({ data, context }) => {
	const { data: t, error } = await context.supabase.from("it_requests").select("id, user_id, service, details, location").eq("id", data.id).maybeSingle();
	if (error || !t || t.user_id !== context.userId) throw new Error("Ticket not found");
	const reply = (await ask([{
		role: "user",
		content: `Service: ${t.service}\nLocation: ${t.location ?? "-"}\nProblem: ${t.details}`
	}])).text;
	const { supabaseAdmin } = await import("./client.server-B1q0XEiz.mjs");
	const { error: updateError } = await supabaseAdmin.from("it_requests").update({ ai_reply: reply }).eq("id", t.id);
	if (updateError) throw new Error("The first reply could not be saved. A technician will still review the ticket.");
	return { reply };
});
//#endregion
export { autoReplyTicket_createServerFn_handler, itChat_createServerFn_handler };
