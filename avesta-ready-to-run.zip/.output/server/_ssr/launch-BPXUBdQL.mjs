import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/launch-BPXUBdQL.js
var $$splitComponentImporter = () => import("./launch-Dhbsals6.mjs");
var Route = createFileRoute("/_authenticated/launch")({
	head: () => ({ meta: [
		{ title: "Launch & Google checklist — Avesta Enterprises" },
		{
			name: "description",
			content: "Domain connection status and Google Search Console steps for avesta.solutions."
		},
		{
			property: "og:title",
			content: "Avesta launch checklist"
		},
		{
			property: "og:description",
			content: "Domain status and Google indexing progress."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex, nofollow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
