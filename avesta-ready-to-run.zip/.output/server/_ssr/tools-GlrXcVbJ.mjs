import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { i as loanQuote, n as RATES, r as kwacha } from "./avesta-HIuujrtk.mjs";
import { t as Label } from "./label-Dz64RFdN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-GlrXcVbJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getRates = createServerFn({ method: "GET" }).handler(createSsrRpc("1e0941a199f160fb788d4f4f39a3b00910ec53d0901baa56e06c4430e14dc7f8"));
function Tools() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page-enter min-h-screen bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl font-semibold print:hidden",
					children: "Loan calculator & currency converter"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Converter, {})
			]
		})
	});
}
function Calculator() {
	const [amount, setAmount] = (0, import_react.useState)(1e3);
	const [weeks, setWeeks] = (0, import_react.useState)(2);
	const [freq, setFreq] = (0, import_react.useState)("end");
	const [name, setName] = (0, import_react.useState)("");
	const [nrc, setNrc] = (0, import_react.useState)("");
	const [showAgreement, setShowAgreement] = (0, import_react.useState)(false);
	const q = loanQuote(amount || 0, weeks, freq);
	const [today, setToday] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => setToday((/* @__PURE__ */ new Date()).toLocaleDateString("en-GB")), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8 rounded-2xl border border-border bg-card p-6 print:border-0 print:p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Loan calculator"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount (K)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 100,
								value: amount,
								onChange: (e) => setAmount(Number(e.target.value))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "loan-term",
								children: "Term"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "loan-term",
								className: "h-10 w-full rounded-md border border-input bg-background px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
								value: weeks,
								onChange: (e) => setWeeks(Number(e.target.value)),
								children: Object.entries(RATES).map(([w, r]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: w,
									children: [
										w,
										" week",
										w !== "1" ? "s" : "",
										" — ",
										r,
										"%"
									]
								}, w))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "loan-repay",
								children: "Repay"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "loan-repay",
								className: "h-10 w-full rounded-md border border-input bg-background px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
								value: freq,
								onChange: (e) => setFreq(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "end",
										children: "Once at the end"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "weekly",
										children: "Weekly"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "bi-weekly",
										children: "Every two weeks"
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Interest",
							value: `${q.rate}% · ${kwacha(q.interest)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Total to repay",
							value: kwacha(q.total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Payments",
							value: String(q.installments)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Each payment",
							value: kwacha(q.perInstallment)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Your full name (for agreement)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "NRC number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: nrc,
							onChange: (e) => setNrc(e.target.value),
							placeholder: "000000/00/0"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "copper",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/dashboard",
								children: "Apply for this loan"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: () => setShowAgreement(true),
							children: "Preview agreement"
						}),
						showAgreement && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							onClick: () => window.print(),
							children: "Print / save as PDF"
						})
					]
				})
			]
		}), showAgreement && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mt-8 space-y-3 rounded-lg border border-border bg-background p-6 text-sm leading-relaxed print:mt-0 print:border-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-center font-display text-xl font-semibold",
					children: "AVESTA ENTERPRISES — LOAN AGREEMENT (DRAFT)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Date: ", today] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Borrower: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: name || "________________" }),
					" · NRC: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: nrc || "____________" })
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Lender: Avesta Enterprises, Ndola, Zambia. Licence: in progress." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-1 pl-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Principal: ",
							kwacha(amount || 0),
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Term: ",
							weeks,
							" week(s) at a flat ",
							q.rate,
							"% interest (",
							kwacha(q.interest),
							")."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Total repayable: ",
							kwacha(q.total),
							" in ",
							q.installments,
							" payment(s) of ",
							kwacha(q.perInstallment),
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Payments are made on or before each due date. Late payment must be discussed with Avesta staff before the due date." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "This draft is not an offer. The loan is only binding once approved and signed by Avesta staff." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 pt-10 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "border-t border-foreground/40 pt-1",
						children: "Borrower signature"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "border-t border-foreground/40 pt-1",
						children: "For Avesta Enterprises"
					})]
				})
			]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold",
			children: value
		})]
	});
}
function Converter() {
	const fetchRates = useServerFn(getRates);
	const r = useQuery({
		queryKey: ["fx"],
		queryFn: () => fetchRates(),
		staleTime: 36e5
	});
	const [amt, setAmt] = (0, import_react.useState)(1e3);
	const [dir, setDir] = (0, import_react.useState)("from");
	const [boz, setBoz] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => setBoz(localStorage.getItem("boz-usd") ?? ""), []);
	const rates = r.data?.rates ?? {};
	const bozUsd = Number(boz);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8 rounded-2xl border border-border bg-card p-6 print:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: "Currency converter"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: amt,
							onChange: (e) => setAmt(Number(e.target.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "rate-direction",
							children: "Direction"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "rate-direction",
							className: "h-10 w-full rounded-md border border-input bg-background px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
							value: dir,
							onChange: (e) => setDir(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "from",
								children: "Kwacha → other currencies"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "to",
								children: "Other currencies → Kwacha"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Bank of Zambia USD rate (K per $1, optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: boz,
							onChange: (e) => {
								setBoz(e.target.value);
								localStorage.setItem("boz-usd", e.target.value);
							}
						})]
					})
				]
			}),
			r.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				children: "Loading today's rates…"
			}),
			r.data && !r.data.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-destructive",
				children: "Live rates are unavailable right now. Enter the Bank of Zambia rate above for USD."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-3 sm:grid-cols-4",
				children: [bozUsd > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "USD (Bank of Zambia)",
					value: dir === "from" ? `$${(amt / bozUsd).toFixed(2)}` : kwacha(amt * bozUsd)
				}), Object.entries(rates).map(([c, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: c,
					value: dir === "from" ? `${(amt * v).toLocaleString(void 0, { maximumFractionDigits: 2 })} ${c}` : kwacha(amt / v)
				}, c))]
			}),
			r.data?.updated && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: [
					"Market rates updated ",
					r.data.updated,
					". Indicative only."
				]
			})
		]
	});
}
//#endregion
export { Tools as component };
