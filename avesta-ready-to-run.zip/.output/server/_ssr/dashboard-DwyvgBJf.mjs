import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DwyvgBJf.js
var $$splitComponentImporter = () => import("./dashboard-CzXAJuxL.mjs");
var Route = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "My account — Avesta Enterprises" },
		{
			name: "description",
			content: "Apply for loans, track repayments and request IT support."
		},
		{
			property: "og:title",
			content: "My Avesta account"
		},
		{
			property: "og:description",
			content: "Your loans and IT requests in one place."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
