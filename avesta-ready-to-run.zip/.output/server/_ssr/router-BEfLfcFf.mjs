import { i as __toESM } from "../_runtime.mjs";
import { N as redirect, _ as Link, b as useRouter, c as Scripts, f as createRouter, g as createRootRouteWithContext, h as createFileRoute, l as HeadContent, m as lazyRouteComponent, p as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { t as Route$11 } from "./admin-DrdCOFgD.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$12 } from "./dashboard-DwyvgBJf.mjs";
import { t as Route$13 } from "./launch-BPXUBdQL.mjs";
import { t as Route$14 } from "./portal-CZ-FEVz6.mjs";
import { t as Route$15 } from "./schedule._loanId-Czg3rJG_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BEfLfcFf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Chbb9GOx.css";
function describe(error) {
	if (error instanceof Error) return {
		message: error.message,
		...error.stack ? { stack: error.stack } : {}
	};
	return { message: typeof error === "string" ? error : JSON.stringify(error) };
}
function reportError(error, context = {}) {
	const detail = describe(error);
	console.error("[avesta]", detail.message, {
		...context,
		stack: detail.stack
	});
	const hook = typeof process !== "undefined" ? process.env?.["ERROR_WEBHOOK_URL"] : void 0;
	if (!hook) return;
	fetch(hook, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			text: `Avesta site error: ${detail.message}`,
			context,
			at: (/* @__PURE__ */ new Date()).toISOString()
		})
	}).catch(() => {});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: "Go home"
						})
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							router.invalidate();
							reset();
						},
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/",
							children: "Go home"
						})
					})]
				})
			]
		})
	});
}
var Route$10 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{
				name: "theme-color",
				content: "#163E33"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Avesta"
			},
			{ title: "Avesta Enterprises" },
			{
				name: "description",
				content: "Lending and IT consulting across Zambia."
			},
			{
				name: "author",
				content: "Avesta Enterprises"
			},
			{
				name: "google-site-verification",
				content: "bM2IM7_YfuNrN_QuIqFzzIaYw6aJ61_65YRawObTkx0"
			},
			{
				property: "og:title",
				content: "Avesta Enterprises"
			},
			{
				property: "og:description",
				content: "Lending and IT consulting across Zambia."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:image",
				content: "https://avesta.solutions/og.jpg"
			},
			{
				property: "og:image:width",
				content: "1200"
			},
			{
				property: "og:image:height",
				content: "630"
			},
			{
				property: "og:image:alt",
				content: "Avesta Enterprises — short-term loans and IT services across Zambia"
			},
			{
				name: "twitter:image",
				content: "https://avesta.solutions/og.jpg"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				sizes: "any"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png"
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/icons/apple-touch-icon.png"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$10.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		if (!("serviceWorker" in navigator) || false) return;
		const register = () => {
			navigator.serviceWorker.register("/sw.js").catch(() => {});
		};
		if (document.readyState === "complete") register();
		else window.addEventListener("load", register, { once: true });
	}, []);
	(0, import_react.useEffect)(() => {
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			setTimeout(() => {
				router.invalidate();
				if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
			}, 0);
		});
		return () => data.subscription.unsubscribe();
	}, [router, queryClient]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})]
	});
}
var $$splitComponentImporter$9 = () => import("./routes-Dgt6NQWt.mjs");
var Route$9 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Short-Term Loans & IT Services in Ndola, Zambia | Avesta" },
			{
				name: "description",
				content: "Short-term loans (1–4 weeks, 15–30%) and IT support — repairs, networks, CCTV, websites — for individuals and businesses across Zambia. Based in Ndola."
			},
			{
				property: "og:title",
				content: "Avesta Enterprises — Lending & IT Services"
			},
			{
				property: "og:description",
				content: "Two trusted services, one Zambian enterprise: flexible lending and hands-on IT support."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://avesta.solutions/"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/"
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": ["FinancialService", "ProfessionalService"],
				name: "Avesta Enterprises",
				url: "https://avesta.solutions/",
				logo: "https://avesta.solutions/favicon.png",
				telephone: "+260971013108",
				email: ["info@avasta.solutions", "avestaenterprises4@gmail.com"],
				address: {
					"@type": "PostalAddress",
					addressLocality: "Ndola",
					addressCountry: "ZM"
				},
				areaServed: {
					"@type": "Country",
					name: "Zambia"
				},
				description: "Short-term lending and IT consulting for individuals and businesses across Zambia.",
				hasOfferCatalog: {
					"@type": "OfferCatalog",
					name: "Services",
					itemListElement: [
						{
							"@type": "Offer",
							itemOffered: {
								"@type": "LoanOrCredit",
								name: "Short-term loan",
								loanTerm: {
									"@type": "QuantitativeValue",
									minValue: 1,
									maxValue: 4,
									unitCode: "WEE"
								}
							}
						},
						{
							"@type": "Offer",
							itemOffered: {
								"@type": "Service",
								name: "Computer repairs & networks"
							}
						},
						{
							"@type": "Offer",
							itemOffered: {
								"@type": "Service",
								name: "CCTV & cybersecurity"
							}
						},
						{
							"@type": "Offer",
							itemOffered: {
								"@type": "Service",
								name: "Websites & databases"
							}
						}
					]
				}
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./route-Di7iQBCH.mjs");
var Route$8 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./advisor-Dc3wD7ML.mjs");
var Route$7 = createFileRoute("/advisor")({
	head: () => ({
		meta: [
			{ title: "Free Loan & IT Advisor Zambia — Avesta Enterprises" },
			{
				name: "description",
				content: "Describe your loan or business IT needs and get tailored Avesta recommendations in seconds."
			},
			{
				property: "og:title",
				content: "Avesta advisor — loans & IT"
			},
			{
				property: "og:description",
				content: "Tell us what you need; get suitable loan options or IT services and next steps."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/advisor"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./apply-CL6Ox9N8.mjs");
var Route$6 = createFileRoute("/apply")({
	head: () => ({
		meta: [
			{ title: "Apply for a Loan in Ndola — Avesta Enterprises" },
			{
				name: "description",
				content: "Apply online for a 1–4 week loan from Avesta Enterprises in Ndola. Submit your details and get a response from our team."
			},
			{
				property: "og:title",
				content: "Apply for a Loan — Avesta Enterprises Ndola"
			},
			{
				property: "og:description",
				content: "Short-term loans with clear terms. Apply online and track Avesta's response."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/apply"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./auth-CdWsPvDN.mjs");
var Route$5 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Sign in — Avesta Enterprises" },
		{
			name: "description",
			content: "Sign in or create your Avesta account to apply for loans and request IT support."
		},
		{
			property: "og:title",
			content: "Sign in — Avesta Enterprises"
		},
		{
			property: "og:description",
			content: "Access your Avesta lending and IT support account."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex, follow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./directory-BR3fur9V.mjs");
var Route$4 = createFileRoute("/directory")({
	head: () => ({
		meta: [
			{ title: "Avesta Enterprises Ndola — Loans & IT Services in Ndola, Zambia" },
			{
				name: "description",
				content: "Avesta Enterprises in Ndola, Zambia: short-term loans (1–4 weeks) and IT services in Ndola — computer repairs, networking, CCTV, cybersecurity, websites. Contact, location, hours and services."
			},
			{
				name: "keywords",
				content: "Avesta Enterprises Ndola, IT services in Ndola, computer repair Ndola, loans in Ndola, CCTV installation Ndola, networking Ndola, business directory Zambia"
			},
			{
				property: "og:title",
				content: "Avesta Enterprises Ndola — Loans & IT Services in Ndola, Zambia"
			},
			{
				property: "og:description",
				content: "Directory entry for Avesta Enterprises: short-term loans and IT services in Ndola, Copperbelt — contact details, location and opening hours."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:url",
				content: "https://avesta.solutions/directory"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/directory"
		}],
		scripts: [{
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "LocalBusiness",
				"@id": "https://avesta.solutions/#business",
				name: "Avesta Enterprises",
				alternateName: "Avesta Enterprises Ndola",
				description: "Avesta Enterprises in Ndola, Zambia: short-term lending (1–4 weeks) and IT services in Ndola — computer repairs, networking, CCTV installation, cybersecurity, websites and databases — for individuals and businesses across Zambia.",
				url: "https://avesta.solutions/",
				telephone: "+260971013108",
				email: ["info@avasta.solutions", "avestaenterprises4@gmail.com"],
				priceRange: "K",
				address: {
					"@type": "PostalAddress",
					streetAddress: "House No. 3, Thom Avenue, Kansenshi",
					addressLocality: "Ndola",
					addressRegion: "Copperbelt",
					addressCountry: "ZM"
				},
				hasMap: "https://www.google.com/maps/search/?api=1&query=Avesta+Enterprises%2C+House+No.+3%2C+Thom+Avenue%2C+Kansenshi%2C+Ndola%2C+Zambia",
				geo: {
					"@type": "GeoCoordinates",
					latitude: -12.9687,
					longitude: 28.6366
				},
				openingHoursSpecification: [{
					"@type": "OpeningHoursSpecification",
					dayOfWeek: [
						"Monday",
						"Tuesday",
						"Wednesday",
						"Thursday",
						"Friday",
						"Saturday"
					],
					opens: "08:00",
					closes: "17:00"
				}],
				areaServed: [
					{
						"@type": "City",
						name: "Ndola"
					},
					{
						"@type": "City",
						name: "Kitwe"
					},
					{
						"@type": "City",
						name: "Lusaka"
					},
					{
						"@type": "AdministrativeArea",
						name: "Copperbelt Province"
					},
					{
						"@type": "Country",
						name: "Zambia"
					}
				],
				knowsAbout: [
					"Short-term loans in Ndola",
					"IT services in Ndola",
					"Computer repairs",
					"Computer networking",
					"CCTV installation",
					"Cybersecurity",
					"Websites and databases"
				],
				makesOffer: [{
					"@type": "Offer",
					itemOffered: {
						"@type": "Service",
						name: "Short-term loans",
						areaServed: {
							"@type": "City",
							name: "Ndola"
						}
					}
				}, {
					"@type": "Offer",
					itemOffered: {
						"@type": "Service",
						name: "IT services",
						areaServed: {
							"@type": "City",
							name: "Ndola"
						}
					}
				}]
			})
		}, {
			type: "application/ld+json",
			children: JSON.stringify({
				"@context": "https://schema.org",
				"@type": "BreadcrumbList",
				itemListElement: [{
					"@type": "ListItem",
					position: 1,
					name: "Home",
					item: "https://avesta.solutions/"
				}, {
					"@type": "ListItem",
					position: 2,
					name: "Business directory",
					item: "https://avesta.solutions/directory"
				}]
			})
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./it-help-BZiNI3cq.mjs");
var Route$3 = createFileRoute("/it-help")({
	head: () => ({
		meta: [
			{ title: "Free IT Help & Troubleshooter Ndola | Avesta" },
			{
				name: "description",
				content: "Describe your computer, internet, printer or CCTV problem and get likely causes and things to try, free."
			},
			{
				property: "og:title",
				content: "Avesta IT help troubleshooter"
			},
			{
				property: "og:description",
				content: "Tell us what's wrong and get practical fixes, or book a technician."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/it-help"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./legal-CcpKJv8l.mjs");
var Route$2 = createFileRoute("/legal")({
	head: () => ({
		meta: [
			{ title: "Privacy, Terms & Complaints — Avesta Enterprises" },
			{
				name: "description",
				content: "How Avesta Enterprises handles your information, our loan terms, and how to raise a complaint."
			},
			{
				property: "og:title",
				content: "Privacy, Terms & Complaints — Avesta Enterprises"
			},
			{
				property: "og:description",
				content: "Our privacy policy, loan terms and complaints procedure, in plain language."
			},
			{
				property: "og:type",
				content: "article"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/legal"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./reset-password-CUP7WvcF.mjs");
var Route$1 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Set a new password — Avesta Enterprises" },
		{
			name: "description",
			content: "Choose a new password for your Avesta account."
		},
		{
			property: "og:title",
			content: "Reset password — Avesta"
		},
		{
			property: "og:description",
			content: "Choose a new password for your Avesta account."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex, nofollow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tools-GlrXcVbJ.mjs");
var Route = createFileRoute("/tools")({
	head: () => ({
		meta: [
			{ title: "Loan Calculator & Currency Converter | Avesta Zambia" },
			{
				name: "description",
				content: "Work out your Avesta loan repayments, print a draft agreement, and convert Kwacha to other currencies."
			},
			{
				property: "og:title",
				content: "Avesta loan calculator & currency converter"
			},
			{
				property: "og:description",
				content: "See exactly what you repay and convert Kwacha instantly."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://avesta.solutions/tools"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AuthenticatedRouteRoute = Route$8.update({
	id: "/_authenticated",
	getParentRoute: () => Route$10
});
var AdvisorRoute = Route$7.update({
	id: "/advisor",
	path: "/advisor",
	getParentRoute: () => Route$10
});
var ApplyRoute = Route$6.update({
	id: "/apply",
	path: "/apply",
	getParentRoute: () => Route$10
});
var AuthRoute = Route$5.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$10
});
var DirectoryRoute = Route$4.update({
	id: "/directory",
	path: "/directory",
	getParentRoute: () => Route$10
});
var ItHelpRoute = Route$3.update({
	id: "/it-help",
	path: "/it-help",
	getParentRoute: () => Route$10
});
var LegalRoute = Route$2.update({
	id: "/legal",
	path: "/legal",
	getParentRoute: () => Route$10
});
var ResetPasswordRoute = Route$1.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$10
});
var ToolsRoute = Route.update({
	id: "/tools",
	path: "/tools",
	getParentRoute: () => Route$10
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAdminRoute: Route$11.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDashboardRoute: Route$12.update({
		id: "/dashboard",
		path: "/dashboard",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedLaunchRoute: Route$13.update({
		id: "/launch",
		path: "/launch",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPortalRoute: Route$14.update({
		id: "/portal",
		path: "/portal",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedScheduleLoanIdRoute: Route$15.update({
		id: "/schedule/$loanId",
		path: "/schedule/$loanId",
		getParentRoute: () => AuthenticatedRouteRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AdvisorRoute,
	ApplyRoute,
	AuthRoute,
	DirectoryRoute,
	ItHelpRoute,
	LegalRoute,
	ResetPasswordRoute,
	ToolsRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
