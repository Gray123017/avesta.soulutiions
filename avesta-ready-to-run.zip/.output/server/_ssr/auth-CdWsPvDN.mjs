import { i as __toESM } from "../_runtime.mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { r as PageNavigation } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Dz64RFdN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-CdWsPvDN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		email: "",
		password: "",
		full_name: "",
		phone: ""
	});
	(0, import_react.useEffect)(() => {
		supabase.auth.getUser().then(({ data }) => {
			if (data.user) navigate({ to: "/dashboard" });
		});
	}, [navigate]);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			if (mode === "in") {
				const { error } = await supabase.auth.signInWithPassword({
					email: form.email,
					password: form.password
				});
				if (error) throw error;
				navigate({ to: "/dashboard" });
			} else if (mode === "up") {
				const { error } = await supabase.auth.signUp({
					email: form.email,
					password: form.password,
					options: {
						emailRedirectTo: window.location.origin + "/auth",
						data: {
							full_name: form.full_name,
							phone: form.phone
						}
					}
				});
				if (error) throw error;
				toast.success("Account created. Check your email to confirm it, then sign in with your password.");
				setMode("in");
			} else {
				const { error } = await supabase.auth.resetPasswordForEmail(form.email, { redirectTo: window.location.origin + "/reset-password" });
				if (error) throw error;
				toast.success("Password reset link sent to your email.");
				setMode("in");
			}
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	const set = (k) => (e) => setForm({
		...form,
		[k]: e.target.value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-enter flex min-h-screen items-center justify-center px-4 py-10 sm:px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageNavigation, { className: "mb-5" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "mb-8 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-lg bg-primary font-display font-bold text-primary-foreground",
						children: "AE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display font-semibold",
						children: "Avesta Enterprises"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "service-door min-w-0 space-y-4 rounded-lg p-4 sm:p-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl font-semibold",
							children: mode === "in" ? "Sign in" : mode === "up" ? "Create your account" : "Reset password"
						}),
						mode === "up" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Full name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								value: form.full_name,
								onChange: set("full_name")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "09XX XXX XXX",
								value: form.phone,
								onChange: set("phone")
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								required: true,
								value: form.email,
								onChange: set("email")
							})]
						}),
						mode !== "reset" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: mode === "up" ? "Create password" : "Password" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								required: true,
								minLength: 6,
								autoComplete: mode === "up" ? "new-password" : "current-password",
								value: form.password,
								onChange: set("password")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "copper",
							className: "w-full",
							disabled: busy,
							children: busy ? "Please wait…" : mode === "in" ? "Sign in" : mode === "up" ? "Create account" : "Send reset link"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap justify-between gap-1 text-sm text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "quiet",
								size: "sm",
								onClick: () => setMode(mode === "up" ? "in" : "up"),
								children: mode === "up" ? "Have an account? Sign in" : "New here? Create account"
							}), mode === "in" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "quiet",
								size: "sm",
								onClick: () => setMode("reset"),
								children: "Forgot password?"
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { AuthPage as component };
