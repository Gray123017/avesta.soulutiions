import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { n as AppHeader } from "./AppHeader-DG15xa67.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-CcpKJv8l.js
var import_jsx_runtime = require_jsx_runtime();
function H({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mt-7 mb-2 font-display text-lg font-semibold text-primary",
		children
	});
}
function LegalPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-enter mx-auto max-w-3xl px-5 pb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-6 font-display text-4xl font-semibold",
					children: "Privacy, Terms & Complaints"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mb-8 flex flex-wrap gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#privacy",
							className: "rounded-full bg-foreground/10 px-3 py-1",
							children: "Privacy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#terms",
							className: "rounded-full bg-foreground/10 px-3 py-1",
							children: "Terms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#complaints",
							className: "rounded-full bg-foreground/10 px-3 py-1",
							children: "Complaints"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Last updated 24 September 2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "privacy",
					className: "text-foreground/85",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 font-display text-3xl font-semibold text-foreground",
							children: "Privacy Policy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: "Avesta Enterprises collects personal information to assess loan applications and provide IT services. This explains what we collect, why, and your rights."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "What we collect" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc space-y-1 pl-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Identity: full name and NRC number." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Contact: phone number and email address." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Loan records: amounts, dates, repayments and balances." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "IT requests: the service needed, location and details you give us." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Account: your email and a securely encrypted password — we can never read it." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Why we collect it" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To verify who you are, decide whether a loan can responsibly be offered, administer repayment, meet our duties under the Money-Lenders Act, and contact you about IT work." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Who can see it" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Only authorised staff. We do not sell your information or share it except where the law requires or you ask us to." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "How long we keep it" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "While your loan is running and afterwards for as long as the law requires. Enquiries that do not lead to a loan are removed after two years." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Your rights" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc space-y-1 pl-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ask what we hold about you and get a copy." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ask us to correct anything wrong, or delete what we no longer need." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Complain to us, and to the Data Protection Commissioner if we do not resolve it." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: "We respond within 30 days. If your information is ever exposed in a way that puts you at risk, we will tell you and report it to the Commissioner as the Data Protection Act No. 3 of 2021 requires."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "terms",
					className: "text-foreground/85",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-12 font-display text-3xl font-semibold text-foreground",
							children: "Terms & Conditions"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: "These terms explain our loans in plain language. The written loan agreement you sign is the binding document."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Our loans" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-xl border border-foreground/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-foreground/10 text-left",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-3",
											children: "Term"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-3",
											children: "Flat interest"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "p-3",
											children: "Repayment"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
									[
										"1 week",
										"15%",
										"Single lump sum"
									],
									[
										"2 weeks",
										"20%",
										"Single lump sum"
									],
									[
										"3 weeks",
										"25%",
										"Instalments or lump sum"
									],
									[
										"4 weeks",
										"30%",
										"Weekly instalments"
									]
								].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "border-t border-foreground/10",
									children: r.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: c
									}, c))
								}, r[0])) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: "Interest is simple and flat, applied once. No compound interest. The total you repay is stated before you sign and does not change."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "What you must do" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc space-y-1 pl-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Give true and complete information." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Repay the agreed amount on the agreed dates." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tell us early if you cannot pay — we would rather agree a new schedule." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Late payment" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A three-day grace period applies before any late charge set out in your agreement." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Early repayment" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You may repay early at any time; ask us for the settlement figure." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Your account" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Do not share your password. Tell us at once if you think someone else has used it." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Governing law" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Governed by the laws of Zambia, including the Money-Lenders Act, CAP 398." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "complaints",
					className: "text-foreground/85",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-12 font-display text-3xl font-semibold text-foreground",
							children: "Complaints Procedure"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
							className: "mt-3 list-decimal space-y-2 pl-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Tell us" }), " by phone, WhatsApp, email or at the office."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "We acknowledge" }), " within two working days."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "We investigate" }), " and answer in writing within fourteen working days."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Management review" }), " if you disagree, within a further fourteen working days."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Take it further" }), " to the Ministry of Finance, the Data Protection Commissioner, or the Zambian courts."] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3",
							children: "Nothing here limits your legal rights."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-12 border-t border-foreground/10 pt-6 text-sm text-muted-foreground",
					children: [
						"House No. 3, Thom Avenue, Kansenshi, Ndola · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "tel:+260971013108",
							children: "+260 971 013 108"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "tel:+260769974200",
							children: "+260 769 974 200"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:info@avasta.solutions",
							children: "info@avasta.solutions"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:avestaenterprises4@gmail.com",
							children: "avestaenterprises4@gmail.com"
						}),
						" · Mon–Sat 08:00–17:00"
					]
				})
			]
		})]
	});
}
//#endregion
export { LegalPage as component };
