import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Xa } from "../_libs/streamdown+tailwind-merge.mjs";
import { n as cn, t as Button } from "./button-DWLuVCSU.mjs";
import { a as researchProblem, r as logQuestion, t as learnedTopics } from "./it-learn.functions-BYnYqmW6.mjs";
import { A as Brain, E as CornerDownLeft, F as ArrowDown, M as ArrowUpRight, T as FileText, f as Paperclip, o as Square, t as X, y as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { t as Textarea } from "./textarea-BPdFvfWe.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as autoReplyTicket, r as itChat } from "./it-assist.functions-DY5_BgGE.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { n as useStickToBottomContext, t as StickToBottom } from "../_libs/use-stick-to-bottom.mjs";
import { t as nanoid } from "../_libs/nanoid.mjs";
import { t as motion } from "../_libs/motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/it-help-BZiNI3cq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var it_help_topics_default = /*#__PURE__*/ JSON.parse("[{\"match\":[\"wont start\",\"won't start\",\"not starting\",\"no power\",\"dead\",\"wont boot\",\"won't boot\",\"not booting\",\"black screen\",\"nothing happens\",\"no display\"],\"title\":\"Computer will not start\",\"answer\":\"Most of the time this is power reaching the machine, not the machine itself. On a laptop it is often the charger or battery; on a desktop, the wall socket, the cable or the power supply.\",\"try\":[\"Check the wall socket with something else you know works — a phone charger will do.\",\"On a laptop, take the battery out if it comes out, hold the power button for 20 seconds, put it back and try on mains only.\",\"Look for any light at all on the machine or the charger brick. Tell us what you see — it narrows things a lot.\",\"If a desktop has lights and fans but no picture, try a different screen cable or screen before assuming the computer is faulty.\"],\"stop\":\"If you smell burning, see scorching, or the machine trips your power when plugged in, unplug it and stop. Do not switch it on again.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"slow\",\"sluggish\",\"freezing\",\"freezes\",\"frozen\",\"freeze\",\"hanging\",\"hangs\",\"hang\",\"stuck\",\"takes long\",\"lagging\",\"lag\"],\"title\":\"Computer has become slow\",\"answer\":\"Usually one of four things: the disk is nearly full, too much starts up with Windows, the machine is short of memory for what it is being asked to do, or it is overheating and slowing itself down on purpose.\",\"try\":[\"Check free space on the C: drive. Under about 10% free and Windows struggles.\",\"Restart properly — Shut down, not just closing the lid. Many machines run for weeks without a real restart.\",\"Open Task Manager (Ctrl+Shift+Esc). On the Processes tab, click the CPU, Memory and Disk column headings in turn — whatever sits at the top is what is slowing you down. Then check the Startup tab and turn off things you do not need at every boot.\",\"Feel whether it is hot and whether the fan is loud or silent. A blocked fan is a common cause, and cleaning it is cheap.\"],\"stop\":\"If it is also making a clicking or grinding noise, stop using it and back up what matters now. That sound often means the drive is failing.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"no internet\",\"internet not working\",\"wifi\",\"wi-fi\",\"network down\",\"cant connect\",\"can't connect\",\"no connection\",\"disconnecting\",\"drops\",\"dropping\",\"keeps dropping\",\"disconnects\",\"slow internet\"],\"title\":\"No internet, or it keeps dropping\",\"answer\":\"Worth separating three things: your device, your router, and the line coming in. Finding which one is at fault takes two minutes and saves a call-out.\",\"try\":[\"Check whether another device on the same Wi-Fi also has the problem. If only one device is affected, it is that device, not the network.\",\"Turn the router off at the wall, wait thirty seconds, and turn it back on. Give it two or three minutes to settle.\",\"If your phone works on mobile data but not on the Wi-Fi, the line or router is the problem, not your phone.\",\"For a room where it keeps dropping, note how far it is from the router and what walls are in between — that usually explains it, and an access point fixes it.\",\"A full signal bar is not the same as a good connection. The bars only show you are near a router; a crowded channel, too many devices, or an overloaded router can drop you at full strength.\",\"Try moving the router somewhere central and higher up, away from metal and thick walls. Moving it often does more than replacing it.\"],\"stop\":\"If your provider confirms the line is fine and it still drops, the fix is usually router placement or an access point. That needs someone on site to do properly.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"printer\",\"printing\",\"wont print\",\"won't print\",\"not printing\",\"offline\",\"printer offline\",\"showing offline\",\"shows offline\",\"says offline\",\"use printer offline\",\"printer not responding\",\"printer error\",\"printer in error state\",\"error state\",\"scanner\",\"scan\"],\"title\":\"Printer will not print\",\"answer\":\"A printer that shows \\\"offline\\\" while it is switched on has lost communication with the computer — it is very rarely broken. On a network the usual cause is a changed address or a Wi-Fi drop; on USB, the cable. Windows also has a setting that holds the printer offline deliberately, and it can switch itself on.\",\"try\":[\"On Windows 11, open the Get Help app from Start and search for printer problems. It runs Microsoft's own automated checks, and fixes a good share of cases without you touching anything else.\",\"Turn the printer off at the wall for thirty seconds, then on again. This fixes a surprising share of cases.\",\"Check the cable is firmly in at both ends, or for a wireless printer, that it is on the same Wi-Fi as the computer — easy to miss after a router change. If your office has a Wi-Fi extender or more than one network name, the computer and the printer must be on the same one.\",\"If the printer itself shows an error, look at the printer before the computer: paper, ink or toner, an open cover, or a jam. Windows reports these as a printer error, not as what they are.\",\"Open Settings, then Bluetooth & devices, then Printers & scanners, and choose your printer. Select Open print queue, and cancel anything stuck (the ... menu, then Cancel all) — and resist clicking Print over and over, because each click adds another copy and buries the one you want. If the window has a Printer menu, make sure \\\"Use Printer Offline\\\" is not ticked; Windows can tick it on its own after a connection drops. Back in Printers & scanners, turn off \\\"Let Windows manage my default printer\\\", which makes whichever printer you used last the default, then choose yours and select Set as default.\",\"Print the printer's own test page from its buttons — many printers can also print a Wi-Fi test report from their menu. If that works, the printer is fine and the problem is on the computer.\",\"If jobs still will not move, restart the print service: search Start for Services, find Print Spooler in the list, right-click it and choose Restart. This only restarts it and deletes nothing. If Windows says you need permission, that is an administrator's job.\"],\"stop\":\"If it prints its own test page but nothing from the computer, it is a driver or network setting. Tell us the printer model and we will sort it, often without visiting. If Windows says the print spooler has stopped, call us rather than following online fixes for it — they involve stopping a Windows service and clearing files inside the Windows folder, which is easy to get wrong.\",\"service\":\"Printer & Scanner Setup\"},{\"match\":[\"virus\",\"malware\",\"hacked\",\"ransomware\",\"encrypted\",\"locked my files\",\"pop ups\",\"popups\",\"strange\",\"suspicious\",\"scam\",\"money gone\"],\"title\":\"Possible virus or attack\",\"answer\":\"If files have been encrypted or renamed and a payment is demanded, that is ransomware. What you do in the first hour matters more than anything else.\",\"try\":[\"Disconnect the machine from the network and Wi-Fi now. Do not plug in a flash drive or external disk.\",\"Do not pay anything and do not reply to any message demanding payment.\",\"Leave the machine on but disconnected, and do not delete anything — deleting can destroy the evidence and the chance of recovery.\",\"Write down what you saw and when. It helps more than people expect.\"],\"stop\":\"Call us straight away on 0971 013 108. Do not run cleanup tools you find online — several of them destroy any chance of getting the files back.\",\"service\":\"Cybersecurity\"},{\"match\":[\"lost files\",\"deleted\",\"recover\",\"recovery\",\"gone\",\"missing files\",\"formatted\",\"cant find my\",\"can't find my\",\"corrupt\",\"corrupted\",\"corruption\"],\"title\":\"Files are missing or deleted\",\"answer\":\"Deleted usually does not mean gone. It means the space is marked reusable — so the single most important thing is to stop writing anything new to that disk.\",\"try\":[\"Stop using the machine for anything else. Every minute of normal use lowers the chance of getting the files back.\",\"Check the Recycle Bin, and search the file name across the whole C: drive before assuming the worst.\",\"If the files were on a flash drive or camera card, take it out and leave it out.\",\"Do not install recovery software onto the same drive — installing it can overwrite the very files you want.\"],\"stop\":\"If the files matter, bring the machine or the drive to us before trying anything else. Recovery odds drop sharply with use.\",\"service\":\"Data Protection, Backup & Recovery\"},{\"match\":[\"password\",\"locked out\",\"forgot\",\"cant login\",\"can't login\",\"cant log in\",\"can't log in\",\"cannot log in\",\"account locked\",\"cannot sign in\",\"cant sign in\"],\"title\":\"Locked out of a computer or account\",\"answer\":\"What can be done depends on what kind of account it is. A Microsoft account can be reset by you; a local Windows account and a work account cannot be, in the same way.\",\"try\":[\"For a Microsoft account, use the official reset at account.microsoft.com from your phone.\",\"For work email, ask whoever administers it. If that is us, call and we will verify you and reset it.\",\"Check Caps Lock and the keyboard language — more lockouts come from this than anyone admits.\",\"Do not keep guessing. Many systems lock harder after repeated failures.\"],\"stop\":\"We will never ask for your password, and neither will Microsoft. Anyone who does is trying to take the account.\",\"service\":\"IT Training & Consultancy\"},{\"match\":[\"cctv\",\"camera\",\"cameras\",\"dvr\",\"nvr\",\"not recording\",\"no footage\",\"cant view\",\"can't view\",\"remote view\"],\"title\":\"CCTV not recording or not viewable\",\"answer\":\"Three usual causes: the recorder's disk is full or failing, the camera has lost power or its cable, or remote viewing has stopped because the internet address changed.\",\"try\":[\"Check the recorder is on and whether it shows any error on screen.\",\"See whether all cameras are affected or only one. One camera points to that camera or its cable; all of them points to the recorder.\",\"Check whether playback works locally even if remote viewing does not — that separates a recording fault from a network one.\",\"Note how far back footage goes. If it is much shorter than it used to be, the disk is probably failing.\"],\"stop\":\"If the footage is needed for an incident, stop and call us before anything else, so the recording is not overwritten. Recorders overwrite the oldest footage automatically.\",\"service\":\"CCTV Installation & Maintenance\"},{\"match\":[\"backup\",\"back up\",\"backups\",\"restore\",\"copy of my data\",\"protect my data\"],\"title\":\"Backups\",\"answer\":\"A backup nobody has ever restored from is not yet a backup. The useful test is simple: if this building burned tonight, what would you still have tomorrow morning?\",\"try\":[\"Write down what would actually hurt to lose. It is usually a much shorter list than people expect.\",\"Keep one copy somewhere other than the building. A drive beside the computer does not survive fire or theft.\",\"Try restoring one file. That is the only way to know a backup works.\",\"Check when it last ran. Backups fail quietly and can be dead for months.\"],\"stop\":\"We can set up a backup that runs on its own and gets checked, so you are not relying on remembering.\",\"service\":\"Data Protection, Backup & Recovery\"},{\"match\":[\"windows\",\"install\",\"reinstall\",\"activate\",\"licence\",\"license\",\"microsoft office\",\"ms office\",\"office 365\",\"office365\",\"excel\",\"microsoft word\",\"ms word\",\"word document\",\"update\",\"updates\",\"blue screen\",\"bsod\",\"error code\"],\"title\":\"Windows or software problem\",\"answer\":\"Software problems usually come with an error message, and that message is most of the answer. A blue screen in particular names the fault if you note the code.\",\"try\":[\"Write down the exact error, or photograph the screen. \\\"It says an error\\\" is hard to work with; the code is not.\",\"Note what you were doing when it happened, and whether it happens every time or now and then.\",\"Restart properly and see whether it recurs.\",\"If it started right after an update or a new program, say so — that is usually the cause.\"],\"stop\":\"Send us the error text or a photo. Most of these are diagnosed without touching the machine.\",\"service\":\"Windows & Software Installation\"},{\"match\":[\"website\",\"web site\",\"site down\",\"domain\",\"hosting\",\"email domain\",\"ssl\",\"https\"],\"title\":\"Website or domain\",\"answer\":\"A site that has stopped working is usually hosting, an expired domain, or an expired certificate. Each looks different in the browser.\",\"try\":[\"Note exactly what the browser says — \\\"not secure\\\", \\\"cannot be reached\\\" and \\\"404\\\" mean quite different things.\",\"Check whether it fails on mobile data as well as on Wi-Fi.\",\"Check whether the domain is still paid up. An expired domain takes a site down completely.\"],\"stop\":\"Tell us the address and what you see. We can check hosting, domain and certificate from here.\",\"service\":\"Website Design & Development\"},{\"match\":[\"shuts down\",\"shutting down\",\"shut down by itself\",\"shuts off\",\"shutting off\",\"turns off\",\"turning off\",\"switches off\",\"switching off\",\"restarts by itself\",\"=keeps restarting\",\"overheating\",\"overheat\",\"too hot\",\"very hot\",\"fan loud\",\"fan noise\",\"loud fan\",\"burning smell\"],\"title\":\"Computer shuts down by itself or runs hot\",\"answer\":\"A machine that switches itself off without warning is usually protecting itself from heat. Dust blocks the fan and vents, the processor gets too hot, and the computer cuts out before damage is done. The other common cause is a failing power supply.\",\"try\":[\"Feel the vents while it runs. Very hot air, or no air at all, points to blocked cooling.\",\"Keep laptops on a hard, flat surface. A bed or cushion blocks the vents underneath.\",\"Note whether it shuts down under load — a big spreadsheet, a video — or at random. Under load points to heat; at random points to power.\",\"Keep it out of direct sun and away from a window in the afternoon.\"],\"stop\":\"Do not open a laptop to clean it yourself — fan cleaning is quick for us and easy to get wrong. If you smell burning, unplug it and stop using it.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"keyboard\",\"mouse\",\"usb\",\"flash drive not showing\",\"not detected\",\"not recognised\",\"not recognized\",\"monitor\",\"no signal\",\"second screen\",\"hdmi\",\"webcam\",\"headset\",\"speakers\",\"no sound\",\"external hard drive\",\"external drive\",\"external disk\",\"hard drive not showing\",\"drive not showing\",\"projector\",\"extend display\",\"duplicate display\",\"two screens\",\"dual monitor\"],\"title\":\"Keyboard, mouse, screen or USB device not working\",\"answer\":\"When a device stops working the fault is far more often the cable, the port or the driver than the device itself — and all three are quick to rule out.\",\"try\":[\"Unplug it and plug it into a different port. Ports fail more often than the things plugged into them.\",\"Try the device on another computer. If it works there, the problem is with the first machine.\",\"For a screen showing \\\"no signal\\\", check the cable is pushed fully home at both ends and the screen is set to the right input.\",\"For wireless keyboards and mice, change the batteries first — it is the most common cause by a wide margin.\",\"Restart the computer after reconnecting, so Windows looks for the device afresh.\"],\"stop\":\"If Windows says a drive \\\"needs to be formatted before you can use it\\\", click Cancel. Do not click Format — it erases everything on the drive, and that message often appears when the drive is fine and only its index is damaged. Bring it to us. The same goes for any flash drive or external disk holding files that matter: stop trying it in different machines, because repeated attempts make recovery harder.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"connected but no internet\",\"some websites\",\"website not loading\",\"sites not loading\",\"cannot open the webpage\",\"cannot open webpage\",\"cant open webpage\",\"cant open website\",\"cannot open website\",\"webpage not opening\",\"page not opening\",\"page wont open\",\"page won't open\",\"webpage wont load\",\"cannot open the page\",\"browser not loading\",\"page cannot be displayed\",\"dns\",\"ip conflict\",\"ip address conflict\",\"limited connectivity\",\"no internet access\"],\"title\":\"Connected, but some or all websites will not load\",\"answer\":\"If the Wi-Fi shows connected but pages will not open, the connection to the router is fine and the problem is further along — often the router has lost its link to your provider, or two devices have ended up with the same address on the network.\",\"try\":[\"Check whether other devices on the same network can open websites. If none can, it is the router or the line.\",\"Restart the router: off at the wall, wait thirty seconds, on again, and give it three minutes.\",\"If only some websites fail, try the same site on mobile data. If it opens there, the problem is on your network, not the website.\",\"On the one affected computer, turn Wi-Fi off and on again, so it asks the router for a fresh address.\",\"Check you are on the network you think you are. It is easy to be on a guest network, a neighbour's, or your phone's hotspot, and some sites only open from the office network.\",\"If you use a VPN, disconnect it and try again — a VPN that is misbehaving can block sites while showing connected.\",\"Open the same page in a private window (Ctrl+Shift+N in Chrome and Edge). If it loads there, a browser extension such as an ad or pop-up blocker is stopping it — turn extensions off one at a time to find which.\",\"Try the page in a private window (Ctrl+Shift+N in Chrome or Edge). Private windows switch off most browser add-ons, so if the page opens there, an add-on is blocking it.\",\"If a site needs a pop-up to work, allow pop-ups for that one site from the icon in the address bar, rather than switching the pop-up blocker off for everything.\"],\"stop\":\"Two things not to do. Do not switch off your antivirus to reach a website — a site or download that asks you to is a warning sign, and it is a favourite line of scammers. And in an office, do not change the network adapter or DNS settings: they may have been set deliberately, and changing them can cut the computer off from the server and shared drives. If it keeps happening, the network needs looking at properly — a quick job for us.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"power cut\",\"power outage\",\"load shedding\",\"loadshedding\",\"load-shedding\",\"zesco\",\"surge\",\"power surge\",\"lightning\",\"ups\",\"inverter\",\"power keeps going\",\"electricity\",\"after the power\"],\"title\":\"Power cuts and protecting equipment\",\"answer\":\"Power going off mid-use, and surging back when it returns, is one of the commonest causes of dead power supplies and corrupted files in Zambia. The surge on restoration does more harm than the cut itself.\",\"try\":[\"Save your work often during load-shedding hours. Windows can lose whatever was open when power drops.\",\"When power goes off, switch equipment off at the wall. Turn it back on a minute or two after power returns, once it has settled.\",\"Plug computers and routers into a surge protector, not straight into the wall. A multiplug is not a surge protector unless it says so.\",\"For a desktop, a server or a CCTV recorder, a UPS gives enough time to shut down properly instead of losing power mid-write.\"],\"stop\":\"If a machine will not start after a power cut, do not keep switching it on and off. A damaged power supply can take other parts with it. Call us.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"upgrade\",\"=should i buy\",\"buy a new\",\"new computer\",\"new laptop\",\"=which laptop\",\"buying a laptop\",\"buying a computer\",\"replace my computer\",\"ssd\",\"hard drive or ssd\",\"more ram\",\"add ram\",\"memory upgrade\",\"worth repairing\",\"worth fixing\",\"old computer\"],\"title\":\"Should I upgrade, repair or replace?\",\"answer\":\"For most office computers a few years old, the single biggest improvement is replacing the old spinning hard drive with a solid-state drive. It often makes a machine feel new for a fraction of the price of one. More memory helps next, if you work with many programs or browser tabs at once.\",\"try\":[\"Check what drive it has: open Task Manager (Ctrl+Shift+Esc), choose Performance, and look under Disk — it says SSD or HDD.\",\"Check its memory in Settings, then System, then About. Under 8 GB is tight for modern office work.\",\"Note its age. A solid-state drive rescues a slow machine; it cannot rescue one that is failing for other reasons.\",\"Write down what you actually use it for. The right answer depends far more on that than on the specifications.\"],\"stop\":\"Tell us the model and what you use it for, and we will tell you honestly whether an upgrade is worth it or whether the money is better put towards a replacement. We move your files and programs across either way.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"secure my\",\"securing\",\"secure the network\",\"secure my wifi\",\"wifi password\",\"router password\",\"guest wifi\",\"guest network\",\"=who is on my wifi\",\"protect my network\",\"network security\",\"someone using my wifi\",\"using my wifi\",\"=on my wifi\",\"stealing my wifi\",\"stealing wifi\",\"hack my wifi\",\"hacked my wifi\"],\"title\":\"Securing an office or home network\",\"answer\":\"Most small networks are exposed by a handful of defaults that were never changed. Closing those takes an afternoon and removes most of the everyday risk.\",\"try\":[\"Change the router's admin password from the one printed on its sticker. Anyone who reads the sticker can change your settings.\",\"Use the strongest Wi-Fi security the router offers — WPA3, or WPA2 if that is the best available — and a long Wi-Fi password.\",\"Put visitors on a separate guest network, so their phones never share a network with your office machines.\",\"Turn on two-step sign-in for email and any account that handles money.\",\"Keep the router's own software up to date — it gets security fixes like anything else. But never start a router update during load-shedding hours or on unsteady power: if the power cuts mid-update, the router can be left permanently unusable. If in doubt, have us do it.\"],\"stop\":\"If you handle client records, personal data or money, the basics are a start rather than enough. We can set up proper separation and monitoring.\",\"service\":\"Cybersecurity\"},{\"match\":[\"wired or wireless\",\"cable or wifi\",\"cable or wi-fi\",\"ethernet\",\"network cable\",\"should i use wifi\",\"lan cable\",\"wifi or cable\"],\"title\":\"Wired or Wi-Fi for my office?\",\"answer\":\"Usually both. Cable is faster, steadier and harder to intrude on; Wi-Fi is convenient where people move around. The sensible split is by what the device does.\",\"try\":[\"Cable anything that stays put and matters: desktops, printers, the CCTV recorder, and any server.\",\"Use Wi-Fi for laptops, phones, visitors and meeting rooms.\",\"If a room has poor Wi-Fi, an access point placed there beats turning the router up — a stronger signal from one spot rarely reaches round corners.\",\"Keep network cables away from mains power cables where you can, and do not staple through them.\"],\"stop\":\"Cabling an office properly is worth doing once. We can survey the space and recommend the fewest cable runs and access points that will cover it.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"maintenance\",\"look after\",\"looking after\",\"take care of\",\"=keep my computer\",\"regular service\",\"servicing\",\"prevent problems\",\"=how often\",\"clean my computer\"],\"title\":\"Looking after your computers\",\"answer\":\"Most failures give warning, and a little routine care catches them early. The aim is not perfection — it is not being surprised.\",\"try\":[\"Let Windows and your programs install their updates. Most attacks rely on machines that never updated.\",\"Keep vents clear and the machine off soft surfaces. In a dusty season, have the fans cleaned once or twice a year.\",\"Watch for early warnings: new noises from the drive, sudden slowness, or programs crashing that never used to.\",\"Back up what matters, and keep one copy away from the building.\",\"Retire machines that no longer get security updates. They are the easiest way in for an attacker.\"],\"stop\":\"We offer regular servicing for offices, so this happens on a schedule rather than when someone remembers.\",\"service\":\"IT Training & Consultancy\"},{\"match\":[\"phishing\",\"suspicious email\",\"strange email\",\"fake email\",\"scam email\",\"clicked a link\",\"clicked the link\",\"opened an attachment\",\"email asking\",\"asking for my password\",\"urgent email\",\"email from the bank\",\"bank email\",\"verify my account\"],\"title\":\"A suspicious email or message\",\"answer\":\"Emails that create urgency — your account will close, a payment failed, verify now — are the commonest way businesses are broken into. They rarely look suspicious at first glance; that is the point of them.\",\"try\":[\"Do not click the link or open the attachment. If you already have, that is fine — it happens to everyone — but tell us now rather than later.\",\"Check the actual sender address, not the name shown. A bank does not write from a free email address.\",\"If it claims to be from your bank, Airtel, MTN or a supplier, contact them using a number you already have — never one in the message.\",\"If you typed a password after clicking, change that password straight away from a different device.\"],\"stop\":\"If you clicked and then entered a password or payment details, call us immediately. The first hour matters, and there is no embarrassment in it.\",\"service\":\"Cybersecurity\"},{\"match\":[\"did not save\",\"didnt save\",\"didn't save\",\"not saved\",\"unsaved\",\"lost my work\",\"lost my document\",\"closed without saving\",\"word crashed\",\"excel crashed\",\"document disappeared\",\"forgot to save\"],\"title\":\"Lost work that was not saved\",\"answer\":\"Office programs keep hidden recovery copies while you work, so work that was never saved is often still there. The sooner you look, the better the odds.\",\"try\":[\"Reopen the same program. It often offers the recovered file on the left as soon as it starts.\",\"In Word or Excel, go to File, then Info, then Manage Document, then Recover Unsaved Documents.\",\"Do not start lots of new work in that program first. Recovery copies can be replaced.\",\"For the future, save to OneDrive or turn on AutoSave, so this cannot happen the same way twice.\"],\"stop\":\"If recovery shows nothing and the document matters, stop and call us before using the computer much more.\",\"service\":\"Data Protection, Backup & Recovery\"},{\"match\":[\"disk full\",\"disk is full\",\"low disk space\",\"no space\",\"out of space\",\"storage full\",\"c drive full\",\"c: drive full\",\"drive is full\",\"running out of space\",\"not enough space\"],\"title\":\"Disk full or low on space\",\"answer\":\"A nearly full drive slows everything down and stops updates installing. Windows has its own tool that clears space safely, which is far better than choosing files to delete by hand.\",\"try\":[\"Search Windows for \\\"Disk Cleanup\\\", pick the C: drive, and let it remove temporary files. It will not touch your documents.\",\"Empty the Recycle Bin — but check it first for anything you still need.\",\"Look in your Downloads folder. It is usually the largest thing people have forgotten about.\",\"Move old photos and videos to an external drive or cloud storage rather than deleting them.\"],\"stop\":\"Please do not delete files from Windows, Program Files or anything you do not recognise. If space is still short after the steps above, we can find what is using it safely.\",\"service\":\"Computer Repair & Maintenance\"},{\"match\":[\"program wont open\",\"program won't open\",\"app wont open\",\"app won't open\",\"not opening\",\"keeps crashing\",\"crashes\",\"crashing\",\"stopped working\",\"not responding\",\"wont install\",\"won't install\",\"cannot install\",\"cant install\",\"install failed\"],\"title\":\"A program will not open, crashes or will not install\",\"answer\":\"Usually the program is out of date, is clashing with something else, or needs more than the computer has. The error message, if there is one, tells us which.\",\"try\":[\"Restart the computer properly, then try the program before opening anything else.\",\"Check for an update to the program itself — many crashes are fixed in a later version.\",\"Note exactly when it fails: on opening, on a particular action, or at random.\",\"If it will not install, check it is meant for your version of Windows, and that there is space on the drive.\"],\"stop\":\"Send us the exact error message or a photo of it. For accounting or business software holding your records, do not uninstall it to try again without talking to us first.\",\"service\":\"Windows & Software Installation\"},{\"match\":[\"update failed\",\"updates failed\",\"update failing\",\"updates failing\",\"update stuck\",\"stuck updating\",\"updating for hours\",\"update keeps failing\",\"cannot update\",\"wont update\",\"won't update\",\"update error\",\"working on updates\"],\"title\":\"Windows updates failing or stuck\",\"answer\":\"Updates most often fail from a full drive or a connection that dropped mid-download. A screen saying it is working on updates can genuinely take a long time on an older machine.\",\"try\":[\"If it is on a \\\"working on updates\\\" screen, leave it — even for an hour or two. Switching off during an update is how machines end up unable to start.\",\"Check there is free space on the C: drive; updates need room to unpack.\",\"Make sure the connection is steady. Large updates over a weak or metered connection often fail part-way.\",\"Restart normally and let Windows try again. It frequently succeeds second time.\"],\"stop\":\"If it has sat unchanged on an update screen for several hours, or restarts into the same failure again and again, call us rather than switching it off repeatedly.\",\"service\":\"Windows & Software Installation\"},{\"match\":[\"stolen\",\"lost my phone\",\"lost my laptop\",\"phone stolen\",\"laptop stolen\",\"lost phone\",\"lost laptop\",\"left my laptop\",\"cannot find my phone\",\"device stolen\"],\"title\":\"Lost or stolen phone or laptop\",\"answer\":\"The device can be replaced. What matters in the first hours is what someone else can now reach from it — email, banking, and anything that sends login codes to it.\",\"try\":[\"Use Find My Device (Android) or Find My (Apple) from another device to locate it, lock it, and erase it remotely if you will not get it back.\",\"Change your email password first, then banking and anything else that was signed in.\",\"Call Airtel, MTN or Zamtel to block the SIM, so nobody can receive your login codes.\",\"Report it to the police and keep the reference — you will need it for insurance.\"],\"stop\":\"If it held work email or client records, tell us straight away. We can sign it out of company accounts remotely.\",\"service\":\"Cybersecurity\"},{\"match\":[\"paper jam\",\"paper jammed\",\"jammed\",\"no colour\",\"no color\",\"colour\",\"color\",\"printing colour\",\"printing color\",\"not printing colour\",\"not printing color\",\"black and white only\",\"wrong size\",\"wrong paper size\",\"print queue\",\"stuck in the queue\",\"prints blank\",\"blank pages\",\"printing faded\",\"streaks\"],\"title\":\"Printing, but printing wrongly\",\"answer\":\"When a printer works but the result is wrong, the cause is nearly always a setting or the consumables — ink, toner or paper — rather than a fault.\",\"try\":[\"For a jam, switch the printer off first, then pull the paper out slowly in the direction it normally travels. Tearing it leaves pieces inside.\",\"For no colour, check the print settings are not set to greyscale, and check the colour ink or toner level.\",\"For the wrong size, make sure the paper size chosen when printing matches what is actually in the tray.\",\"For jobs stuck in the queue, open the print queue, cancel them all, and send the document again.\"],\"stop\":\"If paper tears inside and you cannot see the pieces, stop there — pulling at hidden paper can damage the rollers.\",\"service\":\"Printer & Scanner Setup\"},{\"match\":[\"shared folder\",\"shared drive\",\"network drive\",\"mapped drive\",\"cannot access the server\",\"cant access the server\",\"server not accessible\",\"access denied\",\"shared printer\",\"cannot see the other computer\",\"network share\"],\"title\":\"Cannot open a shared folder or network drive\",\"answer\":\"Shared folders depend on three things lining up: the computer holding the files is on, both machines are on the same network, and your account is allowed in.\",\"try\":[\"Check the computer or server holding the files is switched on and awake.\",\"Check your computer is on the office network, not a phone hotspot or guest Wi-Fi.\",\"Restart your computer and sign in again — the connection is often re-made at sign-in.\",\"If it says access is denied, the folder is reachable but your account is not permitted. That needs whoever manages the shares.\"],\"stop\":\"If it affects everyone in the office at once, the problem is the server or the network rather than any one computer. Call us.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"email\",\"emails\",\"e-mail\",\"outlook\",\"not receiving emails\",\"not sending emails\",\"email not sending\",\"email not working\",\"emails not coming\",\"cannot send email\",\"cant send email\",\"wont send\",\"will not send\",\"not sending\",\"outlook not syncing\",\"email not syncing\",\"mail not syncing\",\"emails not syncing\",\"mailbox full\",\"inbox full\",\"stuck in outbox\",\"outbox\"],\"title\":\"Email not sending, receiving or syncing\",\"answer\":\"Email failures are rarely the mail server. Most come from a changed or expired password, a full mailbox, or a connection that dropped — all quick to rule out.\",\"try\":[\"Check you can open a website. If not, it is the connection, not the email.\",\"Sign in to the same mailbox on your phone or in a web browser. If mail is there, the account is fine and the problem is the app on this computer.\",\"If you changed your password recently, Outlook may still be using the old one. Close it fully and reopen it; it should ask again.\",\"Check whether the mailbox is full — a full mailbox stops new mail arriving without much warning. Empty Deleted Items and move old mail with large attachments out.\",\"For a message stuck in the Outbox, check its attachments. Very large files are the usual reason a message refuses to leave.\"],\"stop\":\"Please do not remove the email account or the Outlook profile to \\\"start again\\\" without talking to us. On some setups your stored mail lives only on that computer, and removing the account can make it look as though it has all gone.\",\"service\":\"IT Training & Consultancy\"},{\"match\":[\"vpn\",\"vpn connected\",\"vpn not working\",\"vpn connected but no internet\",\"vpn wont connect\",\"vpn won't connect\",\"remote access\",\"work from home connection\"],\"title\":\"VPN connected, but nothing works\",\"answer\":\"When the VPN says connected but websites or work systems will not open, the tunnel is up but traffic is being sent the wrong way through it. That is a configuration matter rather than something you have done.\",\"try\":[\"Disconnect the VPN and check the internet works without it. If it does not, the problem is your connection, not the VPN.\",\"Reconnect once, cleanly. If it works for a while and then fails again, note roughly how long it lasts.\",\"Try a different connection — a phone hotspot is the quickest test. Some public and hotel Wi-Fi blocks VPNs.\"],\"stop\":\"If it fails again after one clean reconnect, the settings need looking at. Repeated reconnecting will not fix a routing problem — send us what you see.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"where do i start\",\"how do i troubleshoot\",\"how to troubleshoot\",\"troubleshooting steps\",\"basic troubleshooting\",\"general troubleshooting\",\"first thing to check\",\"what should i check first\",\"what to check first\",\"something is wrong with my computer\"],\"title\":\"Where to start with any problem\",\"answer\":\"Look before you click. When something breaks, the instinct is to restart it repeatedly or click things in a hurry, and that sometimes makes it worse. A minute spent noticing saves an hour of guessing.\",\"try\":[\"Ask what changed. A new program, an update, a moved cable or a power cut shortly before is very often the whole explanation.\",\"Ask whether it is one device or several. One device points to that device; several at once point to the network, the power or a shared service.\",\"Read the error message in full, and photograph it. It usually names the problem.\",\"Check the simple things before the complicated ones: power, cables, the internet connection.\",\"Restart once, properly. If it comes back, stop restarting — note what happens instead.\"],\"stop\":\"If you have been through these and it is still not clear, describe what you found and send it to us. Those notes make a fix much quicker.\",\"service\":\"IT Training & Consultancy\"},{\"match\":[\"=do i need it support\",\"=do we need it support\",\"=should i get it support\",\"=should we get it support\",\"support contract\",\"it support contract\",\"monthly support\",\"retainer\",\"=managed it\",\"managed services\",\"keeps happening again\",\"problems keep coming back\",\"same problem again\",\"=how much does it support cost\"],\"title\":\"Do we need regular IT support?\",\"answer\":\"Not every business does. But a few signs usually mean fixing things as they break is costing more than it looks — in lost hours rather than invoices.\",\"try\":[\"Problems come back every month or so, or a \\\"fix\\\" never quite holds.\",\"Someone in the office spends part of every week on IT instead of their own job.\",\"Security warnings, pop-ups or odd emails keep appearing.\",\"Nobody is sure whether backups are actually working.\",\"The whole business stops if one particular computer or the internet goes down.\"],\"stop\":\"If two or more of those sound familiar, a monthly arrangement is usually cheaper than emergency call-outs. We are happy to look at your setup and tell you honestly which suits you — including if you do not need us regularly.\",\"service\":\"IT Training & Consultancy\"},{\"match\":[\"find a wireless network\",\"find wireless network\",\"find any wifi\",\"find the wifi\",\"no wifi networks\",\"no wireless networks\",\"no networks available\",\"no networks\",\"wifi not showing\",\"wireless not showing\",\"wifi option missing\",\"wifi icon missing\",\"wifi disappeared\",\"wifi turned off\",\"wireless turned off\",\"wifi is off\",\"airplane mode\",\"aeroplane mode\",\"flight mode\",\"cannot see wifi\",\"cant see wifi\",\"cannot see the wifi\",\"no wifi option\",\"wifi button\",\"cannot find wifi\",\"cant find wifi\",\"can't find wifi\",\"cannot find wireless\",\"cant find wireless\",\"cannot find a wireless network\",\"no networks showing\",\"wifi networks not showing\",\"wifi missing\",\"wifi option gone\",\"no wifi icon\",\"cannot see any wifi\",\"cant see any wifi\",\"cannot see my wifi\",\"cant see my wifi\"],\"title\":\"Cannot see any Wi-Fi networks\",\"answer\":\"If the computer shows no networks at all while phones in the same room can see them, the computer's own Wi-Fi is almost always switched off — by a setting, a key or a switch. It is rarely broken.\",\"try\":[\"Check airplane mode is off. Click the network, sound and battery icons at the bottom right; airplane mode appears there, and it switches Wi-Fi off with it.\",\"In the same panel, check the Wi-Fi button itself is on.\",\"Many laptops have a key that turns wireless on and off — often marked with an aerial or a plane symbol, sometimes used with the Fn key. Older laptops may have a small physical switch on the side or front.\",\"Check the adapter itself is enabled: Settings, then Network & internet, then Advanced network settings. If Wi-Fi is listed as disabled, enable it.\",\"Restart the computer. If Wi-Fi was turned off in a way Windows did not register, this usually brings it back.\",\"Check a phone can see the network from the same spot. If the phone cannot either — or you can see other people's networks but not your own — the problem is the router, not this computer.\"],\"stop\":\"If there is still no Wi-Fi option at all after a restart — not just no networks, but no Wi-Fi setting anywhere — the wireless card may have been disabled or failed. That is quick for us to check.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"add a printer\",\"add printer\",\"adding a printer\",\"install a printer\",\"install printer\",\"installing a printer\",\"new printer\",\"set up printer\",\"set up a printer\",\"setup printer\",\"printer setup\",\"connect printer\",\"connect a printer\",\"connect the printer\",\"reinstall printer\",\"reinstall the printer\",\"remove printer\",\"printer driver\",\"printer drivers\",\"driver for my printer\",\"printer not found\",\"printer is not found\",\"printer is not recognised\",\"printer is not recognized\",\"printer is not detected\",\"printer is not showing\",\"printer not recognised\",\"printer not recognized\",\"printer not detected\",\"cannot find printer\",\"cant find printer\",\"printer not showing\"],\"title\":\"Adding a printer, or reinstalling one\",\"answer\":\"Windows finds most printers by itself once they are switched on and connected. If a printer has been misbehaving, removing it and adding it again is safe — nothing you have printed or saved is lost — and it clears a lot of stubborn problems.\",\"try\":[\"Make sure the printer is on and connected: by cable, or on the same Wi-Fi as the computer. Many wireless printers have a button with a blue wireless light that must be on, and a menu option that tests the wireless connection.\",\"Open Settings, then Bluetooth & devices, then Printers & scanners, and choose Add device. Give Windows a minute to look, then pick your printer from the list.\",\"If it is not listed, choose Add manually and follow the option that fits how the printer is connected.\",\"To reinstall one that is misbehaving, select it in Printers & scanners, choose Remove, then Add device again.\",\"If it needs a driver, get it only from the printer maker's own website, for your exact model. Do not use \\\"driver updater\\\" programs or download sites from search adverts — they are a common way malware gets in.\",\"Print a test page to confirm it works.\"],\"stop\":\"If Windows still cannot find it, tell us the make and model and whether it connects by cable or Wi-Fi. Printer setup is often something we can finish remotely.\",\"service\":\"Printer & Scanner Setup\"},{\"match\":[\"ipconfig\",\"ping\",\"tracert\",\"nslookup\",\"netstat\",\"arp\",\"getmac\",\"hostname\",\"flushdns\",\"flush dns\",\"command prompt\",\"cmd\",\"cmd commands\",\"network commands\",\"networking commands\",\"test my connection\",\"check my connection\",\"test the connection\",\"my ip address\",\"what is my ip\",\"ip address\",\"mac address\",\"computer name\",\"default gateway\",\"169.254\"],\"title\":\"Checking your connection with a few simple commands\",\"answer\":\"A few commands tell you in seconds whether a problem is this computer, the router, or the internet itself. They only read information — none of them change anything. Open them by searching Start for \\\"cmd\\\" and choosing Command Prompt.\",\"try\":[\"Type  ping 8.8.8.8  and press Enter. Lines starting \\\"Reply from\\\" mean you are reaching the internet. \\\"Request timed out\\\" means you are not.\",\"Then type  ping google.com . If 8.8.8.8 replied but this says it \\\"could not find host\\\", the internet works and only the name lookup is failing.\",\"For a name-lookup failure, type  ipconfig /flushdns  and try the website again. It clears out old lookups and is completely safe.\",\"Type  ipconfig  and look for \\\"IPv4 Address\\\". If it starts with 169.254, the computer never got an address from the router — restart the router.\",\"In the same output, \\\"Default Gateway\\\" is your router. Type  ping  followed by that number: if it does not reply, the problem is between you and the router.\",\"If we ask which computer you are on, type  hostname  and tell us what it shows.\"],\"stop\":\"Commands such as tracert, nslookup, netstat and arp produce output that is hard to read — run them only if we ask, and send us a photo of the screen. And if anyone who called you out of the blue asks you to open Command Prompt, stop: that is a scam.\",\"service\":\"Networking & Wi-Fi Setup\"},{\"match\":[\"microsoft called\",\"call from microsoft\",\"called from microsoft\",\"someone called me\",\"tech support call\",\"tech support scam\",\"scam call\",\"support scam\",\"said my computer is hacked\",\"said my computer has a virus\",\"said my computer was hacked\",\"anydesk\",\"teamviewer\",\"ultraviewer\",\"asked for remote access\",\"wanted remote access\",\"gave them remote access\",\"gave remote access\",\"asked me to install\",\"asked me to open cmd\",\"told me to open cmd\",\"told me to run\",\"pop up says call\",\"popup says call\",\"call this number\",\"support number on screen\"],\"title\":\"Someone called or messaged saying your computer has a problem\",\"answer\":\"Microsoft, your bank and your internet provider do not call or message out of the blue to fix your computer. A caller who says they have detected a virus or a hack is running a scam. The usual script is to have you open Command Prompt or Event Viewer, point at perfectly normal output as \\\"proof\\\", then get you to install a remote-access app such as AnyDesk so they can reach your bank or mobile money.\",\"try\":[\"Hang up, or stop replying. You do not need to be polite, and you do not need to argue.\",\"Do not install anything they ask for, and do not read out any code or PIN you are sent.\",\"A pop-up saying your computer is locked and to call a number is part of the same scam. Close the browser — if it will not close, restart the computer. Do not call the number.\",\"If you have already let them in, disconnect from the internet now, and do not sign in to banking or mobile money on that computer.\",\"From a different phone or computer, change your email and banking passwords, and tell your bank and your mobile money provider what happened.\"],\"stop\":\"If they had remote access, even briefly, call us straight away on 0971 013 108. We will check what was installed and remove it. There is no shame in it — these callers are practised, and they target careful people too.\",\"service\":\"Cybersecurity\"},{\"match\":[\"ransom note\",\"ransom demand\",\"files encrypted\",\"encrypted files\",\"file extension changed\",\"all files renamed\",\"bitcoin ransom\",\"pay ransom\",\"ransomware attack\"],\"title\":\"Ransomware or encrypted files\",\"answer\":\"This is an urgent security incident. The priority is stopping it spreading and preserving evidence—not trying random cleanup tools.\",\"try\":[\"Disconnect affected computers from Wi-Fi and unplug their network cables immediately.\",\"If several machines are affected, disconnect shared storage and contact Avesta from a phone or other trusted device.\",\"Photograph the ransom note and record when the first signs appeared. Keep the affected device isolated but powered on unless there is smoke, heat or another physical danger.\",\"Keep backup drives disconnected. Do not test them on an affected computer.\"],\"stop\":\"Do not pay, delete files, reinstall Windows, format disks, run online decryptors, or restore backups yet. WhatsApp Avesta urgently on 0971 013 108 so evidence and recoverable data are protected.\",\"service\":\"Cybersecurity Incident Response\"},{\"match\":[\"account hacked\",\"email hacked\",\"account compromised\",\"someone logged in\",\"unknown login\",\"password changed by someone\",\"mfa changed\",\"two factor changed\",\"verification codes arriving\",\"account takeover\",\"cannot access my email\"],\"title\":\"Account or email may be taken over\",\"answer\":\"Treat unexpected sign-ins, password changes or verification codes as an account takeover until proven otherwise—especially for email, banking or administrator accounts.\",\"try\":[\"Use a different trusted device and the provider's official app or website—not a link in a message.\",\"Change the password and every other account using that same password.\",\"Use the account's security page to sign out other sessions, remove unknown devices and check whether recovery email, phone or forwarding rules changed.\",\"Turn on two-step verification after regaining control, and save recovery codes somewhere private and offline.\"],\"stop\":\"If you are locked out, an administrator or financial account is involved, or recovery details were changed, contact the provider and Avesta immediately on 0971 013 108. Never send us your password or verification code.\",\"service\":\"Cybersecurity Incident Response\"},{\"match\":[\"invoice fraud\",\"payment details changed\",\"supplier bank changed\",\"boss asked for money\",\"ceo fraud\",\"business email compromise\",\"bec\",\"fraudulent transfer\",\"wrong account payment\",\"mobile money fraud\",\"sent money to scammer\"],\"title\":\"Payment fraud or business email compromise\",\"answer\":\"A sudden email request to change payment details may mean a mailbox has been compromised. This is a same-hour emergency.\",\"try\":[\"Do not send or approve another payment from the email instructions.\",\"Verify the request using a phone number you already know, not a number in the message.\",\"If money was sent, call the bank or mobile-money provider immediately using its official number and ask whether the transfer can be stopped or recalled.\",\"Preserve the emails, headers, payment records and times; do not delete the conversation.\"],\"stop\":\"Contact Avesta urgently on 0971 013 108 from a separate channel. Do not reply to the suspicious mailbox or warn the attacker through it.\",\"service\":\"Cybersecurity Incident Response\"},{\"match\":[\"data breach\",\"data leaked\",\"customer data exposed\",\"information stolen\",\"database hacked\",\"database breach\",\"records exposed\",\"files exfiltrated\",\"personal information exposed\",\"unauthorized data access\"],\"title\":\"Possible data breach\",\"answer\":\"Possible exposure of customer, employee, payment or business data needs immediate containment and a careful record of what happened.\",\"try\":[\"Disconnect the affected device or service only if that safely stops ongoing access.\",\"Preserve logs, alerts, screenshots and times. Write down what data may be involved and who first noticed it.\",\"Use a clean phone or computer to alert the business owner and Avesta.\",\"Keep the incident private until the responsible people can assess legal and customer-notification duties.\"],\"stop\":\"Do not delete logs, wipe systems, contact the suspected attacker, or announce that the breach is resolved. WhatsApp Avesta urgently on 0971 013 108.\",\"service\":\"Cybersecurity Incident Response\"},{\"match\":[\"website hacked\",\"site hacked\",\"website defaced\",\"strange page on website\",\"seo spam\",\"unknown admin website\",\"malicious redirect\",\"website redirecting\",\"site sending spam\",\"ddos\",\"denial of service\",\"traffic attack\",\"site overloaded\"],\"title\":\"Hacked website or denial-of-service attack\",\"answer\":\"Defacement, unfamiliar administrators or redirects suggest compromise; a sudden flood of traffic may be a denial-of-service attack. Both need hosting-level checks.\",\"try\":[\"Take screenshots and note when it started, what changed recently and whether administrators can still sign in.\",\"Contact the hosting provider through its official support channel and ask it to preserve access and security logs.\",\"For an overload, enable the host's built-in protection if it is already available; otherwise wait for the host or Avesta rather than changing server settings blindly.\",\"Keep known-clean backups untouched until their dates and contents can be checked.\"],\"stop\":\"Do not retaliate, try to trace attackers, delete unknown files, install random security plugins, or restore an unverified backup over the site. Contact Avesta on 0971 013 108.\",\"service\":\"Website Security & Recovery\"},{\"match\":[\"cctv hacked\",\"camera hacked\",\"unknown cctv login\",\"camera moved by itself\",\"cameras accessed\",\"recorder hacked\",\"dvr hacked\",\"nvr hacked\",\"footage deleted\",\"footage missing\",\"security camera breach\"],\"title\":\"CCTV access or footage may be compromised\",\"answer\":\"Unexpected camera movement, unknown logins or missing footage can affect both security and evidence. Preserve what remains before changing settings.\",\"try\":[\"Do not disable recording. Photograph the recorder screen and note which cameras and times are affected.\",\"If footage relates to an incident, export the relevant period to clean storage using the recorder's normal export function if you already know how.\",\"Disconnect remote internet access only if local recording will continue; do not unplug the recorder unless there is a physical danger.\",\"From a trusted device, check the vendor account for unfamiliar users or sessions without sharing any credentials in chat.\"],\"stop\":\"Do not factory-reset the recorder, expose its admin page to the internet, or delete users/logs before review. Contact Avesta promptly on 0971 013 108.\",\"service\":\"CCTV Security & Recovery\"},{\"match\":[\"android app problem\",\"iphone app problem\",\"phone app crashes\",\"mobile app crashes\",\"app permissions\",\"app draining battery\",\"phone has virus\",\"android virus\",\"iphone virus\",\"phone popups\",\"phone overheating\"],\"title\":\"Phone or mobile app problem\",\"answer\":\"Mobile app faults usually come from an outdated app, low storage or a permission problem; repeated pop-ups or unknown apps may indicate unwanted software.\",\"try\":[\"Restart the phone, then update the app and the phone through the official App Store, Play Store or system settings.\",\"Check free storage and remove only files or apps you recognize and no longer need.\",\"Review the app's permissions and remove access it does not need, especially accessibility, device administration, SMS and microphone access.\",\"If pop-ups started after installing an app, disconnect from the internet and note that app's name for a technician.\"],\"stop\":\"Do not install a cleaner or antivirus from a pop-up, and do not factory-reset a phone holding important data before backup and review. For heat, swelling or a damaged battery, stop charging and move away from the device.\",\"service\":\"Mobile Device Support\"},{\"match\":[\"database error\",\"database down\",\"cannot connect database\",\"database connection failed\",\"too many connections\",\"database slow\",\"database locked\",\"sql error\",\"data missing database\",\"app server down\",\"application server\"],\"title\":\"Database or business application unavailable\",\"answer\":\"A database error can come from the network, a stopped service, full storage or exhausted connections. Business data makes guesswork risky.\",\"try\":[\"Record the exact error and time, and check whether one user or everyone is affected.\",\"Check the provider or application status page and whether the wider internet or office network works.\",\"Note any update, deployment, power cut or account change immediately before the failure.\",\"If you have an approved monitoring page, check capacity and backup status without changing data or configuration.\"],\"stop\":\"Do not run repair commands, edit tables, clear logs, restore a backup or restart a production database repeatedly without a verified recovery plan. Contact Avesta on 0971 013 108.\",\"service\":\"Database & Application Support\"}]");
var STOP = /* @__PURE__ */ new Set([
	"a",
	"an",
	"the",
	"is",
	"am",
	"are",
	"was",
	"were",
	"be",
	"been",
	"being",
	"my",
	"our",
	"your",
	"his",
	"her",
	"its",
	"it",
	"this",
	"that",
	"these",
	"those",
	"to",
	"of",
	"on",
	"in",
	"at",
	"for",
	"with",
	"and",
	"or",
	"but",
	"so",
	"i",
	"me",
	"we",
	"us",
	"you",
	"they",
	"them",
	"he",
	"she",
	"will",
	"would",
	"do",
	"does",
	"did",
	"have",
	"has",
	"had",
	"can",
	"could",
	"should",
	"just",
	"really",
	"very",
	"please",
	"help",
	"hi",
	"hello",
	"there",
	"how",
	"what",
	"why",
	"when",
	"where",
	"which",
	"who",
	"get",
	"got",
	"keep",
	"keeps"
]);
var esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var CONTRACTIONS = [
	["can't", "cannot"],
	["cant", "cannot"],
	["can not", "cannot"],
	["won't", "will not"],
	["wont", "will not"],
	["don't", "do not"],
	["dont", "do not"],
	["didn't", "did not"],
	["didnt", "did not"],
	["doesn't", "does not"],
	["doesnt", "does not"],
	["isn't", "is not"],
	["isnt", "is not"],
	["wasn't", "was not"],
	["wasnt", "was not"],
	["couldn't", "could not"],
	["couldnt", "could not"],
	["haven't", "have not"],
	["havent", "have not"],
	["aren't", "are not"],
	["arent", "are not"],
	["i'm", "i am"],
	["it's", "it is"]
];
var COMPOUNDS = [
	[/wi[\s-]?fi/g, "wifi"],
	[/\be[\s-]mail/g, "email"],
	[/\blog[\s-]in\b/g, "login"],
	[/\bsign[\s-]in\b/g, "signin"],
	[/\bset[\s-]up\b/g, "setup"],
	[/\bback[\s-]ups?\b/g, "backup"],
	[/\bpop[\s-]?ups?\b/g, "popup"],
	[/\bload[\s-]?shedding\b/g, "loadshedding"],
	[/\bshutdown\b/g, "shut down"],
	[/\bpc\b/g, "computer"],
	[/\bmodem\b/g, "router"],
	[/\b(smart|cell|mobile)\s?phone\b/g, "phone"]
];
function normalise(text) {
	let t = String(text).toLowerCase().replace(/[\u2019\u2018`\u00B4]/g, "'");
	for (const [from, to] of CONTRACTIONS) t = t.replace(new RegExp("(?<![a-z])" + esc(from) + "(?![a-z])", "g"), to);
	for (const [re, to] of COMPOUNDS) t = t.replace(re, to);
	return t;
}
function undouble(x) {
	const n = x.length;
	const last = x.at(-1);
	const prev = x.at(-2);
	if (n >= 3 && last !== void 0 && last === prev && !"lsz".includes(last) && !"aeiou".includes(last)) return x.slice(0, -1);
	return x;
}
function stem(word) {
	let w = word;
	if (w.length <= 3 || /^\d+$/.test(w)) return w;
	if (w.length >= 6 && w.slice(-3) === "ing") w = undouble(w.slice(0, -3));
	else if (w.length >= 5 && w.slice(-3) === "ied") w = w.slice(0, -3) + "y";
	else if (w.length >= 5 && w.slice(-3) === "ies") w = w.slice(0, -3) + "y";
	else if (w.length >= 5 && w.slice(-2) === "ed") w = undouble(w.slice(0, -2));
	else if (w.length >= 5 && w.slice(-2) === "es") w = w.slice(0, -2);
	else if (w.slice(-1) === "s" && !/(ss|us|is)$/.test(w)) w = w.slice(0, -1);
	if (w.length >= 4 && w.slice(-1) === "e") w = w.slice(0, -1);
	return w;
}
var words = (text) => normalise(text).split(/[^a-z0-9]+/).filter(Boolean);
var tokens = (text) => words(text).map(stem);
/** Edit distance, on flat arrays so every lookup is a plain number. */
function levenshtein(a, b) {
	const m = a.length, n = b.length;
	let prev = new Array(n + 1);
	let curr = new Array(n + 1);
	for (let j = 0; j <= n; j++) prev[j] = j;
	for (let i = 1; i <= m; i++) {
		curr[0] = i;
		for (let j = 1; j <= n; j++) {
			const sub = prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1);
			curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, sub);
		}
		const swap = prev;
		prev = curr;
		curr = swap;
	}
	return prev[n];
}
function buildIndex(topics) {
	const phrases = [];
	const vocab = /* @__PURE__ */ new Set();
	topics.forEach((topic, i) => {
		const seen = /* @__PURE__ */ new Set();
		phrases[i] = [];
		for (const raw of topic.match) {
			const exact = raw.startsWith("=");
			const tok = tokens(exact ? raw.slice(1) : raw);
			if (!tok.length) continue;
			const meaningful = tok.filter((w) => !STOP.has(w));
			const key = exact ? "=" + tok.join(" ") : meaningful.join(" ") || tok.join(" ");
			if (seen.has(key)) continue;
			seen.add(key);
			const core = exact ? tok : meaningful.length ? meaningful : tok;
			phrases[i].push({
				text: raw.replace(/^=/, ""),
				tok: core,
				exact,
				weight: 1 + 2 * (core.length - 1)
			});
			tok.forEach((w) => vocab.add(w));
		}
	});
	return {
		phrases,
		vocab: Array.from(vocab),
		vocabSet: vocab
	};
}
function correct(list, index, fixes) {
	return list.map((w, i) => {
		if (index.vocabSet.has(w) || w.length < 4 || /^\d+$/.test(w) || STOP.has(w)) return w;
		const max = w.length >= 8 ? 2 : 1;
		let best = null, bestD = 99, tie = false, candidates = [];
		for (const v of index.vocab) {
			if (v[0] !== w[0] || Math.abs(v.length - w.length) > max || v.length < 4) continue;
			const d = levenshtein(w, v);
			if (d > max) continue;
			if (d < bestD) {
				best = v;
				bestD = d;
				tie = false;
				candidates = [v];
			} else if (d === bestD && v !== best) {
				tie = true;
				candidates.push(v);
			}
		}
		if (tie) {
			const longer = candidates.filter((c) => c.length > w.length);
			const only = longer[0];
			if (longer.length === 1 && only !== void 0) {
				best = only;
				tie = false;
			}
		}
		if (best && !tie) {
			fixes.set(i, best);
			return best;
		}
		return w;
	});
}
function find(q, p, gap) {
	for (let s = 0; s < q.length; s++) {
		if (q[s] !== p[0]) continue;
		const used = [s];
		let pos = s, ok = true;
		for (let j = 1; j < p.length; j++) {
			let found = false;
			for (let x = pos + 1; x <= Math.min(q.length - 1, pos + 1 + gap); x++) if (q[x] === p[j]) {
				used.push(x);
				pos = x;
				found = true;
				break;
			}
			if (!found) {
				ok = false;
				break;
			}
		}
		if (ok) return used;
	}
	return null;
}
/** Reads a question and returns the best topic, plus what it understood. */
function readQuestion(text, topics, index) {
	const empty = {
		topic: null,
		keywords: [],
		corrected: [],
		also: []
	};
	const raw = tokens(text);
	if (!raw.length || text.trim().length < 3) return empty;
	const fixes = /* @__PURE__ */ new Map();
	const q = correct(raw, index, fixes);
	const plain = words(text);
	const ranked = topics.map((topic, i) => {
		let score = 0;
		const used = [];
		for (const ph of index.phrases[i] || []) {
			const hit = find(q, ph.tok, ph.exact ? 0 : 3);
			if (!hit) continue;
			const guessed = hit.some((u) => fixes.has(u));
			score += guessed ? ph.weight * (ph.tok.length === 1 ? .5 : .75) : ph.weight;
			used.push(...hit);
		}
		return {
			topic,
			i,
			score,
			used
		};
	}).filter((x) => x.score >= 1).sort((a, b) => b.score - a.score || a.i - b.i);
	const top = ranked[0];
	if (!top) return empty;
	const usedSet = new Set(top.used);
	const keywords = [];
	let run = [];
	for (const p of Array.from(usedSet).sort((a, b) => a - b)) {
		if (run.length) {
			const lastUsed = run[run.length - 1] ?? -1;
			const gapWords = plain.slice(lastUsed + 1, p);
			if (gapWords.length > 2 || gapWords.some((g) => !STOP.has(g))) {
				keywords.push(run.map((r) => plain[r] ?? "").join(" "));
				run = [];
			}
		}
		run.push(p);
	}
	if (run.length) keywords.push(run.map((r) => plain[r] ?? "").join(" "));
	const corrected = [];
	fixes.forEach((to, at) => {
		if (usedSet.has(at)) corrected.push({
			typed: plain[at] ?? "",
			readAs: to
		});
	});
	const also = ranked.slice(1).filter((x) => x.used.some((u) => !usedSet.has(u))).slice(0, 1).map((x) => x.topic);
	return {
		topic: top.topic,
		keywords: keywords.slice(0, 4).filter(Boolean),
		corrected,
		also
	};
}
var Conversation = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickToBottom, {
	className: cn("relative flex-1 overflow-y-hidden", className),
	initial: "smooth",
	resize: "smooth",
	role: "log",
	...props
});
var ConversationContent = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickToBottom.Content, {
	className: cn("flex flex-col gap-8 p-4", className),
	...props
});
var ConversationScrollButton = ({ className, ...props }) => {
	const { isAtBottom, scrollToBottom } = useStickToBottomContext();
	const handleScrollToBottom = (0, import_react.useCallback)(() => {
		scrollToBottom();
	}, [scrollToBottom]);
	return !isAtBottom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		className: cn("absolute bottom-4 left-[50%] translate-x-[-50%] rounded-full dark:bg-background dark:hover:bg-muted", className),
		onClick: handleScrollToBottom,
		size: "icon",
		type: "button",
		variant: "outline",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
	});
};
var Message = ({ className, from, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("group flex w-full max-w-[95%] flex-col gap-2", from === "user" ? "is-user ml-auto justify-end" : "is-assistant", className),
	...props
});
var MessageContent = ({ children, className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("is-user:dark flex w-fit min-w-0 max-w-full flex-col gap-2 overflow-hidden text-sm", "group-[.is-user]:ml-auto group-[.is-user]:rounded-lg group-[.is-user]:bg-secondary group-[.is-user]:px-4 group-[.is-user]:py-3 group-[.is-user]:text-foreground", "group-[.is-assistant]:text-foreground", className),
	...props,
	children
});
(0, import_react.createContext)(null);
var MessageResponse = (0, import_react.memo)(({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Xa, {
	className: cn("size-full [&>*:first-child]:mt-0 [&>*:last-child]:mb-0", className),
	...props
}), (prevProps, nextProps) => prevProps.children === nextProps.children && nextProps.isAnimating === prevProps.isAnimating);
MessageResponse.displayName = "MessageResponse";
function InputGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "input-group",
		role: "group",
		className: cn("group/input-group border-input dark:bg-input/30 shadow-xs relative flex w-full items-center rounded-md border outline-none transition-[color,box-shadow]", "h-9 has-[>textarea]:h-auto", "has-[>[data-align=inline-start]]:[&>input]:pl-2", "has-[>[data-align=inline-end]]:[&>input]:pr-2", "has-[>[data-align=block-start]]:h-auto has-[>[data-align=block-start]]:flex-col has-[>[data-align=block-start]]:[&>input]:pb-3", "has-[>[data-align=block-end]]:h-auto has-[>[data-align=block-end]]:flex-col has-[>[data-align=block-end]]:[&>input]:pt-3", "has-[[data-slot=input-group-control]:focus-visible]:ring-ring has-[[data-slot=input-group-control]:focus-visible]:ring-1", "has-[[data-slot][aria-invalid=true]]:ring-destructive/20 has-[[data-slot][aria-invalid=true]]:border-destructive dark:has-[[data-slot][aria-invalid=true]]:ring-destructive/40", className),
		...props
	});
}
var inputGroupAddonVariants = cva("text-muted-foreground flex h-auto cursor-text select-none items-center justify-center gap-2 py-1.5 text-sm font-medium group-data-[disabled=true]/input-group:opacity-50 [&>kbd]:rounded-[calc(var(--radius)-5px)] [&>svg:not([class*='size-'])]:size-4", {
	variants: { align: {
		"inline-start": "order-first pl-3 has-[>button]:ml-[-0.45rem] has-[>kbd]:ml-[-0.35rem]",
		"inline-end": "order-last pr-3 has-[>button]:mr-[-0.4rem] has-[>kbd]:mr-[-0.35rem]",
		"block-start": "[.border-b]:pb-3 order-first w-full justify-start px-3 pt-3 group-has-[>input]/input-group:pt-2.5",
		"block-end": "[.border-t]:pt-3 order-last w-full justify-start px-3 pb-3 group-has-[>input]/input-group:pb-2.5"
	} },
	defaultVariants: { align: "inline-start" }
});
function InputGroupAddon({ className, align = "inline-start", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"data-slot": "input-group-addon",
		"data-align": align,
		className: cn(inputGroupAddonVariants({ align }), className),
		onClick: (e) => {
			if (e.target.closest("button")) return;
			e.currentTarget.parentElement?.querySelector("input")?.focus();
		},
		...props
	});
}
var inputGroupButtonVariants = cva("flex items-center gap-2 text-sm shadow-none", {
	variants: { size: {
		xs: "h-6 gap-1 rounded-[calc(var(--radius)-5px)] px-2 has-[>svg]:px-2 [&>svg:not([class*='size-'])]:size-3.5",
		sm: "h-8 gap-1.5 rounded-md px-2.5 has-[>svg]:px-2.5",
		"icon-xs": "size-6 rounded-[calc(var(--radius)-5px)] p-0 has-[>svg]:p-0",
		"icon-sm": "size-8 p-0 has-[>svg]:p-0"
	} },
	defaultVariants: { size: "xs" }
});
function InputGroupButton({ className, type = "button", variant = "ghost", size = "xs", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type,
		"data-size": size,
		variant,
		className: cn(inputGroupButtonVariants({ size }), className),
		...props
	});
}
function InputGroupTextarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
		"data-slot": "input-group-control",
		className: cn("flex-1 resize-none rounded-none border-0 bg-transparent py-3 shadow-none focus-visible:ring-0 dark:bg-transparent", className),
		...props
	});
}
function Spinner({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
		role: "status",
		"aria-label": "Loading",
		className: cn("size-4 animate-spin", className),
		...props
	});
}
var convertBlobUrlToDataUrl = async (url) => {
	try {
		const blob = await (await fetch(url)).blob();
		return new Promise((resolve) => {
			const reader = new FileReader();
			reader.onloadend = () => resolve(reader.result);
			reader.onerror = () => resolve(null);
			reader.readAsDataURL(blob);
		});
	} catch {
		return null;
	}
};
var PromptInputController = (0, import_react.createContext)(null);
var ProviderAttachmentsContext = (0, import_react.createContext)(null);
var useOptionalPromptInputController = () => (0, import_react.useContext)(PromptInputController);
var useOptionalProviderAttachments = () => (0, import_react.useContext)(ProviderAttachmentsContext);
var LocalAttachmentsContext = (0, import_react.createContext)(null);
var usePromptInputAttachments = () => {
	const provider = useOptionalProviderAttachments();
	const context = (0, import_react.useContext)(LocalAttachmentsContext) ?? provider;
	if (!context) throw new Error("usePromptInputAttachments must be used within a PromptInput or PromptInputProvider");
	return context;
};
var LocalReferencedSourcesContext = (0, import_react.createContext)(null);
var PromptInput = ({ className, accept, multiple, globalDrop, syncHiddenInput, maxFiles, maxFileSize, onError, onSubmit, children, ...props }) => {
	const controller = useOptionalPromptInputController();
	const usingProvider = !!controller;
	const inputRef = (0, import_react.useRef)(null);
	const formRef = (0, import_react.useRef)(null);
	const [items, setItems] = (0, import_react.useState)([]);
	const files = usingProvider ? controller.attachments.files : items;
	const [referencedSources, setReferencedSources] = (0, import_react.useState)([]);
	const filesRef = (0, import_react.useRef)(files);
	(0, import_react.useEffect)(() => {
		filesRef.current = files;
	}, [files]);
	const openFileDialogLocal = (0, import_react.useCallback)(() => {
		inputRef.current?.click();
	}, []);
	const matchesAccept = (0, import_react.useCallback)((f) => {
		if (!accept || accept.trim() === "") return true;
		return accept.split(",").map((s) => s.trim()).filter(Boolean).some((pattern) => {
			if (pattern.endsWith("/*")) {
				const prefix = pattern.slice(0, -1);
				return f.type.startsWith(prefix);
			}
			return f.type === pattern;
		});
	}, [accept]);
	const addLocal = (0, import_react.useCallback)((fileList) => {
		const incoming = [...fileList];
		const accepted = incoming.filter((f) => matchesAccept(f));
		if (incoming.length && accepted.length === 0) {
			onError?.({
				code: "accept",
				message: "No files match the accepted types."
			});
			return;
		}
		const withinSize = (f) => maxFileSize ? f.size <= maxFileSize : true;
		const sized = accepted.filter(withinSize);
		if (accepted.length > 0 && sized.length === 0) {
			onError?.({
				code: "max_file_size",
				message: "All files exceed the maximum size."
			});
			return;
		}
		setItems((prev) => {
			const capacity = typeof maxFiles === "number" ? Math.max(0, maxFiles - prev.length) : void 0;
			const capped = typeof capacity === "number" ? sized.slice(0, capacity) : sized;
			if (typeof capacity === "number" && sized.length > capacity) onError?.({
				code: "max_files",
				message: "Too many files. Some were not added."
			});
			const next = [];
			for (const file of capped) next.push({
				filename: file.name,
				id: nanoid(),
				mediaType: file.type,
				type: "file",
				url: URL.createObjectURL(file)
			});
			return [...prev, ...next];
		});
	}, [
		matchesAccept,
		maxFiles,
		maxFileSize,
		onError
	]);
	const removeLocal = (0, import_react.useCallback)((id) => setItems((prev) => {
		const found = prev.find((file) => file.id === id);
		if (found?.url) URL.revokeObjectURL(found.url);
		return prev.filter((file) => file.id !== id);
	}), []);
	const addWithProviderValidation = (0, import_react.useCallback)((fileList) => {
		const incoming = [...fileList];
		const accepted = incoming.filter((f) => matchesAccept(f));
		if (incoming.length && accepted.length === 0) {
			onError?.({
				code: "accept",
				message: "No files match the accepted types."
			});
			return;
		}
		const withinSize = (f) => maxFileSize ? f.size <= maxFileSize : true;
		const sized = accepted.filter(withinSize);
		if (accepted.length > 0 && sized.length === 0) {
			onError?.({
				code: "max_file_size",
				message: "All files exceed the maximum size."
			});
			return;
		}
		const currentCount = files.length;
		const capacity = typeof maxFiles === "number" ? Math.max(0, maxFiles - currentCount) : void 0;
		const capped = typeof capacity === "number" ? sized.slice(0, capacity) : sized;
		if (typeof capacity === "number" && sized.length > capacity) onError?.({
			code: "max_files",
			message: "Too many files. Some were not added."
		});
		if (capped.length > 0) controller?.attachments.add(capped);
	}, [
		matchesAccept,
		maxFileSize,
		maxFiles,
		onError,
		files.length,
		controller
	]);
	const clearAttachments = (0, import_react.useCallback)(() => usingProvider ? controller?.attachments.clear() : setItems((prev) => {
		for (const file of prev) if (file.url) URL.revokeObjectURL(file.url);
		return [];
	}), [usingProvider, controller]);
	const clearReferencedSources = (0, import_react.useCallback)(() => setReferencedSources([]), []);
	const add = usingProvider ? addWithProviderValidation : addLocal;
	const remove = usingProvider ? controller.attachments.remove : removeLocal;
	const openFileDialog = usingProvider ? controller.attachments.openFileDialog : openFileDialogLocal;
	const clear = (0, import_react.useCallback)(() => {
		clearAttachments();
		clearReferencedSources();
	}, [clearAttachments, clearReferencedSources]);
	(0, import_react.useEffect)(() => {
		if (!usingProvider) return;
		controller.__registerFileInput(inputRef, () => inputRef.current?.click());
	}, [usingProvider, controller]);
	(0, import_react.useEffect)(() => {
		if (syncHiddenInput && inputRef.current && files.length === 0) inputRef.current.value = "";
	}, [files, syncHiddenInput]);
	(0, import_react.useEffect)(() => {
		const form = formRef.current;
		if (!form) return;
		if (globalDrop) return;
		const onDragOver = (e) => {
			if (e.dataTransfer?.types?.includes("Files")) e.preventDefault();
		};
		const onDrop = (e) => {
			if (e.dataTransfer?.types?.includes("Files")) e.preventDefault();
			if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) add(e.dataTransfer.files);
		};
		form.addEventListener("dragover", onDragOver);
		form.addEventListener("drop", onDrop);
		return () => {
			form.removeEventListener("dragover", onDragOver);
			form.removeEventListener("drop", onDrop);
		};
	}, [add, globalDrop]);
	(0, import_react.useEffect)(() => {
		if (!globalDrop) return;
		const onDragOver = (e) => {
			if (e.dataTransfer?.types?.includes("Files")) e.preventDefault();
		};
		const onDrop = (e) => {
			if (e.dataTransfer?.types?.includes("Files")) e.preventDefault();
			if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) add(e.dataTransfer.files);
		};
		document.addEventListener("dragover", onDragOver);
		document.addEventListener("drop", onDrop);
		return () => {
			document.removeEventListener("dragover", onDragOver);
			document.removeEventListener("drop", onDrop);
		};
	}, [add, globalDrop]);
	(0, import_react.useEffect)(() => () => {
		if (!usingProvider) {
			for (const f of filesRef.current) if (f.url) URL.revokeObjectURL(f.url);
		}
	}, [usingProvider]);
	const handleChange = (0, import_react.useCallback)((event) => {
		if (event.currentTarget.files) add(event.currentTarget.files);
		event.currentTarget.value = "";
	}, [add]);
	const attachmentsCtx = (0, import_react.useMemo)(() => ({
		add,
		clear: clearAttachments,
		fileInputRef: inputRef,
		files: files.map((item) => ({
			...item,
			id: item.id
		})),
		openFileDialog,
		remove
	}), [
		files,
		add,
		remove,
		clearAttachments,
		openFileDialog
	]);
	const refsCtx = (0, import_react.useMemo)(() => ({
		add: (incoming) => {
			const array = Array.isArray(incoming) ? incoming : [incoming];
			setReferencedSources((prev) => [...prev, ...array.map((s) => ({
				...s,
				id: nanoid()
			}))]);
		},
		clear: clearReferencedSources,
		remove: (id) => {
			setReferencedSources((prev) => prev.filter((s) => s.id !== id));
		},
		sources: referencedSources
	}), [referencedSources, clearReferencedSources]);
	const handleSubmit = (0, import_react.useCallback)(async (event) => {
		event.preventDefault();
		const form = event.currentTarget;
		const text = usingProvider ? controller.textInput.value : (() => {
			return new FormData(form).get("message") || "";
		})();
		if (!usingProvider) form.reset();
		try {
			const result = onSubmit({
				files: await Promise.all(files.map(async ({ id: _id, ...item }) => {
					if (item.url?.startsWith("blob:")) {
						const dataUrl = await convertBlobUrlToDataUrl(item.url);
						return {
							...item,
							url: dataUrl ?? item.url
						};
					}
					return item;
				})),
				text
			}, event);
			if (result instanceof Promise) try {
				await result;
				clear();
				if (usingProvider) controller.textInput.clear();
			} catch {}
			else {
				clear();
				if (usingProvider) controller.textInput.clear();
			}
		} catch {}
	}, [
		usingProvider,
		controller,
		files,
		onSubmit,
		clear
	]);
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		accept,
		"aria-label": "Upload files",
		className: "hidden",
		multiple,
		onChange: handleChange,
		ref: inputRef,
		title: "Upload files",
		type: "file"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		className: cn("w-full", className),
		onSubmit: handleSubmit,
		ref: formRef,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroup, {
			className: "overflow-hidden",
			children
		})
	})] });
	const withReferencedSources = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocalReferencedSourcesContext.Provider, {
		value: refsCtx,
		children: inner
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocalAttachmentsContext.Provider, {
		value: attachmentsCtx,
		children: withReferencedSources
	});
};
var PromptInputTextarea = ({ onChange, onKeyDown, className, placeholder = "What would you like to know?", ...props }) => {
	const controller = useOptionalPromptInputController();
	const attachments = usePromptInputAttachments();
	const [isComposing, setIsComposing] = (0, import_react.useState)(false);
	const handleKeyDown = (0, import_react.useCallback)((e) => {
		onKeyDown?.(e);
		if (e.defaultPrevented) return;
		if (e.key === "Enter") {
			if (isComposing || e.nativeEvent.isComposing) return;
			if (e.shiftKey) return;
			e.preventDefault();
			const { form } = e.currentTarget;
			if ((form?.querySelector("button[type=\"submit\"]"))?.disabled) return;
			form?.requestSubmit();
		}
		if (e.key === "Backspace" && e.currentTarget.value === "" && attachments.files.length > 0) {
			e.preventDefault();
			const lastAttachment = attachments.files.at(-1);
			if (lastAttachment) attachments.remove(lastAttachment.id);
		}
	}, [
		onKeyDown,
		isComposing,
		attachments
	]);
	const handlePaste = (0, import_react.useCallback)((event) => {
		const items = event.clipboardData?.items;
		if (!items) return;
		const files = [];
		for (const item of items) if (item.kind === "file") {
			const file = item.getAsFile();
			if (file) files.push(file);
		}
		if (files.length > 0) {
			event.preventDefault();
			attachments.add(files);
		}
	}, [attachments]);
	const handleCompositionEnd = (0, import_react.useCallback)(() => setIsComposing(false), []);
	const handleCompositionStart = (0, import_react.useCallback)(() => setIsComposing(true), []);
	const controlledProps = controller ? {
		onChange: (e) => {
			controller.textInput.setInput(e.currentTarget.value);
			onChange?.(e);
		},
		value: controller.textInput.value
	} : { onChange };
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupTextarea, {
		className: cn("field-sizing-content max-h-48 min-h-16", className),
		name: "message",
		onCompositionEnd: handleCompositionEnd,
		onCompositionStart: handleCompositionStart,
		onKeyDown: handleKeyDown,
		onPaste: handlePaste,
		placeholder,
		...props,
		...controlledProps
	});
};
var PromptInputFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, {
	align: "block-end",
	className: cn("justify-between gap-1", className),
	...props
});
var PromptInputSubmit = ({ className, variant = "default", size = "icon-sm", status, onStop, onClick, children, ...props }) => {
	const isGenerating = status === "submitted" || status === "streaming";
	let Icon = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerDownLeft, { className: "size-4" });
	if (status === "submitted") Icon = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	else if (status === "streaming") Icon = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" });
	else if (status === "error") Icon = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" });
	const handleClick = (0, import_react.useCallback)((e) => {
		if (isGenerating && onStop) {
			e.preventDefault();
			onStop();
			return;
		}
		onClick?.(e);
	}, [
		isGenerating,
		onStop,
		onClick
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
		"aria-label": isGenerating ? "Stop" : "Submit",
		className: cn(className),
		onClick: handleClick,
		size,
		type: isGenerating && onStop ? "button" : "submit",
		variant,
		...props,
		children: children ?? Icon
	});
};
var motionComponentCache = /* @__PURE__ */ new Map();
var getMotionComponent = (element) => {
	let component = motionComponentCache.get(element);
	if (!component) {
		component = motion.create(element);
		motionComponentCache.set(element, component);
	}
	return component;
};
var ShimmerComponent = ({ children, as: Component = "p", className, duration = 2, spread = 2 }) => {
	const MotionComponent = getMotionComponent(Component);
	const dynamicSpread = (0, import_react.useMemo)(() => (children?.length ?? 0) * spread, [children, spread]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MotionComponent, {
		animate: { backgroundPosition: "0% center" },
		className: cn("relative inline-block bg-[length:250%_100%,auto] bg-clip-text text-transparent", "[--bg:linear-gradient(90deg,#0000_calc(50%-var(--spread)),var(--color-background),#0000_calc(50%+var(--spread)))] [background-repeat:no-repeat,padding-box]", className),
		initial: { backgroundPosition: "100% center" },
		style: {
			"--spread": `${dynamicSpread}px`,
			backgroundImage: "var(--bg), linear-gradient(var(--color-muted-foreground), var(--color-muted-foreground))"
		},
		transition: {
			duration,
			ease: "linear",
			repeat: Number.POSITIVE_INFINITY
		},
		children
	});
};
var Shimmer = (0, import_react.memo)(ShimmerComponent);
var g_it_icon_default = "/assets/g-it-icon-DkrwBGuv.webp";
var STARTERS = [
	"My laptop shows a blue screen error",
	"Wi-Fi connected but no internet",
	"Printer says offline",
	"CCTV recorder shows HDD error",
	"I clicked a suspicious email link",
	"Website shows 502 Bad Gateway"
];
var SENSITIVE_DATA = /(?:password|passcode|pin|otp|verification code|recovery code|secret|private key|api key)\s*[:=]\s*\S+|\b(?:\d[ -]*?){13,19}\b|-----BEGIN [A-Z ]*PRIVATE KEY-----/i;
function hasSensitiveData(value) {
	return SENSITIVE_DATA.test(value);
}
function Ticket({ asked, service, title }) {
	const [uid, setUid] = (0, import_react.useState)(void 0);
	const [location, setLocation] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	const [ai, setAi] = (0, import_react.useState)("");
	const [aiBusy, setAiBusy] = (0, import_react.useState)(false);
	const autoReply = useServerFn(autoReplyTicket);
	(0, import_react.useEffect)(() => {
		supabase.auth.getUser().then(({ data }) => setUid(data.user?.id ?? null));
	}, []);
	(0, import_react.useEffect)(() => {
		setSent(false);
		setAi("");
	}, [asked]);
	async function submit() {
		if (!uid) return;
		if (hasSensitiveData(asked)) {
			toast.error("Remove passwords, PINs, codes, card numbers or secret keys before sending.");
			return;
		}
		setBusy(true);
		const { data, error } = await supabase.from("it_requests").insert({
			user_id: uid,
			service,
			location: location.trim() || null,
			details: (title ? `[${title}] ` : "") + asked.trim()
		}).select("id").single();
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		setSent(true);
		toast.success("Ticket sent — G-IT is replying now.");
		setAiBusy(true);
		try {
			setAi((await autoReply({ data: { id: data.id } })).reply);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setAiBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 rounded-2xl border border-border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Still stuck? Send a ticket"
			}),
			sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 space-y-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Ticket sent. A technician will follow up — track it in ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/portal",
							className: "text-primary underline",
							children: "your portal"
						}),
						"."
					] }),
					aiBusy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: "G-IT is writing a first reply…"
					}),
					ai && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-primary/10 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 font-semibold",
							children: "G-IT (instant reply)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Md, { text: ai })]
					})
				]
			}) : uid ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-xs",
					placeholder: "Where are you? (e.g. Ndola CBD)",
					value: location,
					onChange: (e) => setLocation(e.target.value),
					maxLength: 200
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "copper",
					disabled: busy,
					onClick: submit,
					children: busy ? "Sending…" : "Send ticket to a technician"
				})]
			}) : uid === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "copper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/auth",
						children: "Sign in to send a ticket"
					})
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "glass",
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `https://wa.me/260769974200?text=${encodeURIComponent("IT help: " + asked)}`,
					target: "_blank",
					rel: "noreferrer",
					children: "Or WhatsApp us"
				})
			})
		]
	});
}
function Md({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 [&_ol]:list-decimal [&_ol]:pl-5 [&_ul]:list-disc [&_ul]:pl-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { children: text })
	});
}
var DOC_RE = /\.(docx?|xlsx?|csv)$/i;
var DOC_MIME = /wordprocessingml|msword|spreadsheetml|ms-excel|text\/csv/;
async function readAttachment(file) {
	if (file.type === "application/pdf") {
		if (file.size > 4e6) throw new Error("PDFs must be under 4 MB.");
		const data = await new Promise((res, rej) => {
			const r = new FileReader();
			r.onload = () => res(r.result);
			r.onerror = rej;
			r.readAsDataURL(file);
		});
		return {
			name: file.name,
			type: file.type,
			data
		};
	}
	if (DOC_RE.test(file.name) || DOC_MIME.test(file.type)) {
		if (file.size > 8e6) throw new Error("Word and Excel files must be under 8 MB.");
		const buf = await file.arrayBuffer();
		let text = "";
		if (/\.docx?$/i.test(file.name) || /wordprocessingml|msword/.test(file.type)) {
			const { extractRawText } = await import("../_libs/mammoth.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			text = (await extractRawText({ arrayBuffer: buf })).value;
		} else {
			const XLSX = await import("../_libs/xlsx.mjs").then((n) => n.t);
			const wb = XLSX.read(buf, { type: "array" });
			text = wb.SheetNames.map((n) => `Sheet: ${n}\n` + XLSX.utils.sheet_to_csv(wb.Sheets[n])).join("\n\n");
		}
		text = text.trim().slice(0, 8e3);
		if (!text) throw new Error(`No readable text was found in ${file.name}.`);
		return {
			name: file.name,
			type: "text/plain",
			data: "data:text/plain;base64," + btoa(String.fromCharCode(...new TextEncoder().encode(text)))
		};
	}
	if (!file.type.startsWith("image/")) throw new Error("Attach a photo, screenshot, PDF, Word or Excel file.");
	const bmp = await createImageBitmap(file);
	const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
	const c = document.createElement("canvas");
	c.width = Math.round(bmp.width * scale);
	c.height = Math.round(bmp.height * scale);
	c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
	return {
		name: file.name || "screenshot.jpg",
		type: "image/jpeg",
		data: c.toDataURL("image/jpeg", .85)
	};
}
function Chat() {
	const send = useServerFn(itChat);
	const textareaRef = (0, import_react.useRef)(null);
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [input, setInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	const [files, setFiles] = (0, import_react.useState)([]);
	async function addFiles(list) {
		if (!list) return;
		setErr("");
		for (const f of Array.from(list)) {
			if (files.length >= 4) {
				setErr("You can attach up to 4 files per message.");
				break;
			}
			try {
				const a = await readAttachment(f);
				setFiles((p) => p.length >= 4 ? p : [...p, a]);
			} catch (e) {
				setErr(e.message || "That file could not be read.");
			}
		}
	}
	async function go(submittedText) {
		const attachments = files;
		const text = (submittedText ?? input).trim() || (attachments.length ? "Please look at the attached file(s) and tell me what the problem is and how to fix it." : "");
		if (!text || busy) return;
		if (hasSensitiveData(text)) {
			setErr("Remove passwords, PINs, verification codes, card numbers or secret keys before sending.");
			return;
		}
		const next = [...msgs, {
			role: "user",
			content: text,
			attachments: attachments.length ? attachments : void 0
		}];
		setMsgs(next);
		setInput("");
		setFiles([]);
		setBusy(true);
		setErr("");
		textareaRef.current?.focus();
		try {
			const recent = next.slice(-20);
			const userIdx = recent.map((m, i) => m.role === "user" ? i : -1).filter((i) => i >= 0).slice(-2);
			const payload = recent.map((m, i) => ({
				role: m.role,
				content: m.content,
				...m.attachments && userIdx.includes(i) ? { attachments: m.attachments } : {}
			}));
			const r = await send({ data: { messages: payload } });
			setMsgs([...next, {
				role: "assistant",
				content: r.reply,
				reasoning: r.reasoning,
				suggestions: r.suggestions
			}]);
		} catch (e) {
			setErr(e.message);
		} finally {
			setBusy(false);
			textareaRef.current?.focus();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10 overflow-hidden rounded-lg border border-border bg-card shadow-lg",
		"aria-label": "G-IT chat",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-primary/25 bg-background px-4 py-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: g_it_icon_default,
					alt: "G-IT assistant icon",
					width: 48,
					height: 48,
					className: "size-12 shrink-0 rounded-md border border-primary/30 object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold leading-tight sm:text-2xl",
						children: "Chat with G-IT"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-medium text-primary",
						children: "AVESTA IT HELP"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Conversation, {
				className: "h-[min(34rem,58dvh)] min-h-64 bg-background/70 sm:h-[31rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConversationContent, {
					className: "min-h-full gap-5 p-4 sm:p-6",
					children: [
						msgs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-full flex-col justify-between gap-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex max-w-md items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/assets/g-it-icon-DkrwBGuv.webp",
									alt: "",
									width: 32,
									height: 32,
									className: "size-8 shrink-0 rounded-md object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 border-l-2 border-primary/50 pl-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium leading-relaxed",
										children: "Hello, I'm G-IT. Tell me what's happening with your device, network or software, and we'll work through it."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-muted-foreground",
										children: "You can include an error code or attach a screenshot, photo, PDF, Word or Excel file."
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-xs font-semibold text-primary",
								children: "COMMON ISSUES"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: STARTERS.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									disabled: busy,
									className: "h-auto min-h-11 justify-between gap-3 whitespace-normal border-border bg-card px-3 py-2.5 text-left text-xs leading-snug hover:border-primary/60 hover:bg-secondary sm:text-sm",
									onClick: () => go(q),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 shrink-0 text-primary" })]
								}, q))
							})] })]
						}),
						msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Message, {
							from: m.role,
							className: m.role === "assistant" ? "max-w-full flex-row items-start gap-3" : "max-w-[88%]",
							children: [m.role === "assistant" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/assets/g-it-icon-DkrwBGuv.webp",
								alt: "G-IT",
								width: 32,
								height: 32,
								className: "size-8 shrink-0 rounded-md object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageContent, {
								className: m.role === "user" ? "rounded-lg group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground" : "min-w-0 max-w-full text-sm leading-relaxed",
								children: m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									m.reasoning && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "mb-2 rounded-md border border-border bg-muted/40 px-3 py-2 text-xs text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
											className: "flex cursor-pointer items-center gap-1 font-medium",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "size-3.5" }), " How G-IT worked this out"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 whitespace-pre-line",
											children: m.reasoning
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageResponse, {
										className: "[&_a]:text-primary [&_a]:underline",
										children: m.content
									}),
									i === msgs.length - 1 && !busy && !!m.suggestions?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 flex flex-wrap gap-2",
										children: m.suggestions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											className: "h-auto min-h-8 whitespace-normal text-left",
											onClick: () => go(q),
											children: q
										}, q))
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!!m.attachments?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-2 flex flex-wrap gap-2",
									children: m.attachments.map((a, j) => a.type.startsWith("image/") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: a.data,
										alt: a.name,
										className: "max-h-40 rounded border border-border"
									}, j) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex min-w-0 items-center gap-1 break-all rounded bg-primary-foreground/15 px-2 py-1 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 shrink-0" }), a.name]
									}, j))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "whitespace-pre-line",
									children: m.content
								})] })
							})]
						}, `${m.role}-${i}`)),
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/assets/g-it-icon-DkrwBGuv.webp",
								alt: "",
								width: 32,
								height: 32,
								className: "size-8 rounded-md object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shimmer, {
								className: "text-sm",
								children: "G-IT is looking into this…"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConversationScrollButton, { "aria-label": "Scroll to latest message" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border bg-card p-3 sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PromptInput, {
						className: "rounded-md border-border bg-background/60 focus-within:border-primary/60",
						onSubmit: ({ text }) => go(text),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptInputTextarea, {
								ref: textareaRef,
								"aria-label": "Message G-IT",
								className: "min-h-16 max-h-36 px-3 py-3 text-sm",
								value: input,
								onChange: (e) => setInput(e.target.value),
								onPaste: (e) => {
									const imgs = Array.from(e.clipboardData.files).filter((f) => f.type.startsWith("image/"));
									if (imgs.length) {
										e.preventDefault();
										addFiles(imgs);
									}
								},
								maxLength: 4e3,
								placeholder: "Describe your issue or paste an error code…"
							}),
							!!files.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2 px-3 pt-2",
								children: files.map((a, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [a.type.startsWith("image/") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: a.data,
										alt: a.name,
										className: "size-16 rounded border border-border object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex h-16 max-w-44 items-center gap-1 break-all rounded border border-border px-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 shrink-0" }), a.name]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "icon-sm",
										variant: "destructive",
										"aria-label": `Remove ${a.name}`,
										onClick: () => setFiles((p) => p.filter((_, k) => k !== j)),
										className: "absolute -right-2 -top-2 size-6 rounded-full p-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
									})]
								}, j))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PromptInputFooter, {
								className: "justify-between gap-2 px-2 pb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "sm",
									className: "h-8 px-2 text-muted-foreground hover:text-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										title: "Attach a photo, screenshot, PDF, Word or Excel file",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: "Attach file"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sm:hidden",
												children: "Attach"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												"aria-label": "Attach a photo or document to your ticket",
												accept: "image/*,application/pdf,.doc,.docx,.xls,.xlsx,.csv",
												multiple: true,
												className: "sr-only",
												onChange: (e) => {
													addFiles(e.target.files);
													e.target.value = "";
												}
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptInputSubmit, {
									title: "Send message",
									className: "size-9 shrink-0 rounded-md bg-primary text-primary-foreground hover:bg-primary/90",
									status: busy ? "submitted" : "ready",
									disabled: busy || !input.trim() && !files.length
								})]
							})
						]
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "mt-2 text-sm text-destructive",
						children: err
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-xs text-muted-foreground",
						children: "Never share passwords, PINs, codes or banking details."
					})
				]
			})
		]
	});
}
function useTopics() {
	const [extra, setExtra] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		learnedTopics().then((r) => setExtra(r.topics ?? [])).catch(() => setExtra([]));
	}, []);
	const all = (0, import_react.useMemo)(() => [...it_help_topics_default, ...extra], [extra]);
	return {
		all,
		index: (0, import_react.useMemo)(() => buildIndex(all), [all])
	};
}
function ItHelp() {
	const [text, setText] = (0, import_react.useState)("");
	const [asked, setAsked] = (0, import_react.useState)("");
	const { all: allTopics, index: helpIndex } = useTopics();
	const reading = (0, import_react.useMemo)(() => asked ? readQuestion(asked, allTopics, helpIndex) : null, [
		asked,
		allTopics,
		helpIndex
	]);
	const results = reading?.topic ? [reading.topic, ...reading.also] : [];
	const [web, setWeb] = (0, import_react.useState)(null);
	const [researching, setResearching] = (0, import_react.useState)(false);
	const [webErr, setWebErr] = (0, import_react.useState)("");
	function ask(text) {
		setAsked(text);
		setWeb(null);
		setWebErr("");
		const r = readQuestion(text, allTopics, helpIndex);
		logQuestion({ data: {
			question: text.slice(0, 500),
			matchedTitle: r.topic?.title ?? null
		} }).catch(() => {});
	}
	async function research() {
		setResearching(true);
		setWebErr("");
		try {
			setWeb(await researchProblem({ data: { question: asked.slice(0, 500) } }));
		} catch (e) {
			setWebErr(e.message);
		}
		setResearching(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page-enter min-h-screen bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl font-semibold",
					children: "What's wrong with your tech?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "Describe the problem in your own words — e.g. \"my laptop won't start\" or \"wifi keeps dropping\"."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-5 min-h-28",
					value: text,
					onChange: (e) => setText(e.target.value),
					maxLength: 1e3
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3",
					variant: "copper",
					disabled: text.trim().length < 3,
					onClick: () => ask(text),
					children: "Find a fix"
				}),
				asked && results.length === 0 && !web && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-lg border border-border p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We have no written answer for that one yet." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "We can look it up online and summarise what we find, in plain language, leaving out anything that could cost you your data. Or send it straight to our technicians."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-3",
							variant: "copper",
							disabled: researching,
							onClick: () => void research(),
							children: researching ? "Looking it up…" : "Look it up online"
						}),
						webErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-destructive",
							children: webErr
						})
					]
				}),
				web && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mt-6 rounded-2xl border border-border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wide text-muted-foreground",
							children: "Researched online just now"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: web.answer
						}),
						web.steps.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 font-semibold",
							children: "Safe to try"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-2 list-decimal space-y-1.5 pl-5 text-sm",
							children: web.steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: step }, step))
						})] }),
						web.stop && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 rounded-md bg-destructive/15 p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Stop if: " }), web.stop]
						}),
						web.sources.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 border-t border-border pt-3 text-xs text-muted-foreground",
							children: [
								"Read from:",
								" ",
								web.sources.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [i > 0 && ", ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "underline",
									href: src.url,
									target: "_blank",
									rel: "noopener noreferrer nofollow",
									children: src.title
								})] }, src.url))
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: "Put together from what we found online, not from seeing your machine. If anything here looks risky, stop and call us on 0769 974 200."
						})
					]
				}),
				results.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mt-6 rounded-2xl border border-border bg-card p-6",
					children: [
						i === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wide text-muted-foreground",
							children: "It could also be"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-semibold text-primary",
							children: r.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: r.answer
						}),
						r.try.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 font-semibold",
							children: "Try this first"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-2 list-decimal space-y-1.5 pl-5 text-sm",
							children: r.try.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, s))
						})] }),
						r.stop && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 rounded-md bg-destructive/15 p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Stop if: " }), r.stop]
						}),
						r.service && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: ["Our service: ", r.service]
						})
					]
				}, r.title)),
				asked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, {
					asked,
					service: results[0]?.service || "Computer repair",
					title: results[0]?.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chat, {})
			]
		})
	});
}
//#endregion
export { ItHelp as component };
