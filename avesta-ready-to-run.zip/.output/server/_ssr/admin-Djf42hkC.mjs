import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { t as Route } from "./admin-DrdCOFgD.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
import { i as promoteToTopic, n as learningQueue } from "./it-learn.functions-BYnYqmW6.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as StatusBadge, n as AppHeader, t as AdminOnly } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { t as Textarea } from "./textarea-BPdFvfWe.mjs";
import { a as statusTone, i as loanQuote, r as kwacha } from "./avesta-HIuujrtk.mjs";
import { n as notifyLoanDecision } from "./loan-emails.functions-tn9qcqtK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Djf42hkC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var listAdmins = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("c8a7e24030f37de350fc982d3af5723fc27c506758ea41bd22ec73fd0618863f"));
var addAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ email: stringType().trim().email().max(255) }).parse(d)).handler(createSsrRpc("70a2e888f5b17f1d42c4b7d91733a75478930126c5885a27410ae82fc68cbad2"));
var removeAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ userId: stringType().uuid() }).parse(d)).handler(createSsrRpc("3a46d25e6804bae49baa23e35d434e5b5a3b4e1ffe6810a527b2f565f7d796ed"));
var deleteCustomer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ userId: stringType().uuid() }).parse(d)).handler(createSsrRpc("2f1c73f9e24ebe72c705d295e336913c9c1e020140aca47d15ca892445dc6794"));
function Admin() {
	const { user } = Route.useRouteContext();
	const [tab, setTab] = (0, import_react.useState)("loans");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOnly, {
		userId: user.id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "page-enter mx-auto max-w-6xl px-5 pb-16 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { userId: user.id }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-3xl font-semibold",
					children: "Staff portal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "tablist",
					"aria-label": "Staff portal sections",
					className: "mt-8 grid grid-cols-2 gap-2 sm:grid-cols-5",
					children: [
						"loans",
						"it",
						"learning",
						"customers",
						"data"
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						role: "tab",
						"aria-selected": tab === t,
						size: "sm",
						className: "h-auto min-h-9 min-w-0 whitespace-normal px-2 py-2 text-center leading-tight sm:px-3",
						variant: tab === t ? "copper" : "glass",
						onClick: () => setTab(t),
						children: t === "loans" ? "Loans" : t === "it" ? "IT requests" : t === "learning" ? "Assistant learning" : t === "customers" ? "Customers" : "Backup & admins"
					}, t))
				}),
				tab === "loans" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoansPanel, {}),
				tab === "it" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItPanel, {}),
				tab === "learning" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LearningPanel, {}),
				tab === "customers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomersPanel, { currentUserId: user.id }),
				tab === "data" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {})
			]
		})
	});
}
function useProfiles() {
	return useQuery({
		queryKey: ["all-profiles"],
		queryFn: async () => (await supabase.from("profiles").select("*").order("created_at", { ascending: false })).data ?? []
	});
}
function Stats() {
	const { data } = useQuery({
		queryKey: ["admin-stats"],
		queryFn: async () => {
			const [l, r, i] = await Promise.all([
				supabase.from("loans").select("status, amount, total"),
				supabase.from("repayments").select("amount"),
				supabase.from("it_requests").select("status")
			]);
			const loans = l.data ?? [];
			return {
				pending: loans.filter((x) => x.status === "pending").length,
				lent: loans.filter((x) => ["approved", "paid"].includes(x.status)).reduce((s, x) => s + Number(x.amount), 0),
				collected: (r.data ?? []).reduce((s, x) => s + Number(x.amount), 0),
				openIt: (i.data ?? []).filter((x) => x.status !== "completed" && x.status !== "cancelled").length
			};
		}
	});
	const items = [
		["Pending loans", data?.pending ?? 0],
		["Total lent", kwacha(data?.lent ?? 0)],
		["Collected", kwacha(data?.collected ?? 0)],
		["Open IT jobs", data?.openIt ?? 0]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-6 grid grid-cols-1 gap-3 min-[420px]:grid-cols-2 sm:grid-cols-4",
		children: items.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "account-strip min-w-0 rounded-xl p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: k
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 break-words font-display text-xl font-semibold",
				children: v
			})]
		}, k))
	});
}
var PAYOUT = {
	mobile_money: "Mobile money",
	bank: "Bank transfer",
	cash: "Cash at office"
};
function waLink(phone, text) {
	return `https://wa.me/260${(phone ?? "").replace(/\D/g, "").replace(/^260/, "").replace(/^0/, "")}?text=${encodeURIComponent(text)}`;
}
function LoansPanel() {
	const qc = useQueryClient();
	const profiles = useProfiles();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const loans = useQuery({
		queryKey: ["admin-loans"],
		queryFn: async () => {
			const { data, error } = await supabase.from("loans").select("*, repayments(*)").order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const docs = useQuery({
		queryKey: ["admin-documents"],
		queryFn: async () => (await supabase.from("loan_documents").select("*")).data ?? []
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["admin-loans"] });
		qc.invalidateQueries({ queryKey: ["admin-stats"] });
	};
	const update = useMutation({
		mutationFn: async (v) => {
			const { id, ...rest } = v;
			const { error } = await supabase.from("loans").update(rest).eq("id", id);
			if (error) throw error;
			return v;
		},
		onSuccess: (v) => {
			toast.success("Loan updated");
			refresh();
			const kind = v.status === "approved" || v.status === "rejected" || v.status === "paid" ? v.status : v.disbursed_at ? "disbursed" : v.collateral_required ? "collateral" : null;
			if (kind) notifyLoanDecision({ data: {
				loanId: v.id,
				kind
			} }).catch(() => {});
		},
		onError: (e) => toast.error(e.message)
	});
	const del = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("loans").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Loan deleted");
			refresh();
		},
		onError: (e) => toast.error(e.message)
	});
	const pay = useMutation({
		mutationFn: async (v) => {
			const { error } = await supabase.from("repayments").insert(v);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Repayment recorded");
			refresh();
		},
		onError: (e) => toast.error(e.message)
	});
	const delPay = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("repayments").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Repayment removed");
			refresh();
		},
		onError: (e) => toast.error(e.message)
	});
	const openDoc = async (path) => {
		const { data, error } = await supabase.storage.from("borrower-docs").createSignedUrl(path, 60);
		if (error) {
			toast.error(error.message);
			return;
		}
		window.open(data.signedUrl, "_blank", "noopener,noreferrer");
	};
	const list = (loans.data ?? []).filter((l) => filter === "all" || l.status === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 text-sm",
				children: [
					"all",
					"pending",
					"approved",
					"paid",
					"rejected"
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setFilter(f),
					className: `rounded-full px-3 py-1 capitalize ${filter === f ? "bg-primary text-primary-foreground" : "bg-foreground/10"}`,
					children: f
				}, f))
			}),
			list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No loans here."
			}),
			list.map((l) => {
				const paid = l.repayments.reduce((s, r) => s + Number(r.amount), 0);
				const balance = Math.max(0, Number(l.total) - paid);
				const p = profiles.data?.find((x) => x.id === l.user_id);
				const collateral = (docs.data ?? []).filter((d) => d.kind === "collateral" && (d.loan_id === l.id || !d.loan_id && d.user_id === l.user_id));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoanRow, {
					l,
					p,
					paid,
					balance,
					collateral,
					onOpenDoc: openDoc,
					onUpdate: (v) => update.mutate({
						id: l.id,
						...v
					}),
					onDelete: () => {
						if (confirm("Delete this loan and its repayments? This cannot be undone.")) del.mutate(l.id);
					},
					onDeletePayment: (id) => {
						if (confirm("Remove this repayment?")) delPay.mutate(id);
					},
					onPay: (amount) => pay.mutate({
						loan_id: l.id,
						amount
					}, { onSuccess: () => {
						if (amount >= balance) update.mutate({
							id: l.id,
							status: "paid"
						});
					} })
				}, l.id);
			})
		]
	});
}
function LoanRow({ l, p, paid, balance, collateral, onOpenDoc, onUpdate, onDelete, onDeletePayment, onPay }) {
	const [note, setNote] = (0, import_react.useState)(l.admin_note ?? "");
	const [amt, setAmt] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [edit, setEdit] = (0, import_react.useState)({
		amount: Number(l.amount),
		weeks: l.weeks,
		frequency: l.frequency
	});
	const [colNote, setColNote] = (0, import_react.useState)(l.collateral_note ?? "");
	const [ref, setRef] = (0, import_react.useState)(l.disbursement_ref ?? "");
	const who = p?.full_name || "there";
	const msg = l.status === "approved" ? `Hello ${who}, your Avesta loan of ${kwacha(l.amount)} is approved. Total to repay ${kwacha(l.total)}.${l.disbursed_at ? " The money has been sent." : " Please confirm how you'd like to receive it in your portal: https://avesta.solutions/portal"}` : l.status === "rejected" ? `Hello ${who}, sorry — your Avesta loan application of ${kwacha(l.amount)} was not approved.${l.admin_note ? " " + l.admin_note : ""}` : `Hello ${who}, Avesta received your loan application of ${kwacha(l.amount)}. We're reviewing it now.`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "account-strip rounded-xl p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold",
						children: [
							p?.full_name || p?.email || "Customer",
							" · ",
							kwacha(l.amount),
							" for ",
							l.weeks,
							" wk (",
							l.rate,
							"%)"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							p?.phone,
							" · ",
							p?.email,
							" ",
							p?.nrc && `· NRC ${p.nrc}`,
							" · ",
							l.frequency,
							" · ",
							new Date(l.created_at).toLocaleDateString()
						]
					}),
					l.purpose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["Purpose: ", l.purpose]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: ["Payout: ", l.payout_method ? `${PAYOUT[l.payout_method] ?? l.payout_method}${l.payout_details ? " — " + l.payout_details : ""}` : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "not given yet"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [l.disbursed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-accent/20 px-2.5 py-0.5 text-xs font-semibold text-accent",
						children: "Money sent"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
						status: l.status,
						tones: statusTone
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm",
				children: [
					"Total ",
					kwacha(l.total),
					" · Paid ",
					kwacha(paid),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-primary",
						children: ["Balance ", kwacha(balance)]
					})
				]
			}),
			l.repayments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-1 flex flex-wrap gap-2 text-xs",
				children: l.repayments.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-1 rounded-full bg-foreground/10 px-2 py-0.5",
					children: [
						kwacha(r.amount),
						" · ",
						new Date(r.paid_at).toLocaleDateString(),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Remove repayment",
							className: "text-destructive",
							onClick: () => onDeletePayment(r.id),
							children: "×"
						})
					]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [
					l.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "copper",
						onClick: () => onUpdate({
							status: "approved",
							admin_note: note
						}),
						children: "Approve"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						onClick: () => onUpdate({
							status: "rejected",
							admin_note: note
						}),
						children: "Reject"
					})] }),
					l.status === "approved" && l.disbursed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex w-full flex-wrap gap-2 sm:w-auto",
						onSubmit: (e) => {
							e.preventDefault();
							const n = Number(amt);
							if (n > 0) {
								onPay(n);
								setAmt("");
							}
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "min-w-0 flex-1 sm:w-32 sm:flex-none",
							type: "number",
							step: "0.01",
							placeholder: "Amount",
							value: amt,
							onChange: (e) => setAmt(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "copper",
							type: "submit",
							children: "Record payment"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "min-w-0 flex-1 basis-full sm:basis-48",
						placeholder: "Note to customer",
						value: note,
						onChange: (e) => setNote(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						onClick: () => onUpdate({ admin_note: note }),
						children: "Save note"
					})
				]
			}),
			(l.status === "pending" || l.status === "approved") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 rounded-lg bg-foreground/5 p-3 text-sm md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: ["Collateral ", l.collateral_required ? "(requested)" : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "What collateral? e.g. laptop, TV, title deed",
							value: colNote,
							onChange: (e) => setColNote(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => onUpdate({
									collateral_required: true,
									collateral_note: colNote || null
								}),
								children: l.collateral_required ? "Update request" : "Request collateral"
							}), l.collateral_required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								onClick: () => onUpdate({ collateral_required: false }),
								children: "Not needed"
							})]
						}),
						collateral.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: collateral.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => onOpenDoc(d.file_path),
								children: d.file_name
							}, d.id))
						})
					]
				}), l.status === "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Send the money"
					}), l.disbursed_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Sent ",
						new Date(l.disbursed_at).toLocaleString(),
						l.disbursement_ref && ` · ref ${l.disbursement_ref}`
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Transaction / receipt reference",
							value: ref,
							onChange: (e) => setRef(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "copper",
							disabled: l.collateral_required && collateral.length === 0,
							onClick: () => onUpdate({
								disbursed_at: (/* @__PURE__ */ new Date()).toISOString(),
								disbursement_ref: ref || null
							}),
							children: "Mark money sent"
						}),
						l.collateral_required && collateral.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Waiting for the customer's collateral."
						})
					] })]
				})]
			}),
			editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex flex-wrap items-end gap-2 rounded-lg bg-foreground/5 p-3 text-sm",
				onSubmit: (e) => {
					e.preventDefault();
					const q = loanQuote(edit.amount, edit.weeks, edit.frequency);
					onUpdate({
						amount: edit.amount,
						weeks: edit.weeks,
						frequency: edit.frequency,
						rate: q.rate,
						total: q.total
					});
					setEditing(false);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs",
							children: "Amount (K)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "w-28",
							type: "number",
							min: 1,
							value: edit.amount,
							onChange: (e) => setEdit({
								...edit,
								amount: Number(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs",
							children: "Weeks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "h-9 rounded-md border border-input bg-transparent px-2 [&>option]:bg-popover",
							value: edit.weeks,
							onChange: (e) => setEdit({
								...edit,
								weeks: Number(e.target.value)
							}),
							children: [
								1,
								2,
								3,
								4
							].map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: w }, w))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs",
							children: "Repayment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-9 rounded-md border border-input bg-transparent px-2 [&>option]:bg-popover",
							value: edit.frequency,
							onChange: (e) => setEdit({
								...edit,
								frequency: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "weekly",
									children: "Weekly"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bi-weekly",
									children: "Bi-weekly"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "monthly",
									children: "Once at end"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs",
							children: "Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "h-9 rounded-md border border-input bg-transparent px-2 [&>option]:bg-popover",
							defaultValue: l.status,
							onChange: (e) => onUpdate({ status: e.target.value }),
							children: [
								"pending",
								"approved",
								"paid",
								"rejected"
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "copper",
						type: "submit",
						children: "Save changes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "quiet",
						type: "button",
						onClick: () => setEditing(false),
						children: "Cancel"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					p?.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "glass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: waLink(p.phone, msg),
							target: "_blank",
							rel: "noopener noreferrer",
							children: "WhatsApp customer"
						})
					}),
					p?.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "glass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${p.email}?subject=${encodeURIComponent("Your Avesta loan")}&body=${encodeURIComponent(msg)}`,
							children: "Email customer"
						})
					}),
					(l.status === "approved" || l.status === "paid") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "copper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/schedule/$loanId",
							params: { loanId: l.id },
							children: "Repayment schedule"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "glass",
						onClick: () => setEditing((x) => !x),
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "quiet",
						className: "text-destructive",
						onClick: onDelete,
						children: "Delete"
					})
				]
			})
		]
	});
}
function ItPanel() {
	const qc = useQueryClient();
	const profiles = useProfiles();
	const reqs = useQuery({
		queryKey: ["admin-it"],
		queryFn: async () => (await supabase.from("it_requests").select("*").order("created_at", { ascending: false })).data ?? []
	});
	const update = useMutation({
		mutationFn: async (v) => {
			const { id, ...rest } = v;
			const { error } = await supabase.from("it_requests").update(rest).eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Request updated");
			qc.invalidateQueries({ queryKey: ["admin-it"] });
			qc.invalidateQueries({ queryKey: ["admin-stats"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("it_requests").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Request deleted");
			qc.invalidateQueries({ queryKey: ["admin-it"] });
			qc.invalidateQueries({ queryKey: ["admin-stats"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 space-y-3",
		children: [reqs.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "No IT requests yet."
		}), reqs.data?.map((r) => {
			const p = profiles.data?.find((x) => x.id === r.user_id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "account-strip rounded-xl p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: [
								r.service,
								" · ",
								p?.full_name || p?.email
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
							status: r.status,
							tones: statusTone
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							p?.phone,
							" · ",
							r.location,
							" · ",
							new Date(r.created_at).toLocaleDateString()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 whitespace-pre-line text-sm",
						children: r.details
					}),
					r.ai_reply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "mt-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
							className: "cursor-pointer text-muted-foreground",
							children: "Assistant already replied — view"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 whitespace-pre-line",
							children: r.ai_reply
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-wrap gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const v = String(new FormData(e.currentTarget).get("reply") ?? "").trim();
							if (v) update.mutate({
								id: r.id,
								admin_note: v,
								status: r.status === "open" ? "in_progress" : r.status
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							name: "reply",
							"aria-label": "Reply to customer",
							defaultValue: r.admin_note ?? "",
							placeholder: "Reply to the customer…",
							className: "min-h-16 flex-1 rounded-md border border-input bg-background p-2 text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							variant: "copper",
							children: "Send reply"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							[
								"open",
								"in_progress",
								"completed",
								"cancelled"
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: r.status === s ? "copper" : "glass",
								onClick: () => update.mutate({
									id: r.id,
									status: s
								}),
								children: s.replace("_", " ")
							}, s)),
							p?.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "glass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: waLink(p.phone, `Hello ${p.full_name ?? ""}, this is Avesta IT support about your ${r.service} request.`),
									target: "_blank",
									rel: "noreferrer",
									children: "WhatsApp"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								className: "text-destructive",
								onClick: () => {
									if (confirm("Delete this IT request?")) remove.mutate(r.id);
								},
								children: "Delete"
							})
						]
					})
				]
			}, r.id);
		})]
	});
}
/**
* What the assistant could not answer.
*
* Every unmatched question lands here. An admin writes the answer once, and
* from then on the troubleshooter gives it instantly, free, to everyone who
* asks the same thing. That is the whole of the "learning": a person decides
* what Avesta tells customers, never whatever a customer happened to type.
*/
function LearningPanel() {
	const qc = useQueryClient();
	const { data, isLoading } = useQuery({
		queryKey: ["learning-queue"],
		queryFn: () => learningQueue()
	});
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		title: "",
		answer: "",
		try: "",
		stop: "",
		service: "Computer repair & maintenance",
		match: ""
	});
	const rows = data?.questions ?? [];
	function start(q) {
		setOpenId(q.id);
		const drafted = (q.answer ?? "").replace(/\[blocked[^\]]*\]/, "");
		const answerLine = drafted.match(/ANSWER:\s*([\s\S]*?)(?=\nSTEPS:|$)/i)?.[1]?.trim() ?? "";
		const steps = (drafted.match(/STEPS:\s*([\s\S]*?)(?=\nSTOP:|$)/i)?.[1] ?? "").split("\n").map((l) => l.replace(/^[-*\s]+/, "").trim()).filter(Boolean).join("\n");
		const stopLine = drafted.match(/STOP:\s*([\s\S]*)$/i)?.[1]?.trim() ?? "";
		setForm({
			title: "",
			answer: answerLine,
			try: steps,
			stop: stopLine,
			service: "Computer repair & maintenance",
			match: q.question.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 3).slice(0, 6).join(", ")
		});
	}
	async function save(logId) {
		setSaving(true);
		try {
			await promoteToTopic({ data: {
				logId,
				title: form.title.trim(),
				answer: form.answer.trim(),
				try: form.try.split("\n").map((x) => x.trim()).filter(Boolean),
				stop: form.stop.trim(),
				service: form.service.trim(),
				match: form.match.split(",").map((x) => x.trim().toLowerCase()).filter(Boolean)
			} });
			toast.success("Saved — the assistant answers this from now on.");
			setOpenId(null);
			await qc.invalidateQueries({ queryKey: ["learning-queue"] });
		} catch (e) {
			toast.error(e.message);
		}
		setSaving(false);
	}
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mt-6 text-muted-foreground",
		children: "Loading…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Questions the topic list could not answer. Write an answer once and everyone who asks the same thing gets it instantly, with no AI cost. ",
					rows.length,
					" waiting."
				]
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-border p-4 text-sm",
				children: "Nothing waiting — the topics answered everything asked so far."
			}),
			rows.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: q.question
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [new Date(q.created_at).toLocaleDateString("en-GB"), q.answered_by === "web" ? " · researched online" : " · no answer given"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: openId === q.id ? "glass" : "copper",
						onClick: () => openId === q.id ? setOpenId(null) : start(q),
						children: openId === q.id ? "Close" : "Write the answer"
					})]
				}), openId === q.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Title — e.g. Laptop battery will not charge",
							value: form.title,
							onChange: (e) => setForm({
								...form,
								title: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							placeholder: "What is usually wrong, in plain words",
							value: form.answer,
							onChange: (e) => setForm({
								...form,
								answer: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							placeholder: "Safe steps — one per line",
							className: "min-h-28",
							value: form.try,
							onChange: (e) => setForm({
								...form,
								try: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "When to stop and call us",
							value: form.stop,
							onChange: (e) => setForm({
								...form,
								stop: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Which service this belongs to",
							value: form.service,
							onChange: (e) => setForm({
								...form,
								service: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Words that should find it, separated by commas",
							value: form.match,
							onChange: (e) => setForm({
								...form,
								match: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Anything telling a customer to format a drive, delete from Windows folders or switch off their antivirus is refused when saving, however the wording is arranged."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "copper",
							disabled: saving || form.title.trim().length < 4 || form.answer.trim().length < 10,
							onClick: () => void save(q.id),
							children: saving ? "Saving…" : "Add to the assistant"
						})
					]
				})]
			}, q.id))
		]
	});
}
function CustomersPanel({ currentUserId }) {
	const qc = useQueryClient();
	const deleteCustomerFn = useServerFn(deleteCustomer);
	const profiles = useProfiles();
	const privileged = useQuery({
		queryKey: ["privileged-customers"],
		queryFn: async () => {
			const { data, error } = await supabase.from("user_roles").select("user_id, role").in("role", ["admin", "staff"]);
			if (error) throw error;
			return new Set(data.map((entry) => entry.user_id));
		}
	});
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [deletingId, setDeletingId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		full_name: "",
		phone: "",
		nrc: ""
	});
	const save = async () => {
		const { error } = await supabase.from("profiles").update(form).eq("id", editId);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Customer updated");
		setEditId(null);
		qc.invalidateQueries({ queryKey: ["all-profiles"] });
	};
	const removeDoc = async (id, path) => {
		if (!confirm("Delete this document?")) return;
		await supabase.storage.from("borrower-docs").remove([path]);
		const { error } = await supabase.from("loan_documents").delete().eq("id", id);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Document deleted");
		qc.invalidateQueries({ queryKey: ["admin-documents"] });
	};
	const documents = useQuery({
		queryKey: ["admin-documents"],
		queryFn: async () => {
			const { data, error } = await supabase.from("loan_documents").select("*").order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const openDocument = async (path) => {
		const { data, error } = await supabase.storage.from("borrower-docs").createSignedUrl(path, 60);
		if (error) {
			toast.error(error.message);
			return;
		}
		window.open(data.signedUrl, "_blank", "noopener,noreferrer");
	};
	const label = {
		nrc: "NRC",
		payslip: "Payslip",
		residence: "Residence",
		other: "Other",
		collateral: "Collateral"
	};
	const removeCustomer = async (id, name) => {
		if (!confirm(`Permanently delete ${name} and all their loans, documents and IT requests? This cannot be undone. Download a backup first if unsure.`)) return;
		setDeletingId(id);
		try {
			await deleteCustomerFn({ data: { userId: id } });
			toast.success("Customer deleted");
			await qc.invalidateQueries();
		} catch (error) {
			toast.error(error.message);
		} finally {
			setDeletingId(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted-foreground",
			children: "Edit a customer or permanently remove an account. Download a full backup from Backup & admins before deleting records."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-4",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pr-4",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pr-4",
							children: "Phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pr-4",
							children: "NRC"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pr-4",
							children: "Documents"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pr-4",
							children: "Joined"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Actions" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: profiles.data?.map((p) => {
					const borrowerDocs = documents.data?.filter((d) => d.user_id === p.id) ?? [];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-foreground/10 align-top",
						children: [
							editId === p.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "Full name",
										value: form.full_name,
										onChange: (e) => setForm({
											...form,
											full_name: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4",
									children: p.email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "Phone",
										value: form.phone,
										onChange: (e) => setForm({
											...form,
											phone: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "NRC",
										value: form.nrc,
										onChange: (e) => setForm({
											...form,
											nrc: e.target.value
										})
									})
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4",
									children: p.full_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4",
									children: p.email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4",
									children: p.phone
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 pr-4",
									children: p.nrc
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex min-w-44 flex-wrap gap-1.5",
									children: borrowerDocs.length ? borrowerDocs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "glass",
											onClick: () => openDocument(d.file_path),
											children: label[d.kind] ?? d.kind
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											"aria-label": "Delete document",
											title: "Delete document",
											size: "icon-sm",
											variant: "ghost",
											className: "text-destructive",
											onClick: () => removeDoc(d.id, d.file_path),
											children: "×"
										})]
									}, d.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "None uploaded"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 pr-4",
								children: new Date(p.created_at).toLocaleDateString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3",
								children: editId === p.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "copper",
										onClick: save,
										children: "Save"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "quiet",
										onClick: () => setEditId(null),
										children: "Cancel"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "glass",
										onClick: () => {
											setEditId(p.id);
											setForm({
												full_name: p.full_name ?? "",
												phone: p.phone ?? "",
												nrc: p.nrc ?? ""
											});
										},
										children: "Edit"
									}), !privileged.isLoading && !privileged.isError && !privileged.data?.has(p.id) && p.id !== currentUserId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "quiet",
										className: "text-destructive",
										disabled: deletingId !== null,
										onClick: () => removeCustomer(p.id, p.full_name || p.email || "this customer"),
										children: deletingId === p.id ? "Deleting…" : "Delete"
									})]
								})
							})
						]
					}, p.id);
				}) })]
			})
		})]
	});
}
var BACKUP_TABLES = [
	"profiles",
	"loans",
	"loan_instalments",
	"repayments",
	"loan_documents",
	"it_requests",
	"user_roles"
];
function DataPanel() {
	const qc = useQueryClient();
	const listAdminsFn = useServerFn(listAdmins);
	const admins = useQuery({
		queryKey: ["admins"],
		queryFn: () => listAdminsFn()
	});
	const addAdminFn = useServerFn(addAdmin);
	const removeAdminFn = useServerFn(removeAdmin);
	const [email, setEmail] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const refreshAll = () => qc.invalidateQueries();
	const backup = async () => {
		setBusy(true);
		try {
			const out = {
				created_at: (/* @__PURE__ */ new Date()).toISOString(),
				site: "avesta.solutions"
			};
			for (const t of BACKUP_TABLES) {
				const { data, error } = await supabase.from(t).select("*");
				if (error) throw error;
				out[t] = data;
			}
			const blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
			const a = document.createElement("a");
			a.href = URL.createObjectURL(blob);
			a.download = `avesta-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
			a.click();
			URL.revokeObjectURL(a.href);
			toast.success("Backup downloaded");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const clear = async (label, run) => {
		if (!confirm(`${label}? This cannot be undone. Download a backup first if unsure.`)) return;
		setBusy(true);
		const { error } = await run();
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Cleared");
		refreshAll();
	};
	const clearTests = async () => {
		const { data } = await supabase.from("loans").select("id, purpose, admin_note");
		const ids = (data ?? []).filter((l) => /test|ignore/i.test(`${l.purpose ?? ""} ${l.admin_note ?? ""}`)).map((l) => l.id);
		if (!ids.length) {
			toast.info("No test loans found");
			return;
		}
		await clear(`Delete ${ids.length} test loan(s)`, () => supabase.from("loans").delete().in("id", ids));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "account-strip rounded-xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold",
						children: "Back up"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Download all customers, loans, schedules, repayments, documents list, IT requests and staff roles as one file. Keep it somewhere safe — it contains private customer details."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						variant: "copper",
						disabled: busy,
						onClick: backup,
						children: "Download full backup"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "account-strip rounded-xl p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Clear information you don't need"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							disabled: busy,
							onClick: clearTests,
							children: "Delete test / practice loans"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							disabled: busy,
							onClick: () => clear("Delete all rejected loans", () => supabase.from("loans").delete().eq("status", "rejected")),
							children: "Delete rejected loans"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							disabled: busy,
							onClick: () => clear("Delete all fully paid loans", () => supabase.from("loans").delete().eq("status", "paid")),
							children: "Delete paid loans"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							disabled: busy,
							onClick: () => clear("Delete completed and cancelled IT requests", () => supabase.from("it_requests").delete().in("status", ["completed", "cancelled"])),
							children: "Delete finished IT requests"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							disabled: busy,
							onClick: () => clear("Delete all your notifications", async () => {
								const { data } = await supabase.auth.getUser();
								return supabase.from("notifications").delete().eq("user_id", data.user.id);
							}),
							children: "Clear my notifications"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "account-strip rounded-xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold",
						children: "Administrators"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid gap-2 text-sm",
						children: admins.data?.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 border-t border-foreground/10 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								a.name ?? "—",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: a.email
								}),
								a.isYou && " (you)"
							] }), !a.isYou && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "quiet",
								className: "text-destructive",
								onClick: async () => {
									if (!confirm(`Remove admin access for ${a.email}?`)) return;
									try {
										await removeAdminFn({ data: { userId: a.id } });
										toast.success("Admin removed");
										admins.refetch();
									} catch (e) {
										toast.error(e.message);
									}
								},
								children: "Remove admin"
							})]
						}, a.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-4 flex flex-wrap gap-2",
						onSubmit: async (e) => {
							e.preventDefault();
							try {
								await addAdminFn({ data: { email } });
								toast.success("Admin added");
								setEmail("");
								admins.refetch();
							} catch (err) {
								toast.error(err.message);
							}
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "max-w-xs",
							type: "email",
							required: true,
							placeholder: "Email of their Avesta account",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "copper",
							children: "Add admin"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: "The person must create an account on the site first."
					})
				]
			})
		]
	});
}
//#endregion
export { Admin as component };
