import { i as __toESM } from "../_runtime.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { r as PageNavigation } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Dz64RFdN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-CUP7WvcF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reset() {
	const [pw, setPw] = (0, import_react.useState)("");
	const [confirmPw, setConfirmPw] = (0, import_react.useState)("");
	const [recoveryReady, setRecoveryReady] = (0, import_react.useState)(false);
	const [checking, setChecking] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(`${window.location.search}&${window.location.hash.slice(1)}`);
		const isRecoveryLink = params.get("type") === "recovery" || params.has("code");
		if (isRecoveryLink) setRecoveryReady(true);
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event === "PASSWORD_RECOVERY") setRecoveryReady(true);
		});
		supabase.auth.getSession().then(({ data: sessionData }) => {
			if (isRecoveryLink && sessionData.session) setRecoveryReady(true);
			setChecking(false);
		});
		return () => data.subscription.unsubscribe();
	}, []);
	async function submit(e) {
		e.preventDefault();
		if (!recoveryReady) {
			toast.error("Open the password reset link sent to your email.");
			return;
		}
		if (pw !== confirmPw) {
			toast.error("Passwords do not match.");
			return;
		}
		setBusy(true);
		const { error } = await supabase.auth.updateUser({ password: pw });
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Password updated");
		navigate({ to: "/dashboard" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "page-enter grid min-h-screen place-items-center px-5 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageNavigation, { className: "mb-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "service-door space-y-4 rounded-2xl p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Set a new password"
				}), checking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Checking your reset link…"
				}) : recoveryReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-password",
							children: "New password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "new-password",
							type: "password",
							autoComplete: "new-password",
							minLength: 6,
							required: true,
							value: pw,
							onChange: (e) => setPw(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "confirm-password",
							children: "Confirm new password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "confirm-password",
							type: "password",
							autoComplete: "new-password",
							minLength: 6,
							required: true,
							value: confirmPw,
							onChange: (e) => setConfirmPw(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "copper",
						className: "w-full",
						type: "submit",
						disabled: busy,
						children: busy ? "Saving…" : "Save password"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "This reset link is missing or has expired. Request a new one from the sign-in page."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "copper",
					className: "w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/auth",
						children: "Request a new reset link"
					})
				})] })]
			})]
		})
	});
}
//#endregion
export { Reset as component };
