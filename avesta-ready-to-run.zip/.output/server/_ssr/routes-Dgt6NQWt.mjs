import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { C as Headphones, N as ArrowRight, O as Check, _ as Mail, c as ShieldCheck, d as Phone, g as MapPin, h as MapPinned, k as Calculator, l as Scale, m as MessageCircle, p as MonitorCog, r as Wallet, s as Sparkles } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dgt6NQWt.js
var import_jsx_runtime = require_jsx_runtime();
var lendingServices = [
	"1–4 week terms",
	"15–30% interest",
	"Weekly, bi-weekly or monthly repayment",
	"Apply and track online"
];
var itServices = [
	"Computer repairs & networks",
	"CCTV & cybersecurity",
	"Websites & databases",
	"Data services & training"
];
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: "#top",
		className: "group flex min-w-0 items-center gap-2 sm:gap-3",
		"aria-label": "Avesta Enterprises home",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-10 shrink-0 place-items-center rounded-md bg-primary font-display text-base font-bold text-primary-foreground transition-transform group-hover:-rotate-2 sm:size-11",
			children: "AE"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-display text-sm font-semibold text-foreground sm:text-lg",
				children: "Avesta Enterprises"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted-foreground",
				children: "Zambia"
			})]
		})]
	});
}
function ServiceDoor({ id, label, number, title, description, services, action, href, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		id,
		className: `service-door group relative flex h-full min-h-[19rem] flex-col overflow-hidden rounded-lg p-5 sm:p-6 ${tone === "copper" ? "service-door-copper" : "service-door-sage"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute right-0 top-0 h-24 w-24 border-b border-l border-primary/15 sm:h-32 sm:w-32",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mb-3 flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `service-pill ${tone === "copper" ? "service-pill-copper" : "service-pill-sage"}`,
					children: label
				}), tone === "copper" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
					className: "size-5 text-primary",
					"aria-hidden": "true"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonitorCog, {
					className: "size-5 text-accent",
					"aria-hidden": "true"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "relative mt-auto mb-2 text-[12px] font-bold uppercase text-primary",
				children: number
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "relative font-display text-2xl font-bold leading-tight text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative mt-2 text-sm leading-6 text-muted-foreground",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "relative mt-4 grid gap-1.5 text-xs text-foreground/85 sm:grid-cols-2",
				children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `mt-0.5 grid size-4 shrink-0 place-items-center rounded-full ${tone === "copper" ? "bg-primary/20 text-primary" : "bg-accent/20 text-accent"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-2.5",
							strokeWidth: 3
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: service })]
				}, service))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `relative mt-4 border-t pt-3 ${tone === "copper" ? "border-primary/20" : "border-accent/20"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "link",
					className: "h-auto p-0 text-primary hover:text-gold-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: href === "/dashboard" ? "/dashboard" : "/it-help",
						className: "reveal-line inline-flex items-center gap-2 font-display text-sm font-semibold",
						children: [action, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "arrow size-4" })]
					})
				})
			})
		]
	});
}
function Index() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		id: "top",
		className: "min-h-screen overflow-hidden bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen w-full max-w-[88rem] flex-col px-5 sm:px-8 lg:px-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b border-primary/15 py-5 sm:gap-4 sm:py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex items-center gap-2 sm:gap-5",
						"aria-label": "Main navigation",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "reveal-line hidden py-2 text-sm text-foreground/75 sm:inline-flex",
							children: "Contact"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "glass",
							size: "default",
							className: "max-[350px]:px-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								children: "Sign in"
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 py-6 sm:gap-5 md:grid-cols-12 md:grid-rows-[repeat(2,minmax(19rem,1fr))] md:py-8",
					"aria-label": "Avesta services",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rise architectural-panel relative flex min-h-[28rem] flex-col justify-between overflow-hidden rounded-lg p-6 sm:p-10 md:col-span-8 md:row-span-2 lg:p-12",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pointer-events-none absolute right-0 top-0 h-40 w-40 border-b border-l border-primary/15 sm:h-56 sm:w-56",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-6 flex items-start gap-2 text-xs font-semibold uppercase text-primary",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-3.5 shrink-0" }), "Serving all of Zambia · Head office, Ndola"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
											className: "max-w-[14ch] font-display text-4xl font-extrabold leading-[1.13] break-words text-foreground sm:text-5xl lg:text-6xl",
											children: ["Avesta Enterprises", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-primary",
												children: "."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-6 max-w-[34rem] text-base leading-7 text-muted-foreground sm:text-lg sm:leading-8",
											children: "Fair short-term finance and hands-on IT support, delivered across Zambia with clear terms and grounded care."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mt-10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "copper",
											size: "roomy",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/dashboard",
												children: ["Explore lending ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											variant: "glass",
											size: "roomy",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/it-help",
												children: "Explore IT services"
											})
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 grid max-w-lg grid-cols-2 gap-4 border-t border-primary/20 pt-5 text-sm text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-primary" }), " Clear terms"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-4 text-accent" }), " Local support"]
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rise rise-2 md:col-span-4 md:row-span-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceDoor, {
								id: "lending",
								label: "Avesta Lending",
								number: "Door 01",
								title: "Short-term finance",
								description: "For individuals and small businesses, with costs stated before you commit.",
								services: lendingServices,
								action: "Start a loan application",
								href: "/dashboard",
								tone: "copper"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rise rise-3 md:col-span-4 md:row-span-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceDoor, {
								id: "it",
								label: "Avesta Consulting",
								number: "Door 02",
								title: "IT services & support",
								description: "Practical technology support for the systems your home or business depends on.",
								services: itServices,
								action: "Open live IT support",
								href: "/it-help",
								tone: "sage"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "account",
					className: "account-strip my-4 grid gap-5 rounded-lg px-5 py-5 sm:grid-cols-[1fr_auto] sm:items-center sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base font-semibold",
						children: "Already have an Avesta account?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Sign in to apply for a loan, request IT support, or track progress. Not sure what you need? ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/advisor",
								className: "text-primary underline",
								children: "Ask our free advisor"
							}),
							"."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "copper",
						size: "roomy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/auth",
							children: "Sign in or create account"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					id: "contact",
					className: "mt-4 flex flex-col gap-4 border-t border-foreground/10 py-7 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Avesta Enterprises · Ndola, Zambia"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						"aria-label": "Footer links",
						className: "grid grid-cols-5 justify-items-start gap-2 sm:flex sm:flex-wrap sm:items-center sm:gap-x-5 sm:gap-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								href: "tel:+260971013108",
								"aria-label": "Call 0971 013 108",
								title: "Call 0971 013 108",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "0971 013 108"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								href: "https://wa.me/260769974200",
								"aria-label": "WhatsApp",
								title: "WhatsApp",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "WhatsApp"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								href: "mailto:info@avasta.solutions",
								"aria-label": "Email info@avasta.solutions",
								title: "Email info@avasta.solutions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "info@avasta.solutions"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								href: "mailto:avestaenterprises4@gmail.com",
								"aria-label": "Email avestaenterprises4@gmail.com",
								title: "Email avestaenterprises4@gmail.com",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "avestaenterprises4@gmail.com"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								to: "/advisor",
								"aria-label": "Free advisor",
								title: "Free advisor",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Free advisor"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								to: "/tools",
								"aria-label": "Loan calculator and currency",
								title: "Loan calculator and currency",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Loan calculator & currency"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								to: "/it-help",
								"aria-label": "IT help",
								title: "IT help",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "IT help"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								to: "/directory",
								"aria-label": "Directory",
								title: "Directory",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Directory"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								className: "grid size-11 place-items-center rounded-md border border-foreground/15 transition-colors hover:text-foreground sm:size-auto sm:border-0",
								to: "/legal",
								"aria-label": "Privacy and terms",
								title: "Privacy and terms",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, {
									className: "size-5 sm:hidden",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Privacy & terms"
								})]
							})
						]
					})]
				})
			]
		})
	});
}
//#endregion
export { Index as component };
