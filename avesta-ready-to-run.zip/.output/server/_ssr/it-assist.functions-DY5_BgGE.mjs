import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { i as stringType, n as enumType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/it-assist.functions-DY5_BgGE.js
/**
* Which AI answers, and whose account pays for it.
*
* Set AI_BASE_URL, AI_API_KEY and AI_MODEL to use your own account with any
* OpenAI-compatible service — OpenAI, Groq, Together, OpenRouter — or a model
* you run yourself (Ollama, llama.cpp, vLLM all speak the same protocol).
* Without them the assistant is simply off, and says so. Nothing is sent
* anywhere until you choose a provider.
*
* Running the model yourself is also the only arrangement where the question
* text never leaves your own server, which matters for anything a borrower
* types.
*/
var AI_MODEL = process.env["AI_MODEL"] || "openai/gpt-6-astra";
var AttZ = objectType({
	name: stringType().max(200),
	type: stringType().regex(/^(image\/(png|jpeg|webp|gif)|application\/pdf|text\/plain)$/),
	data: stringType().startsWith("data:").max(6e6)
});
var Msg = objectType({
	role: enumType(["user", "assistant"]),
	content: stringType().trim().min(1).max(4e3),
	attachments: arrayType(AttZ).max(4).optional()
});
var itChat = createServerFn({ method: "POST" }).inputValidator((d) => objectType({ messages: arrayType(Msg).min(1).max(30) }).parse(d)).handler(createSsrRpc("62bed3c1c0477d30bf1aef5d1c28d08f110afea4608e5fabd46ec233948169d8"));
var autoReplyTicket = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ id: stringType().uuid() }).parse(d)).handler(createSsrRpc("0c1622454411fadf13257888c96cb3e8749d28765bca3e88502ed8ccbe0ef6bb"));
//#endregion
export { autoReplyTicket as n, itChat as r, AI_MODEL as t };
