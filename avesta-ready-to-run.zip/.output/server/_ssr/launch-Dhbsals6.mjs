import { i as __toESM } from "../_runtime.mjs";
import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as AppHeader, t as AdminOnly } from "./AppHeader-DG15xa67.mjs";
import { t as Route } from "./launch-BPXUBdQL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/launch-Dhbsals6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOMAIN = "avesta.solutions";
var checkDomain = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("775e3ec415bf10866650f14a6c56f70240c979393980b088f01e639562c6eb5b"));
var STEPS = [
	{
		id: "gsc-open",
		title: "Open Google Search Console",
		body: "Go to search.google.com/search-console and sign in with the business Google account.",
		link: "https://search.google.com/search-console"
	},
	{
		id: "gsc-add",
		title: "Add a Domain property",
		body: `Choose “Domain” and type ${DOMAIN}. Google shows a TXT record starting with google-site-verification=.`
	},
	{
		id: "gsc-txt",
		title: "Add Google's TXT record in Hostinger",
		body: "Hostinger → Domains → avesta.solutions → DNS. Add TXT, name @, paste Google's value. Keep the the platform records."
	},
	{
		id: "gsc-verify",
		title: "Click Verify in Search Console",
		body: "If it fails, wait an hour for DNS to update and try again."
	},
	{
		id: "gsc-sitemap",
		title: "Submit the sitemap",
		body: "Search Console → Sitemaps → enter sitemap.xml → Submit. Status should show “Success”."
	},
	{
		id: "gsc-inspect",
		title: "Request indexing of the home page",
		body: `URL Inspection → https://${DOMAIN}/ → Request indexing. Repeat for /advisor.`
	},
	{
		id: "gsc-indexed",
		title: "Confirm pages are indexed",
		body: `After 3–14 days, search Google for site:${DOMAIN}. Check Pages report in Search Console.`,
		link: `https://www.google.com/search?q=site%3A${DOMAIN}`
	},
	{
		id: "gbp",
		title: "Create a Google Business Profile",
		body: "Add your Ndola address, hours and website so you appear on Google Maps.",
		link: "https://business.google.com"
	}
];
function Launch() {
	const { user } = Route.useRouteContext();
	const check = useServerFn(checkDomain);
	const q = useQuery({
		queryKey: ["domain"],
		queryFn: () => check()
	});
	const [done, setDone] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		setDone(JSON.parse(localStorage.getItem("avesta-gsc") || "{}"));
	}, []);
	const toggle = (id) => {
		const next = { ...done };
		if (next[id]) delete next[id];
		else next[id] = (/* @__PURE__ */ new Date()).toLocaleDateString();
		setDone(next);
		localStorage.setItem("avesta-gsc", JSON.stringify(next));
	};
	const count = STEPS.filter((s) => done[s.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOnly, {
		userId: user.id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "page-enter min-h-screen bg-background text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-4xl px-5 sm:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { userId: user.id })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-3xl space-y-10 px-5 py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-serif text-3xl",
							children: ["Domain: ", DOMAIN]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							size: "sm",
							onClick: () => q.refetch(),
							disabled: q.isFetching,
							children: q.isFetching ? "Checking…" : "Check again"
						})]
					}),
					q.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `mt-4 rounded-lg border p-4 ${q.data.live ? "border-accent bg-accent/10" : q.data.dnsReady ? "border-primary bg-primary/10" : "border-destructive bg-destructive/10"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: q.data.live ? "Live — the site loads securely on your domain." : q.data.dnsReady ? "DNS is correct — ready to publish. Secure connection (https) follows shortly after." : "Not ready yet — fix the records marked ✗ in Hostinger."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 divide-y divide-border rounded-lg border border-border",
							children: q.data.checks.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start justify-between gap-4 p-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: c.ok ? "text-accent" : "text-destructive",
										children: c.ok ? "✓" : "✗"
									}),
									" ",
									c.label
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-right text-muted-foreground break-all",
									children: c.found
								})]
							}, c.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: [
								"Checked ",
								new Date(q.data.checkedAt).toLocaleString(),
								". DNS changes can take up to 72 hours."
							]
						})
					] }),
					q.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-destructive",
						children: "Could not check DNS right now."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-serif text-2xl",
						children: [
							"Google Search Console — ",
							count,
							"/",
							STEPS.length,
							" done"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-2 rounded bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 rounded bg-primary",
							style: { width: `${count / STEPS.length * 100}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 space-y-3",
						children: STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 rounded-lg border border-border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4 accent-[var(--primary)]",
								checked: !!done[s.id],
								onChange: () => toggle(s.id),
								"aria-label": s.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-semibold",
										children: [
											i + 1,
											". ",
											s.title,
											done[s.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-2 text-xs text-muted-foreground",
												children: ["done ", done[s.id]]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-muted-foreground",
										children: s.body
									}),
									s.link && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "mt-1 inline-block text-primary underline",
										href: s.link,
										target: "_blank",
										rel: "noreferrer",
										children: "Open"
									})
								]
							})]
						}, s.id))
					})
				] })]
			})]
		})
	});
}
//#endregion
export { Launch as component };
