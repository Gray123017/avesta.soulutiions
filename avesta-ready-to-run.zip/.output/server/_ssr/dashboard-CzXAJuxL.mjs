import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as StatusBadge, n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { t as Textarea } from "./textarea-BPdFvfWe.mjs";
import { a as statusTone, i as loanQuote, r as kwacha, t as IT_SERVICES } from "./avesta-HIuujrtk.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Dz64RFdN.mjs";
import { t as Route } from "./dashboard-DwyvgBJf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CzXAJuxL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var selectCls = "h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm [&>option]:bg-popover";
function Dashboard() {
	const { user } = Route.useRouteContext();
	const qc = useQueryClient();
	const profile = useQuery({
		queryKey: ["profile", user.id],
		queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()).data
	});
	const loans = useQuery({
		queryKey: ["my-loans"],
		queryFn: async () => {
			const { data, error } = await supabase.from("loans").select("*, repayments(*)").eq("user_id", user.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const requests = useQuery({
		queryKey: ["my-it"],
		queryFn: async () => {
			const { data, error } = await supabase.from("it_requests").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const [loan, setLoan] = (0, import_react.useState)({
		amount: 1e3,
		weeks: 2,
		frequency: "weekly",
		purpose: ""
	});
	const quote = loanQuote(loan.amount || 0, loan.weeks, loan.frequency);
	const applyLoan = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("loans").insert({
				user_id: user.id,
				amount: loan.amount,
				weeks: loan.weeks,
				frequency: loan.frequency,
				purpose: loan.purpose
			});
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Loan application submitted");
			qc.invalidateQueries({ queryKey: ["my-loans"] });
			setLoan({
				...loan,
				purpose: ""
			});
		},
		onError: (e) => toast.error(e.message)
	});
	const [it, setIt] = (0, import_react.useState)({
		service: IT_SERVICES[0] ?? "Computer repair",
		details: "",
		location: ""
	});
	const sendIt = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("it_requests").insert({
				user_id: user.id,
				...it
			});
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Support request sent");
			qc.invalidateQueries({ queryKey: ["my-it"] });
			setIt({
				...it,
				details: ""
			});
		},
		onError: (e) => toast.error(e.message)
	});
	const [p, setP] = (0, import_react.useState)(null);
	const pv = p ?? {
		full_name: profile.data?.full_name ?? "",
		phone: profile.data?.phone ?? "",
		nrc: profile.data?.nrc ?? ""
	};
	const saveProfile = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("profiles").update(pv).eq("id", user.id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Profile saved");
			qc.invalidateQueries({ queryKey: ["profile"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "page-enter mx-auto max-w-6xl px-5 pb-16 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { userId: user.id }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-4 font-display text-3xl font-semibold",
				children: ["Welcome", profile.data?.full_name ? `, ${profile.data.full_name}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted-foreground",
				children: "Apply for a loan, track repayments, or request IT support."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "service-door service-door-copper rounded-2xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold text-primary",
						children: "Apply for a loan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-4 space-y-4",
						onSubmit: (e) => {
							e.preventDefault();
							applyLoan.mutate();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount (K)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: 100,
											required: true,
											value: loan.amount,
											onChange: (e) => setLoan({
												...loan,
												amount: Number(e.target.value)
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Term" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											className: selectCls,
											value: loan.weeks,
											onChange: (e) => setLoan({
												...loan,
												weeks: Number(e.target.value)
											}),
											children: [
												1,
												2,
												3,
												4
											].map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: w,
												children: [
													w,
													" week",
													w > 1 ? "s" : ""
												]
											}, w))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Repayment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: selectCls,
											value: loan.frequency,
											onChange: (e) => setLoan({
												...loan,
												frequency: e.target.value
											}),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "weekly",
													children: "Weekly"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "bi-weekly",
													children: "Bi-weekly"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "monthly",
													children: "Monthly"
												})
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Purpose" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: loan.purpose,
									onChange: (e) => setLoan({
										...loan,
										purpose: e.target.value
									}),
									placeholder: "e.g. school fees, stock"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-3 rounded-xl bg-foreground/5 p-4 text-sm min-[420px]:grid-cols-2 sm:grid-cols-4 [&>div]:min-w-0 [&_p]:break-words",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: "Interest"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-semibold",
										children: [quote.rate, "%"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: "Cost"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: kwacha(quote.interest)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: "Total to repay"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold text-primary",
										children: kwacha(quote.total)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-muted-foreground",
										children: [quote.installments, " payment(s) of"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: kwacha(quote.perInstallment)
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "copper",
								type: "submit",
								disabled: applyLoan.isPending,
								children: "Submit application"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "service-door service-door-sage rounded-2xl p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold text-accent",
						children: "Request IT support"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-4 space-y-4",
						onSubmit: (e) => {
							e.preventDefault();
							sendIt.mutate();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Service" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: selectCls,
										value: it.service,
										onChange: (e) => setIt({
											...it,
											service: e.target.value
										}),
										children: IT_SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Location" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: it.location,
										onChange: (e) => setIt({
											...it,
											location: e.target.value
										}),
										placeholder: "Town / area"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "What do you need?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									required: true,
									value: it.details,
									onChange: (e) => setIt({
										...it,
										details: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "glass",
								type: "submit",
								disabled: sendIt.isPending,
								children: "Send request"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "My loans"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [loans.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No loans yet."
					}), loans.data?.map((l) => {
						const paid = l.repayments.reduce((s, r) => s + Number(r.amount), 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "account-strip rounded-xl p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-semibold",
										children: [
											kwacha(l.amount),
											" · ",
											l.weeks,
											" wk · ",
											l.rate,
											"%"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
										status: l.status,
										tones: statusTone
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: [
										"Total ",
										kwacha(l.total),
										" · Paid ",
										kwacha(paid),
										" · Balance ",
										kwacha(Math.max(0, Number(l.total) - paid)),
										" · Applied ",
										new Date(l.created_at).toLocaleDateString()
									]
								}),
								l.admin_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm",
									children: ["Note from Avesta: ", l.admin_note]
								})
							]
						}, l.id);
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "My IT requests"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [requests.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No requests yet."
					}), requests.data?.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "account-strip rounded-xl p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: r.service
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
									status: r.status,
									tones: statusTone
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: r.details
							}),
							r.admin_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: ["Note from Avesta: ", r.admin_note]
							})
						]
					}, r.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 max-w-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "My details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						saveProfile.mutate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Full name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pv.full_name,
								onChange: (e) => setP({
									...pv,
									full_name: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pv.phone,
								onChange: (e) => setP({
									...pv,
									phone: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "NRC number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pv.nrc,
								onChange: (e) => setP({
									...pv,
									nrc: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "glass",
							type: "submit",
							children: "Save details"
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component };
