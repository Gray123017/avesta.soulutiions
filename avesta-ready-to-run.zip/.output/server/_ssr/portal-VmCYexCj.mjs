import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as StatusBadge, n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { a as statusTone, r as kwacha } from "./avesta-HIuujrtk.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./portal-CZ-FEVz6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portal-VmCYexCj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOC_KINDS = [
	{
		id: "nrc",
		label: "NRC (front & back)"
	},
	{
		id: "payslip",
		label: "Payslip or proof of income"
	},
	{
		id: "residence",
		label: "Proof of residence"
	},
	{
		id: "collateral",
		label: "Collateral (photo / proof of ownership)"
	},
	{
		id: "other",
		label: "Other"
	}
];
function nextSteps(status, missing) {
	const docs = missing.length ? [`Upload: ${missing.join(", ")}.`] : [];
	switch (status) {
		case "pending": return [
			...docs,
			"Our staff are reviewing your application — usually within 1 working day.",
			"Keep your phone on; we may call to confirm details."
		];
		case "approved": return [
			"Choose how you want to receive the money (mobile money, bank or cash) under My applications.",
			"If collateral is requested, upload a photo or proof of ownership there.",
			"Avesta sends the money and you get a notification with the reference.",
			"Repay the total shown by the due date to keep a good record."
		];
		case "rejected": return ["This application was not approved. See the staff note if any.", "You can apply again or ask us on WhatsApp what would help."];
		case "paid": return ["Fully repaid — thank you! You're eligible to apply again."];
		default: return docs;
	}
}
function Portal() {
	const { user } = Route.useRouteContext();
	const qc = useQueryClient();
	const [kind, setKind] = (0, import_react.useState)("nrc");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const loans = useQuery({
		queryKey: ["portal-loans"],
		queryFn: async () => {
			const { data, error } = await supabase.from("loans").select("*, repayments(*), loan_instalments(*)").eq("user_id", user.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const docs = useQuery({
		queryKey: ["portal-docs"],
		queryFn: async () => {
			const { data, error } = await supabase.from("loan_documents").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const tickets = useQuery({
		queryKey: ["portal-tickets"],
		queryFn: async () => {
			const { data, error } = await supabase.from("it_requests").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const have = new Set((docs.data ?? []).map((d) => d.kind));
	const missing = DOC_KINDS.filter((k) => k.id !== "other" && k.id !== "collateral" && !have.has(k.id)).map((k) => k.label);
	async function upload(file) {
		if (file.size > 10485760) {
			toast.error("File must be under 10MB");
			return;
		}
		setBusy(true);
		try {
			const path = `${user.id}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
			const up = await supabase.storage.from("borrower-docs").upload(path, file);
			if (up.error) throw up.error;
			const ins = await supabase.from("loan_documents").insert({
				user_id: user.id,
				kind,
				file_path: path,
				file_name: file.name,
				loan_id: loans.data?.[0]?.id ?? null
			});
			if (ins.error) throw ins.error;
			toast.success("Document uploaded");
			qc.invalidateQueries({ queryKey: ["portal-docs"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function view(path) {
		const { data, error } = await supabase.storage.from("borrower-docs").createSignedUrl(path, 60);
		if (error) {
			toast.error(error.message);
			return;
		}
		window.open(data.signedUrl, "_blank");
	}
	async function remove(id, path) {
		await supabase.storage.from("borrower-docs").remove([path]);
		await supabase.from("loan_documents").delete().eq("id", id);
		qc.invalidateQueries({ queryKey: ["portal-docs"] });
	}
	const latest = loans.data?.[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-enter min-h-screen bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-5xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { userId: user.id })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-4xl space-y-8 px-4 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Borrower portal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "Your application status, documents and what happens next."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border bg-card p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 text-lg font-semibold",
						children: "Next steps"
					}), latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "list-decimal space-y-1 pl-5 text-sm",
						children: nextSteps(latest.status, missing).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, s))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You haven't applied yet." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "copper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/dashboard",
									children: "Apply for a loan"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/advisor",
									children: "Ask the advisor"
								})
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-lg font-semibold",
							children: "My applications"
						}),
						!loans.data?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No applications yet."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: loans.data?.map((l) => {
								const paid = (l.repayments ?? []).reduce((s, r) => s + Number(r.amount), 0);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-md border p-4 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium",
												children: [
													kwacha(Number(l.amount)),
													" · ",
													l.weeks,
													" week",
													l.weeks > 1 ? "s" : ""
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
												status: l.status,
												tones: statusTone
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-muted-foreground",
											children: [
												"Applied ",
												new Date(l.created_at).toLocaleDateString(),
												" · Total to repay ",
												kwacha(Number(l.total)),
												" · Paid ",
												kwacha(paid),
												" · Balance ",
												kwacha(Math.max(0, Number(l.total) - paid))
											]
										}),
										l.admin_note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1",
											children: ["Staff note: ", l.admin_note]
										}),
										l.schedule_sent_at && (l.loan_instalments ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 rounded-md bg-foreground/5 p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold",
												children: "Repayment schedule"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "mt-1 space-y-1",
												children: [...l.loan_instalments ?? []].sort((a, b) => a.due_date.localeCompare(b.due_date)).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex justify-between gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: (/* @__PURE__ */ new Date(i.due_date + "T00:00:00")).toLocaleDateString(void 0, {
														day: "numeric",
														month: "short",
														year: "numeric"
													}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														kwacha(Number(i.amount)),
														" ",
														i.paid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-accent",
															children: "· paid"
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-muted-foreground",
															children: "· due"
														})
													] })]
												}, i.id))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoanFlow, {
											loan: l,
											userId: user.id,
											onDone: () => {
												qc.invalidateQueries({ queryKey: ["portal-loans"] });
												qc.invalidateQueries({ queryKey: ["portal-docs"] });
											},
											collateralCount: (docs.data ?? []).filter((d) => d.kind === "collateral" && d.loan_id === l.id).length
										})
									]
								}, l.id);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-lg font-semibold",
							children: "My IT help tickets"
						}),
						!tickets.data?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: ["No tickets yet. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/it-help",
								className: "text-primary underline",
								children: "Get IT help"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: tickets.data?.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border p-4 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: t.service
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
											status: t.status,
											tones: statusTone
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 whitespace-pre-line text-muted-foreground",
										children: t.details
									}),
									t.ai_reply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 whitespace-pre-line rounded-md border border-border p-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Assistant first reply:" }),
											" ",
											t.ai_reply
										]
									}),
									t.admin_note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 rounded-md bg-primary/10 p-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Technician reply:" }),
											" ",
											t.admin_note
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-muted-foreground",
										children: "A technician will follow up soon."
									})
								]
							}, t.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border bg-card p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-lg font-semibold",
							children: "My documents"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex min-w-0 flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								"aria-label": "Document type",
								value: kind,
								onChange: (e) => setKind(e.target.value),
								className: "h-9 w-full min-w-0 rounded-md border border-input bg-transparent px-3 text-sm sm:w-auto [&>option]:bg-popover",
								children: DOC_KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k.id,
									children: k.label
								}, k.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"aria-label": "Upload document",
								type: "file",
								accept: "image/*,application/pdf",
								disabled: busy,
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) upload(f);
									e.target.value = "";
								},
								className: "w-full min-w-0 text-sm sm:w-auto"
							})]
						}),
						!docs.data?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No documents uploaded yet."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "divide-y text-sm",
							children: docs.data?.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex min-w-0 flex-wrap items-center justify-between gap-2 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 break-all",
									children: [
										DOC_KINDS.find((k) => k.id === d.kind)?.label ?? d.kind,
										" — ",
										d.file_name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex shrink-0 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => view(d.file_path),
										children: "View"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => remove(d.id, d.file_path),
										children: "Remove"
									})]
								})]
							}, d.id))
						})
					]
				})
			]
		})]
	});
}
var PAYOUTS = [
	{
		id: "mobile_money",
		label: "Mobile money",
		hint: "Network and number, e.g. MTN 097…"
	},
	{
		id: "bank",
		label: "Bank transfer",
		hint: "Bank, branch, account name and number"
	},
	{
		id: "cash",
		label: "Cash at office",
		hint: "Collect at House No. 3, Thom Avenue, Kansenshi"
	}
];
function LoanFlow({ loan, userId, collateralCount, onDone }) {
	const [method, setMethod] = (0, import_react.useState)(loan.payout_method ?? "mobile_money");
	const [details, setDetails] = (0, import_react.useState)(loan.payout_details ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const canEdit = !loan.disbursed_at && (loan.status === "pending" || loan.status === "approved");
	const steps = [
		{
			label: "Applied",
			done: true
		},
		{
			label: "Decision",
			done: loan.status !== "pending"
		},
		{
			label: "Payout details",
			done: !!loan.payout_method
		},
		...loan.collateral_required ? [{
			label: "Collateral",
			done: collateralCount > 0
		}] : [],
		{
			label: "Money sent",
			done: !!loan.disbursed_at
		},
		{
			label: "Repaid",
			done: loan.status === "paid"
		}
	];
	async function savePayout(e) {
		e.preventDefault();
		if (method !== "cash" && details.trim().length < 5) {
			toast.error("Please add your payout details.");
			return;
		}
		setBusy(true);
		const { error } = await supabase.rpc("set_loan_payout", {
			_loan_id: loan.id,
			_method: method,
			_details: details.trim()
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Payout details saved");
		onDone();
	}
	async function uploadCollateral(file) {
		if (file.size > 10485760) {
			toast.error("File must be under 10MB");
			return;
		}
		setBusy(true);
		const path = `${userId}/collateral-${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
		const up = await supabase.storage.from("borrower-docs").upload(path, file);
		const ins = up.error ? up : await supabase.from("loan_documents").insert({
			user_id: userId,
			kind: "collateral",
			file_path: path,
			file_name: file.name,
			loan_id: loan.id
		});
		setBusy(false);
		if (ins.error) {
			toast.error(ins.error.message);
			return;
		}
		toast.success("Collateral uploaded — Avesta has been notified");
		onDone();
	}
	if (loan.status === "rejected") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-wrap gap-1.5 text-xs",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `rounded-full px-2.5 py-0.5 ${s.done ? "bg-primary text-primary-foreground" : "bg-foreground/10 text-muted-foreground"}`,
					children: [
						i + 1,
						". ",
						s.label
					]
				}, s.label))
			}),
			loan.disbursed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md bg-primary/10 p-2",
				children: [
					"Money sent ",
					new Date(loan.disbursed_at).toLocaleString(),
					loan.disbursement_ref && ` · reference ${loan.disbursement_ref}`
				]
			}),
			canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: savePayout,
				className: "space-y-2 rounded-md border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "How should we send your money?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: PAYOUTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: `m-${loan.id}`,
								checked: method === p.id,
								onChange: () => setMethod(p.id)
							}), p.label]
						}, p.id))
					}),
					method !== "cash" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"aria-label": "Payout details",
						maxLength: 300,
						value: details,
						onChange: (e) => setDetails(e.target.value),
						placeholder: PAYOUTS.find((p) => p.id === method)?.hint,
						className: "h-9 w-full rounded-md border border-input bg-transparent px-3"
					}),
					method === "cash" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [PAYOUTS[2].hint, ". Bring your NRC."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "copper",
						type: "submit",
						disabled: busy,
						children: "Save payout details"
					})
				]
			}),
			loan.collateral_required && !loan.disbursed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-md border border-primary/40 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Collateral requested"
					}),
					loan.collateral_note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: loan.collateral_note
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: collateralCount ? `${collateralCount} file(s) uploaded.` : "Upload a photo of the item or proof of ownership." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						"aria-label": "Upload collateral",
						type: "file",
						accept: "image/*,application/pdf",
						disabled: busy,
						className: "w-full min-w-0 text-sm",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (f) uploadCollateral(f);
							e.target.value = "";
						}
					})
				]
			})
		]
	});
}
//#endregion
export { Portal as component };
