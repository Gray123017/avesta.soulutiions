import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { i as stringType, r as objectType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-tools.functions-7pZSiuET.js
async function assertAdmin(ctx) {
	const { data } = await ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	});
	if (!data) throw new Error("Administrator access required");
	const { supabaseAdmin } = await import("./client.server-B1q0XEiz.mjs");
	return supabaseAdmin;
}
var listAdmins_createServerFn_handler = createServerRpc({
	id: "c8a7e24030f37de350fc982d3af5723fc27c506758ea41bd22ec73fd0618863f",
	name: "listAdmins",
	filename: "src/lib/admin-tools.functions.ts"
}, (opts) => listAdmins.__executeServer(opts));
var listAdmins = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listAdmins_createServerFn_handler, async ({ context }) => {
	const admin = await assertAdmin(context);
	const { data: roles, error } = await admin.from("user_roles").select("user_id").eq("role", "admin");
	if (error) throw new Error(error.message);
	const ids = (roles ?? []).map((r) => r.user_id);
	if (!ids.length) return [];
	const { data: profs } = await admin.from("profiles").select("id, full_name, email").in("id", ids);
	return ids.map((id) => {
		const p = profs?.find((x) => x.id === id);
		return {
			id,
			name: p?.full_name ?? null,
			email: p?.email ?? null,
			isYou: id === context.userId
		};
	});
});
var addAdmin_createServerFn_handler = createServerRpc({
	id: "70a2e888f5b17f1d42c4b7d91733a75478930126c5885a27410ae82fc68cbad2",
	name: "addAdmin",
	filename: "src/lib/admin-tools.functions.ts"
}, (opts) => addAdmin.__executeServer(opts));
var addAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ email: stringType().trim().email().max(255) }).parse(d)).handler(addAdmin_createServerFn_handler, async ({ data, context }) => {
	const admin = await assertAdmin(context);
	const { data: prof } = await admin.from("profiles").select("id").ilike("email", data.email).maybeSingle();
	if (!prof) throw new Error("No account uses that email. Ask the person to create an account first, then try again.");
	const { error } = await admin.from("user_roles").upsert({
		user_id: prof.id,
		role: "admin"
	}, { onConflict: "user_id,role" });
	if (error) throw new Error(error.message);
	await admin.from("notifications").insert({
		user_id: prof.id,
		title: "You are now an administrator",
		body: "You can open the Staff portal from your account.",
		link: "/admin"
	});
	return { ok: true };
});
var removeAdmin_createServerFn_handler = createServerRpc({
	id: "3a46d25e6804bae49baa23e35d434e5b5a3b4e1ffe6810a527b2f565f7d796ed",
	name: "removeAdmin",
	filename: "src/lib/admin-tools.functions.ts"
}, (opts) => removeAdmin.__executeServer(opts));
var removeAdmin = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ userId: stringType().uuid() }).parse(d)).handler(removeAdmin_createServerFn_handler, async ({ data, context }) => {
	const admin = await assertAdmin(context);
	if (data.userId === context.userId) throw new Error("You cannot remove your own admin access.");
	const { error } = await admin.from("user_roles").delete().eq("user_id", data.userId).eq("role", "admin");
	if (error) throw new Error(error.message);
	return { ok: true };
});
var deleteCustomer_createServerFn_handler = createServerRpc({
	id: "2f1c73f9e24ebe72c705d295e336913c9c1e020140aca47d15ca892445dc6794",
	name: "deleteCustomer",
	filename: "src/lib/admin-tools.functions.ts"
}, (opts) => deleteCustomer.__executeServer(opts));
var deleteCustomer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ userId: stringType().uuid() }).parse(d)).handler(deleteCustomer_createServerFn_handler, async ({ data, context }) => {
	const admin = await assertAdmin(context);
	if (data.userId === context.userId) throw new Error("You cannot delete your own account here.");
	const { data: roles, error: rolesError } = await admin.from("user_roles").select("role").eq("user_id", data.userId);
	if (rolesError) throw new Error(rolesError.message);
	if (roles?.some((entry) => entry.role === "admin" || entry.role === "staff")) throw new Error("Staff and administrator accounts cannot be deleted from Customers.");
	const { data: docs, error: docsError } = await admin.from("loan_documents").select("file_path").eq("user_id", data.userId);
	if (docsError) throw new Error(docsError.message);
	if (docs?.length) {
		const { error: storageError } = await admin.storage.from("borrower-docs").remove(docs.map((d) => d.file_path));
		if (storageError) throw new Error(storageError.message);
	}
	const { error: docDeleteError } = await admin.from("loan_documents").delete().eq("user_id", data.userId);
	if (docDeleteError) throw new Error(docDeleteError.message);
	const { error: notifError } = await admin.from("notifications").delete().eq("user_id", data.userId);
	if (notifError) throw new Error(notifError.message);
	const { error } = await admin.auth.admin.deleteUser(data.userId);
	if (error) throw new Error(error.message);
	return { ok: true };
});
//#endregion
export { addAdmin_createServerFn_handler, deleteCustomer_createServerFn_handler, listAdmins_createServerFn_handler, removeAdmin_createServerFn_handler };
