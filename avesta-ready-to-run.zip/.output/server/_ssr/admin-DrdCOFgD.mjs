import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DrdCOFgD.js
var $$splitComponentImporter = () => import("./admin-Djf42hkC.mjs");
var Route = createFileRoute("/_authenticated/admin")({
	head: () => ({ meta: [
		{ title: "Staff portal — Avesta Enterprises" },
		{
			name: "description",
			content: "Manage loan applications, repayments and IT requests."
		},
		{
			property: "og:title",
			content: "Avesta staff portal"
		},
		{
			property: "og:description",
			content: "Staff tools for Avesta Enterprises."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
