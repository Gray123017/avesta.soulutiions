import { h as createFileRoute, m as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule._loanId-Czg3rJG_.js
var $$splitComponentImporter = () => import("./schedule._loanId-BIY7ibbb.mjs");
var Route = createFileRoute("/_authenticated/schedule/$loanId")({
	head: () => ({ meta: [
		{ title: "Repayment schedule — Avesta Staff" },
		{
			name: "description",
			content: "Set instalment dates and amounts for an approved Avesta loan."
		},
		{
			property: "og:title",
			content: "Repayment schedule — Avesta Staff"
		},
		{
			property: "og:description",
			content: "Set instalment dates and amounts for an approved loan."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
