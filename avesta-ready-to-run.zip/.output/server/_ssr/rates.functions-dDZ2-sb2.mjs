import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rates.functions-dDZ2-sb2.js
var getRates_createServerFn_handler = createServerRpc({
	id: "1e0941a199f160fb788d4f4f39a3b00910ec53d0901baa56e06c4430e14dc7f8",
	name: "getRates",
	filename: "src/lib/rates.functions.ts"
}, (opts) => getRates.__executeServer(opts));
var getRates = createServerFn({ method: "GET" }).handler(getRates_createServerFn_handler, async () => {
	try {
		const r = await fetch("https://open.er-api.com/v6/latest/ZMW");
		if (!r.ok) return {
			ok: false,
			rates: {},
			updated: ""
		};
		const j = await r.json();
		const want = [
			"USD",
			"ZAR",
			"GBP",
			"EUR",
			"BWP",
			"CNY",
			"TZS",
			"MWK"
		];
		const rates = {};
		for (const c of want) if (j.rates?.[c]) rates[c] = j.rates[c];
		return {
			ok: true,
			rates,
			updated: j.time_last_update_utc ?? ""
		};
	} catch {
		return {
			ok: false,
			rates: {},
			updated: ""
		};
	}
});
//#endregion
export { getRates_createServerFn_handler };
