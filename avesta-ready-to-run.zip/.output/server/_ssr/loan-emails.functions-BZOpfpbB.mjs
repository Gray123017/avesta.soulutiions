import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { i as stringType, n as enumType, r as objectType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/loan-emails.functions-BZOpfpbB.js
var loanIdSchema = objectType({ loanId: stringType().uuid() });
/**
* Emails the borrower that their application was received, and alerts staff.
* Caller must be the loan's owner. Best-effort: email failures never throw
* back to the caller — the in-app notification is the source of truth.
*/
var notifyLoanApplied_createServerFn_handler = createServerRpc({
	id: "8b9041f9bd81c9775a830ec4399832d706290211a2b7fcfc32f5c8379302b5f1",
	name: "notifyLoanApplied",
	filename: "src/lib/loan-emails.functions.ts"
}, (opts) => notifyLoanApplied.__executeServer(opts));
var notifyLoanApplied = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => loanIdSchema.parse(data)).handler(notifyLoanApplied_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: loan } = await supabase.from("loans").select("id, user_id, amount, weeks").eq("id", data.loanId).single();
	if (!loan || loan.user_id !== userId) return { sent: false };
	const { sendTemplateEmail } = await import("./send-email-DmB8rzAW.mjs");
	const { data: userData } = await supabase.auth.getUser();
	const email = userData?.user?.email;
	const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", userId).single();
	const name = profile?.full_name ?? "";
	const amount = Number(loan.amount).toFixed(2);
	if (email) await sendTemplateEmail("loan-status", email, {
		templateData: {
			name,
			status: "received",
			amount
		},
		idempotencyKey: `loan-received-${loan.id}`
	}).catch((e) => console.error("loan-received email failed", e));
	await sendTemplateEmail("admin-alert", "", {
		templateData: {
			title: "New loan application",
			body: `${name || "A customer"} applied for K${amount} over ${loan.weeks} week(s).`
		},
		idempotencyKey: `admin-loan-${loan.id}`
	}).catch((e) => console.error("admin loan alert failed", e));
	return { sent: true };
});
var notifyLoanDecision_createServerFn_handler = createServerRpc({
	id: "ac5fc9a203621458bff34b85f2ddfab947f1d3af573647d0ab26dbc5c8026279",
	name: "notifyLoanDecision",
	filename: "src/lib/loan-emails.functions.ts"
}, (opts) => notifyLoanDecision.__executeServer(opts));
var notifyLoanDecision = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => loanIdSchema.extend({ kind: enumType([
	"approved",
	"rejected",
	"collateral",
	"disbursed",
	"paid"
]) }).parse(data)).handler(notifyLoanDecision_createServerFn_handler, async ({ data, context }) => {
	const { supabase } = context;
	const { data: isAdmin } = await supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) return { sent: false };
	const { supabaseAdmin } = await import("./client.server-B1q0XEiz.mjs");
	const { data: loan } = await supabaseAdmin.from("loans").select("id, user_id, amount").eq("id", data.loanId).single();
	if (!loan) return { sent: false };
	const { data: userData } = await supabaseAdmin.auth.admin.getUserById(loan.user_id);
	const email = userData?.user?.email;
	if (!email) return { sent: false };
	const { data: profile } = await supabaseAdmin.from("profiles").select("full_name").eq("id", loan.user_id).single();
	const { sendTemplateEmail } = await import("./send-email-DmB8rzAW.mjs");
	await sendTemplateEmail("loan-status", email, {
		templateData: {
			name: profile?.full_name ?? "",
			status: data.kind,
			amount: Number(loan.amount).toFixed(2)
		},
		idempotencyKey: `loan-${data.kind}-${loan.id}`
	}).catch((e) => console.error("loan decision email failed", e));
	return { sent: true };
});
//#endregion
export { notifyLoanApplied_createServerFn_handler, notifyLoanDecision_createServerFn_handler };
