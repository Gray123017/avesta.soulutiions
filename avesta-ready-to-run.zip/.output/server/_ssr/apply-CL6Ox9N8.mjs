import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as StatusBadge, n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { a as statusTone, i as loanQuote, r as kwacha } from "./avesta-HIuujrtk.mjs";
import { t as notifyLoanApplied } from "./loan-emails.functions-tn9qcqtK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Label } from "./label-Dz64RFdN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apply-CL6Ox9N8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var selectCls = "h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm [&>option]:bg-popover";
function ApplyPage() {
	const [userId, setUserId] = (0, import_react.useState)(void 0);
	const [f, setF] = (0, import_react.useState)({
		full_name: "",
		phone: "",
		nrc: "",
		amount: 1e3,
		weeks: 2,
		frequency: "weekly",
		purpose: "",
		payout: "mobile_money",
		payout_details: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [mine, setMine] = (0, import_react.useState)([]);
	const quote = loanQuote(f.amount || 0, f.weeks, f.frequency);
	const loadMine = async (id) => {
		const { data } = await supabase.from("loans").select("id,amount,weeks,total,status,admin_note,created_at").eq("user_id", id).order("created_at", { ascending: false }).limit(5);
		setMine(data ?? []);
	};
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(async ({ data }) => {
			const id = data.session?.user?.id ?? null;
			setUserId(id);
			if (!id) return;
			const { data: p } = await supabase.from("profiles").select("full_name,phone,nrc").eq("id", id).maybeSingle();
			if (p) setF((s) => ({
				...s,
				full_name: p.full_name ?? "",
				phone: p.phone ?? "",
				nrc: p.nrc ?? ""
			}));
			loadMine(id);
		}).catch(() => setUserId(null));
	}, []);
	const submit = async (e) => {
		e.preventDefault();
		if (!userId) return;
		if (f.full_name.trim().length < 2 || f.phone.trim().length < 9 || f.nrc.trim().length < 6) {
			toast.error("Please enter your full name, phone number and NRC.");
			return;
		}
		if (f.amount < 100 || f.amount > 1e6) {
			toast.error("Enter an amount between K100 and K1,000,000.");
			return;
		}
		setBusy(true);
		const { error: pe } = await supabase.from("profiles").update({
			full_name: f.full_name.trim().slice(0, 100),
			phone: f.phone.trim().slice(0, 20),
			nrc: f.nrc.trim().slice(0, 30)
		}).eq("id", userId);
		let error = pe;
		if (!error) {
			const ins = await supabase.from("loans").insert({
				user_id: userId,
				amount: f.amount,
				weeks: f.weeks,
				frequency: f.frequency,
				purpose: f.purpose.trim().slice(0, 300)
			}).select("id").single();
			error = ins.error;
			if (ins.data) {
				await supabase.rpc("set_loan_payout", {
					_loan_id: ins.data.id,
					_method: f.payout,
					_details: f.payout_details.trim()
				});
				notifyLoanApplied({ data: { loanId: ins.data.id } }).catch(() => {});
			}
		}
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Application sent — Avesta will respond here and on WhatsApp.");
		setF((s) => ({
			...s,
			purpose: ""
		}));
		loadMine(userId);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-enter mx-auto max-w-4xl px-5 pb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-2 font-display text-4xl font-semibold",
				children: "Apply for a loan"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-6 text-muted-foreground",
				children: "1 to 4 weeks · 15–30% flat interest · Avesta reviews every application and replies to you."
			}),
			userId === void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}),
			userId === null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Sign in to apply"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "A free account lets you submit your details safely and see Avesta's response and your loan status any time."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "copper",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								children: "Create account / Sign in"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "glass",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://wa.me/260769974200",
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Apply on WhatsApp"
							})
						})]
					})
				]
			}),
			userId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4 rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Your details"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "fn",
									children: "Full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "fn",
									required: true,
									maxLength: 100,
									value: f.full_name,
									onChange: (e) => setF({
										...f,
										full_name: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "ph",
									children: "Phone"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "ph",
									required: true,
									maxLength: 20,
									value: f.phone,
									onChange: (e) => setF({
										...f,
										phone: e.target.value
									}),
									placeholder: "09…"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "nrc",
									children: "NRC number"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "nrc",
									required: true,
									maxLength: 30,
									value: f.nrc,
									onChange: (e) => setF({
										...f,
										nrc: e.target.value
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "pt-2 font-display text-lg font-semibold",
						children: "Loan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "amt",
									children: "Amount (K)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "amt",
									type: "number",
									min: 100,
									required: true,
									value: f.amount,
									onChange: (e) => setF({
										...f,
										amount: Number(e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "wk",
									children: "Term"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "wk",
									className: selectCls,
									value: f.weeks,
									onChange: (e) => setF({
										...f,
										weeks: Number(e.target.value)
									}),
									children: [
										1,
										2,
										3,
										4
									].map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: w,
										children: [
											w,
											" week",
											w > 1 ? "s" : ""
										]
									}, w))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "fq",
									children: "Repayment"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "fq",
									className: selectCls,
									value: f.frequency,
									onChange: (e) => setF({
										...f,
										frequency: e.target.value
									}),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "weekly",
											children: "Weekly"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "bi-weekly",
											children: "Bi-weekly"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "monthly",
											children: "Once at the end"
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "pp",
							children: "Purpose"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "pp",
							maxLength: 300,
							value: f.purpose,
							onChange: (e) => setF({
								...f,
								purpose: e.target.value
							}),
							placeholder: "e.g. school fees, stock"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "po",
							children: "Receive money by"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-[12rem_1fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "po",
								className: selectCls,
								value: f.payout,
								onChange: (e) => setF({
									...f,
									payout: e.target.value
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "mobile_money",
										children: "Mobile money"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "bank",
										children: "Bank transfer"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "cash",
										children: "Cash at office"
									})
								]
							}), f.payout !== "cash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Payout details",
								maxLength: 300,
								value: f.payout_details,
								onChange: (e) => setF({
									...f,
									payout_details: e.target.value
								}),
								placeholder: f.payout === "bank" ? "Bank, account name and number" : "Network and number, e.g. MTN 097…"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "self-center text-sm text-muted-foreground",
								children: "Collect at Kansenshi, Ndola with your NRC."
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 rounded-xl bg-foreground/5 p-4 text-sm min-[420px]:grid-cols-2 sm:grid-cols-4 [&>div]:min-w-0 [&_p]:break-words",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: "Interest"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold",
								children: [quote.rate, "%"]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: "Cost"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: kwacha(quote.interest)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: "Total to repay"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-primary",
								children: kwacha(quote.total)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted-foreground",
								children: [quote.installments, " payment(s) of"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: kwacha(quote.perInstallment)
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "copper",
						type: "submit",
						disabled: busy,
						children: busy ? "Sending…" : "Submit application"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl border border-foreground/10 bg-card p-6 shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Avesta's response"
					}),
					mine.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "No applications yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-3",
						children: mine.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-foreground/5 p-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: [
											kwacha(l.amount),
											" · ",
											l.weeks,
											" wk · total ",
											kwacha(l.total)
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
										status: l.status,
										tones: statusTone
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-muted-foreground",
									children: ["Applied ", new Date(l.created_at).toLocaleDateString()]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									children: l.admin_note ? `Avesta: ${l.admin_note}` : "Avesta is reviewing your application — we'll reply here and on WhatsApp."
								})
							]
						}, l.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/portal",
						className: "mt-4 inline-block text-sm text-primary underline",
						children: "Open my full borrower portal"
					})
				]
			})] })
		] })]
	});
}
//#endregion
export { ApplyPage as component };
