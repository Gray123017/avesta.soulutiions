import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/domain.functions-CLR6wUlR.js
var IP = "185.158.133.1";
var DOMAIN = "avesta.solutions";
async function dns(name, type) {
	return ((await (await fetch(`https://cloudflare-dns.com/dns-query?name=${name}&type=${type}`, { headers: { accept: "application/dns-json" } })).json()).Answer ?? []).map((a) => a.data.replace(/^"|"$/g, ""));
}
async function https(url) {
	try {
		return (await fetch(url, { redirect: "follow" })).ok;
	} catch {
		return false;
	}
}
var checkDomain_createServerFn_handler = createServerRpc({
	id: "775e3ec415bf10866650f14a6c56f70240c979393980b088f01e639562c6eb5b",
	name: "checkDomain",
	filename: "src/lib/domain.functions.ts"
}, (opts) => checkDomain.__executeServer(opts));
var checkDomain = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(checkDomain_createServerFn_handler, async ({ context }) => {
	const { data: isAdmin, error } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (error || !isAdmin) throw new Error("Administrator access required");
	const [root, www, secureRoot, secureWww] = await Promise.all([
		dns(DOMAIN, "A"),
		dns(`www.${DOMAIN}`, "A"),
		https(`https://${DOMAIN}`),
		https(`https://www.${DOMAIN}`)
	]);
	const checks = [
		{
			label: `A record @ → ${IP}`,
			ok: root.includes(IP) && root.length === 1,
			found: root.join(", ") || "none"
		},
		{
			label: `A record www → ${IP}`,
			ok: www.includes(IP),
			found: www.join(", ") || "none"
		},
		{
			label: `https://${DOMAIN} loads securely`,
			ok: secureRoot,
			found: secureRoot ? "yes" : "no"
		},
		{
			label: `https://www.${DOMAIN} loads securely`,
			ok: secureWww,
			found: secureWww ? "yes" : "no"
		}
	];
	return {
		checks,
		dnsReady: checks.slice(0, 2).every((c) => c.ok),
		live: secureRoot || secureWww,
		checkedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
});
//#endregion
export { checkDomain_createServerFn_handler };
