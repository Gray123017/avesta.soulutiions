import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as StatusBadge, n as AppHeader, t as AdminOnly } from "./AppHeader-DG15xa67.mjs";
import { t as Input } from "./input-1tvakjVT.mjs";
import { a as statusTone, r as kwacha } from "./avesta-HIuujrtk.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./schedule._loanId-Czg3rJG_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule._loanId-BIY7ibbb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ScheduleGate() {
	const { user } = Route.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOnly, {
		userId: user.id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchedulePage, {})
	});
}
var iso = (d) => d.toISOString().slice(0, 10);
var nice = (s) => (/* @__PURE__ */ new Date(s + "T00:00:00")).toLocaleDateString(void 0, {
	day: "numeric",
	month: "short",
	year: "numeric"
});
function SchedulePage() {
	const { loanId } = Route.useParams();
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["schedule", loanId],
		queryFn: async () => {
			const { data: loan, error } = await supabase.from("loans").select("*, loan_instalments(*)").eq("id", loanId).single();
			if (error) throw error;
			const { data: p } = await supabase.from("profiles").select("full_name, phone, email").eq("id", loan.user_id).maybeSingle();
			return {
				loan,
				p,
				inst: [...loan.loan_instalments].sort((a, b) => a.due_date.localeCompare(b.due_date))
			};
		}
	});
	const [date, setDate] = (0, import_react.useState)("");
	const [amt, setAmt] = (0, import_react.useState)("");
	const refresh = () => qc.invalidateQueries({ queryKey: ["schedule", loanId] });
	const run = async (p, ok) => {
		const { error } = await p;
		if (error) toast.error(error.message);
		else {
			if (ok) toast.success(ok);
			refresh();
		}
	};
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8 text-sm text-muted-foreground",
		children: "Loading…"
	})] });
	if (!q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8",
		children: "Loan not found."
	})] });
	const { loan, p, inst } = q.data;
	const total = Number(loan.total);
	const planned = inst.reduce((s, i) => s + Number(i.amount), 0);
	const diff = Math.round((total - planned) * 100) / 100;
	const generate = async () => {
		const step = loan.frequency === "bi-weekly" ? 14 : loan.frequency === "monthly" ? loan.weeks * 7 : 7;
		const count = Math.max(1, Math.round(loan.weeks * 7 / step));
		const start = loan.disbursed_at ? new Date(loan.disbursed_at) : /* @__PURE__ */ new Date();
		const each = Math.floor(total / count * 100) / 100;
		const rows = Array.from({ length: count }, (_, k) => {
			const d = new Date(start);
			d.setDate(d.getDate() + step * (k + 1));
			const amount = k === count - 1 ? Math.round((total - each * (count - 1)) * 100) / 100 : each;
			return {
				loan_id: loanId,
				due_date: iso(d),
				amount
			};
		});
		const del = await supabase.from("loan_instalments").delete().eq("loan_id", loanId);
		if (del.error) {
			toast.error(del.error.message);
			return;
		}
		run(supabase.from("loan_instalments").insert(rows), "Schedule created from the loan terms");
	};
	const scheduleText = inst.map((i, n) => `${n + 1}. ${nice(i.due_date)} — ${kwacha(Number(i.amount))}`).join("\n");
	const waText = `Hello ${p?.full_name || "there"}, here is your Avesta repayment schedule for your ${kwacha(loan.amount)} loan (total ${kwacha(total)}):\n${scheduleText}\nView it any time: https://avesta.solutions/portal`;
	const phone = (p?.phone ?? "").replace(/\D/g, "").replace(/^0/, "260");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "page-enter mx-auto max-w-3xl space-y-6 px-4 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						className: "text-sm text-muted-foreground hover:text-foreground",
						children: "← Back to Staff portal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-2xl font-bold",
						children: "Repayment schedule"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							p?.full_name || p?.email || "Customer",
							" · ",
							kwacha(loan.amount),
							" for ",
							loan.weeks,
							" week(s) · ",
							loan.frequency
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
								status: loan.status,
								tones: statusTone
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Total to repay ", kwacha(total)] }),
							loan.schedule_sent_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-accent",
								children: ["· Sent ", new Date(loan.schedule_sent_at).toLocaleDateString()]
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-foreground/10 bg-card p-5 shadow-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold",
								children: "Instalments"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "glass",
								onClick: () => {
									if (!inst.length || confirm("Replace the current instalments?")) generate();
								},
								children: "Fill from loan terms"
							})]
						}),
						!inst.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: "No instalments yet. Fill from the loan terms or add dates below."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2",
							children: inst.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstRow, {
								i,
								run
							}, i.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-4 flex flex-wrap items-end gap-2",
							onSubmit: (e) => {
								e.preventDefault();
								const n = Number(amt);
								if (!date || !(n > 0)) {
									toast.error("Choose a date and an amount");
									return;
								}
								run(supabase.from("loan_instalments").insert({
									loan_id: loanId,
									due_date: date,
									amount: n
								}), "Instalment added");
								setDate("");
								setAmt("");
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "space-y-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs",
										children: "Due date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: date,
										onChange: (e) => setDate(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "space-y-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs",
										children: "Amount (K)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "w-32",
										type: "number",
										step: "0.01",
										min: "0.01",
										value: amt,
										onChange: (e) => setAmt(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "copper",
									type: "submit",
									children: "Add instalment"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `mt-3 text-sm ${diff === 0 ? "text-accent" : "text-muted-foreground"}`,
							children: [
								"Planned ",
								kwacha(planned),
								" of ",
								kwacha(total),
								diff !== 0 && ` · ${diff > 0 ? `${kwacha(diff)} still to schedule` : `${kwacha(-diff)} over the total`}`
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-foreground/10 bg-card p-5 shadow-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "Send to customer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "The customer gets a notification and sees the schedule in their portal."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "copper",
								disabled: !inst.length,
								onClick: () => run(supabase.rpc("send_loan_schedule", { _loan_id: loanId }), "Schedule sent to the customer"),
								children: loan.schedule_sent_at ? "Send updated schedule" : "Send schedule"
							}), phone && inst.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "glass",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `https://wa.me/${phone}?text=${encodeURIComponent(waText)}`,
									target: "_blank",
									rel: "noopener noreferrer",
									children: "Send on WhatsApp"
								})
							})]
						})
					]
				})
			]
		})]
	});
}
function InstRow({ i, run }) {
	const [d, setD] = (0, import_react.useState)(i.due_date);
	const [a, setA] = (0, import_react.useState)(String(i.amount));
	const changed = d !== i.due_date || Number(a) !== Number(i.amount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-wrap items-center gap-2 rounded-lg bg-foreground/5 p-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "w-40",
				type: "date",
				value: d,
				onChange: (e) => setD(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "w-28",
				type: "number",
				step: "0.01",
				value: a,
				onChange: (e) => setA(e.target.value)
			}),
			changed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "copper",
				onClick: () => run(supabase.from("loan_instalments").update({
					due_date: d,
					amount: Number(a)
				}).eq("id", i.id), "Saved"),
				children: "Save"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: i.paid,
					onChange: (e) => run(supabase.from("loan_instalments").update({ paid: e.target.checked }).eq("id", i.id))
				}), " Paid"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "quiet",
				className: "ml-auto text-destructive",
				onClick: () => {
					if (confirm("Remove this instalment?")) run(supabase.from("loan_instalments").delete().eq("id", i.id));
				},
				children: "Remove"
			})
		]
	});
}
//#endregion
export { ScheduleGate as component };
