//#region node_modules/.nitro/vite/services/ssr/assets/avesta-HIuujrtk.js
var RATES = {
	1: 15,
	2: 20,
	3: 25,
	4: 30
};
function loanQuote(amount, weeks, frequency) {
	const rate = RATES[weeks] ?? 30;
	const total = Math.round(amount * (1 + rate / 100) * 100) / 100;
	const installments = frequency === "weekly" ? weeks : frequency === "bi-weekly" ? Math.max(1, Math.ceil(weeks / 2)) : 1;
	return {
		rate,
		total,
		interest: total - amount,
		installments,
		perInstallment: total / installments
	};
}
var kwacha = (n) => "K" + Number(n).toLocaleString("en-ZM", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
var IT_SERVICES = [
	"Computer repair",
	"Networking",
	"CCTV installation",
	"Cybersecurity",
	"Website development",
	"Database systems",
	"Data services",
	"Training"
];
var statusTone = {
	pending: "bg-primary/15 text-primary",
	open: "bg-primary/15 text-primary",
	approved: "bg-accent/20 text-accent",
	in_progress: "bg-accent/20 text-accent",
	active: "bg-accent/20 text-accent",
	paid: "bg-foreground/10 text-foreground",
	completed: "bg-foreground/10 text-foreground",
	rejected: "bg-destructive/20 text-destructive",
	cancelled: "bg-destructive/20 text-destructive"
};
//#endregion
export { statusTone as a, loanQuote as i, RATES as n, kwacha as r, IT_SERVICES as t };
