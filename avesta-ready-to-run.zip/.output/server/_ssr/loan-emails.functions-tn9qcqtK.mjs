import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-CNjxwplZ.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { i as stringType, n as enumType, r as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/loan-emails.functions-tn9qcqtK.js
var loanIdSchema = objectType({ loanId: stringType().uuid() });
/**
* Emails the borrower that their application was received, and alerts staff.
* Caller must be the loan's owner. Best-effort: email failures never throw
* back to the caller — the in-app notification is the source of truth.
*/
var notifyLoanApplied = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => loanIdSchema.parse(data)).handler(createSsrRpc("8b9041f9bd81c9775a830ec4399832d706290211a2b7fcfc32f5c8379302b5f1"));
/**
* Emails the borrower when staff approve, reject, request collateral, or mark
* money sent. Caller must be an admin. Best-effort: never throws.
*/
var notifyLoanDecision = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => loanIdSchema.extend({ kind: enumType([
	"approved",
	"rejected",
	"collateral",
	"disbursed",
	"paid"
]) }).parse(data)).handler(createSsrRpc("ac5fc9a203621458bff34b85f2ddfab947f1d3af573647d0ab26dbc5c8026279"));
//#endregion
export { notifyLoanDecision as n, notifyLoanApplied as t };
