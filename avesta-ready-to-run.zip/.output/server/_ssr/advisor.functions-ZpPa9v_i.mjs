import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { i as stringType, n as enumType, r as objectType, t as arrayType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-B90ckaqP.mjs";
import { t as createOpenAI } from "../_libs/@ai-sdk/openai+[...].mjs";
import { n as output_exports, r as streamText } from "../_libs/ai.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/advisor.functions-ZpPa9v_i.js
var Input = objectType({
	kind: enumType(["loan", "services"]),
	text: stringType().trim().min(10).max(2e3)
});
var Result = objectType({
	summary: stringType(),
	recommendations: arrayType(objectType({
		title: stringType(),
		why: stringType(),
		details: stringType()
	})),
	nextSteps: arrayType(stringType())
});
var LOAN_PROMPT = `You are the lending advisor for Avesta Enterprises, a lender in Ndola, Zambia.
Our only product: short-term cash loans of 1 to 4 weeks. Flat interest: 1 week 15%, 2 weeks 20%, 3 weeks 25%, 4 weeks 30%.
Repayment frequency: weekly, bi-weekly or once at the end. Amounts are in Zambian Kwacha (K).
Given the borrower's needs, recommend 2-3 concrete options (term + repayment frequency), showing the total to repay (amount x (1+rate)).
Be honest: if a short-term loan is a poor fit (e.g. long-term capital), say so and suggest a smaller amount or alternatives. Never promise approval.
Next steps should reference creating an account on this site and applying, or WhatsApp 0769 974 200. Keep each field short.`;
var SERVICES_PROMPT = `You are the IT advisor for Avesta Enterprises in Ndola, Zambia.
Our IT services: computer repair, networking, CCTV installation, cybersecurity, website development, database systems, data services, training. We also offer short-term business loans (1-4 weeks, 15-30%).
Given the client's business needs, recommend the 2-4 most relevant Avesta services, why each fits, and what the work would involve. Do not quote prices.
Next steps should reference sending an IT support request after signing in on this site, or WhatsApp 0769 974 200. Keep each field short.`;
var getAdvice_createServerFn_handler = createServerRpc({
	id: "1b0f1285003491e80d9c5454741721d7a2ecbfb70d9b57b2c65196b724160f22",
	name: "getAdvice",
	filename: "src/lib/advisor.functions.ts"
}, (opts) => getAdvice.__executeServer(opts));
var getAdvice = createServerFn({ method: "POST" }).inputValidator((d) => Input.parse(d)).handler(getAdvice_createServerFn_handler, async ({ data }) => {
	const baseURL = process.env["AI_BASE_URL"];
	if (!baseURL) throw new Error("The advisor is not configured. Set AI_BASE_URL and AI_API_KEY.");
	const ai = createOpenAI({
		baseURL,
		apiKey: process.env["AI_API_KEY"] || "not-needed"
	});
	try {
		return await streamText({
			model: ai.responses(process.env["AI_MODEL"] || "openai/gpt-4.1-mini"),
			system: data.kind === "loan" ? LOAN_PROMPT : SERVICES_PROMPT,
			prompt: data.text,
			output: output_exports.object({ schema: Result }),
			providerOptions: { openai: {
				forceReasoning: true,
				reasoningEffort: "low",
				store: false,
				include: ["reasoning.encrypted_content"]
			} }
		}).output;
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		if (/402/.test(msg)) throw new Error("AI credits have run out. Please try again later.");
		if (/429/.test(msg)) throw new Error("The advisor is busy. Please wait a moment and try again.");
		console.error("advisor error", msg);
		throw new Error("The advisor could not answer right now. Please try again.");
	}
});
//#endregion
export { getAdvice_createServerFn_handler };
