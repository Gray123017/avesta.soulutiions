import { i as __toESM } from "../_runtime.mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createServerFn } from "./createServerFn-CIHAFgYl.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CAUI3crF.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as stringType, n as enumType, r as objectType } from "../_libs/zod.mjs";
import { t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as AppHeader } from "./AppHeader-DG15xa67.mjs";
import { t as Textarea } from "./textarea-BPdFvfWe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/advisor-Dc3wD7ML.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = objectType({
	kind: enumType(["loan", "services"]),
	text: stringType().trim().min(10).max(2e3)
});
var getAdvice = createServerFn({ method: "POST" }).inputValidator((d) => Input.parse(d)).handler(createSsrRpc("1b0f1285003491e80d9c5454741721d7a2ecbfb70d9b57b2c65196b724160f22"));
var EXAMPLES = {
	loan: "I need about K2,000 to restock my shop. I get paid every Friday and can repay within 3 weeks.",
	services: "I run a small pharmacy with 3 computers. The internet keeps dropping and I want cameras for security."
};
function Advisor() {
	const [kind, setKind] = (0, import_react.useState)("loan");
	const [text, setText] = (0, import_react.useState)("");
	const advise = useServerFn(getAdvice);
	const m = useMutation({ mutationFn: () => advise({ data: {
		kind,
		text
	} }) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "page-enter min-h-screen bg-background text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end text-sm mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/portal",
						className: "text-muted-foreground hover:text-foreground",
						children: "Already applied? Track it in the borrower portal →"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-serif text-4xl",
					children: "What do you need?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted-foreground",
					children: "Describe it in your own words. Our AI advisor suggests options — a staff member confirms everything."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: kind === "loan" ? "copper" : "glass",
						onClick: () => {
							setKind("loan");
							m.reset();
						},
						children: "A loan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: kind === "services" ? "copper" : "glass",
						onClick: () => {
							setKind("services");
							m.reset();
						},
						children: "IT for my business"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-4 min-h-32",
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: EXAMPLES[kind],
					maxLength: 2e3
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "copper",
						disabled: text.trim().length < 10 || m.isPending,
						onClick: () => m.mutate(),
						children: m.isPending ? "Thinking…" : "Get recommendations"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						size: "sm",
						onClick: () => setText(EXAMPLES[kind]),
						children: "Use an example"
					})]
				}),
				m.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-destructive",
					children: m.error.message
				}),
				m.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
					r: m.data,
					kind
				})
			]
		})
	});
}
function Results({ r, kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8 space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg",
				children: r.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: r.recommendations.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold text-primary",
							children: x.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: x.why
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: x.details
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Next steps"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-2 list-decimal space-y-1 pl-5 text-sm",
					children: r.nextSteps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "copper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dashboard",
							children: kind === "loan" ? "Apply now" : "Send a request"
						})
					}),
					kind === "services" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "glass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/it-help",
							children: "Open live IT support"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "glass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/portal",
							children: "Borrower portal"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "glass",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/260769974200",
							target: "_blank",
							rel: "noreferrer",
							children: "WhatsApp us"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Suggestions only — not a loan offer. Final terms are confirmed by Avesta staff."
			})
		]
	});
}
//#endregion
export { Advisor as component };
