import { i as __toESM } from "../_runtime.mjs";
import { _ as Link, b as useRouter, u as useCanGoBack, v as Navigate, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime, r as require_react_dom } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as supabase } from "./client-V0TxFhOb.mjs";
import { t as Button } from "./button-DWLuVCSU.mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { P as ArrowLeft, S as House, b as LayoutDashboard, c as ShieldCheck, i as UserRound, j as Bell, u as Rocket, v as LogOut } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppHeader-DG15xa67.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
function NotificationBell({ userId }) {
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const triggerRef = (0, import_react.useRef)(null);
	const [position, setPosition] = (0, import_react.useState)({
		top: 0,
		left: 0,
		width: 0,
		maxHeight: 0
	});
	const { data = [] } = useQuery({
		queryKey: ["notifications", userId],
		queryFn: async () => (await supabase.from("notifications").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(30)).data ?? [],
		refetchInterval: 6e4
	});
	(0, import_react.useEffect)(() => {
		const ch = supabase.channel(`notif-${userId}`).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${userId}`
		}, () => qc.invalidateQueries({ queryKey: ["notifications", userId] })).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [userId, qc]);
	const unread = data.filter((n) => !n.read).length;
	const markAll = async () => {
		await supabase.from("notifications").update({ read: true }).eq("user_id", userId).eq("read", false);
		qc.invalidateQueries({ queryKey: ["notifications", userId] });
	};
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const placePanel = () => {
			const rect = triggerRef.current?.getBoundingClientRect();
			if (!rect) return;
			const width = Math.min(384, window.innerWidth - 32);
			const left = window.innerWidth < 1024 ? (window.innerWidth - width) / 2 : Math.max(16, Math.min(rect.right - width, window.innerWidth - width - 16));
			const top = Math.min(rect.bottom + 8, window.innerHeight - 96);
			setPosition({
				top,
				left,
				width,
				maxHeight: Math.max(80, window.innerHeight - top - 16)
			});
		};
		placePanel();
		window.addEventListener("resize", placePanel);
		window.addEventListener("scroll", placePanel, true);
		const onKeyDown = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		window.addEventListener("keydown", onKeyDown);
		return () => {
			window.removeEventListener("resize", placePanel);
			window.removeEventListener("scroll", placePanel, true);
			window.removeEventListener("keydown", onKeyDown);
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			ref: triggerRef,
			variant: "glass",
			size: "sm",
			"aria-label": `Notifications (${unread} unread)`,
			"aria-expanded": open,
			onClick: () => setOpen((o) => !o),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {}), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-primary px-1.5 text-xs font-bold text-primary-foreground",
				children: unread
			})]
		}), open && position.width > 0 && (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Notifications",
			className: "fixed z-50 overflow-y-auto rounded-lg border border-border bg-popover p-3 text-popover-foreground shadow-soft",
			style: position,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Notifications"
					}), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "link",
						size: "sm",
						onClick: markAll,
						children: "Mark all read"
					})]
				}),
				data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Nothing yet."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "max-h-96 space-y-2 overflow-y-auto",
					children: data.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: `break-words rounded-lg p-2 text-sm ${n.read ? "opacity-70" : "bg-foreground/5"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: n.link ?? "/portal",
							onClick: () => setOpen(false),
							className: "block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: n.title
								}),
								n.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground",
									children: n.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: new Date(n.created_at).toLocaleString()
								})
							]
						})
					}, n.id))
				})
			]
		}), document.body)]
	});
}
function useIsAdmin(userId) {
	return useQuery({
		queryKey: ["is-admin", userId],
		enabled: !!userId,
		queryFn: async () => {
			if (!userId) return false;
			const { data, error } = await supabase.rpc("has_role", {
				_user_id: userId,
				_role: "admin"
			});
			if (error) throw error;
			return !!data;
		}
	});
}
function PageNavigation({ className = "" }) {
	const router = useRouter();
	const canGoBack = useCanGoBack();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		"aria-label": "Page navigation",
		className: `flex items-center gap-2 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "glass",
			size: "sm",
			onClick: () => canGoBack ? router.history.back() : router.navigate({ to: "/" }),
			"aria-label": "Go to previous page",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "quiet",
			size: "sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				"aria-label": "Go to home page",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Home" })]
			})
		})]
	});
}
function AdminOnly({ userId, children }) {
	const { data: isAdmin, isLoading, isError } = useIsAdmin(userId);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center text-muted-foreground",
		children: "Checking access…"
	});
	if (isError || !isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/dashboard",
		replace: true
	});
	return children;
}
function AppHeader({ userId }) {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: isAdmin } = useIsAdmin(userId);
	async function signOut() {
		await qc.cancelQueries();
		qc.clear();
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "border-b border-primary/15 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 sm:gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "group flex min-w-0 items-center gap-2 sm:gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-10 shrink-0 place-items-center rounded-md bg-primary font-display font-bold text-primary-foreground transition-transform duration-300 group-hover:-rotate-2",
					children: "AE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 truncate font-display text-sm font-bold sm:text-base",
					children: "Avesta Enterprises"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageNavigation, {})]
		}), userId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			"aria-label": "Account navigation",
			className: "mt-3 flex flex-wrap items-center gap-2 sm:justify-end",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, { userId }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "glass",
					size: "sm",
					className: "max-sm:size-9 max-sm:px-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard",
						"aria-label": "My account",
						title: "My account",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
							className: "sm:hidden",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-sm:hidden",
							children: "My account"
						})]
					})
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "glass",
					size: "sm",
					className: "max-sm:size-9 max-sm:px-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/admin",
						"aria-label": "Staff portal",
						title: "Staff portal",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							className: "sm:hidden",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-sm:hidden",
							children: "Staff portal"
						})]
					})
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "glass",
					size: "sm",
					className: "max-sm:size-9 max-sm:px-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/launch",
						"aria-label": "Launch",
						title: "Launch",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, {
							className: "sm:hidden",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-sm:hidden",
							children: "Launch"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "glass",
					size: "sm",
					className: "max-sm:size-9 max-sm:px-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/portal",
						"aria-label": "My portal",
						title: "My portal",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, {
							className: "sm:hidden",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-sm:hidden",
							children: "My portal"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "copper",
					size: "sm",
					className: "max-sm:size-9 max-sm:px-0",
					onClick: signOut,
					"aria-label": "Sign out",
					title: "Sign out",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
						className: "sm:hidden",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "max-sm:hidden",
						children: "Sign out"
					})]
				})
			]
		})]
	});
}
function StatusBadge({ status, tones }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${tones[status] ?? "bg-foreground/10"}`,
		children: status.replace("_", " ")
	});
}
//#endregion
export { StatusBadge as i, AppHeader as n, PageNavigation as r, AdminOnly as t };
