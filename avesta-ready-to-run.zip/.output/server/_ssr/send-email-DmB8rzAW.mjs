import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/@radix-ui/react-label+[...].mjs";
import { t as render } from "../_libs/@react-email/render+[...].mjs";
import { t as nodemailer } from "../_libs/nodemailer.mjs";
import { t as Body } from "../_libs/react-email__body.mjs";
import { t as Container } from "../_libs/react-email__container.mjs";
import { t as Head } from "../_libs/react-email__head.mjs";
import { t as Heading } from "../_libs/react-email__heading.mjs";
import { t as Html } from "../_libs/react-email__html.mjs";
import { t as Text } from "../_libs/react-email__text.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/send-email-DmB8rzAW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_LINES = {
	received: "We have received your loan application. Our team is reviewing it and you will hear from us here and on WhatsApp shortly.",
	approved: "Good news — your loan has been approved. Please sign in to your portal to confirm how you would like to receive the money.",
	rejected: "Thank you for applying. Unfortunately we are unable to approve this application at this time. You are welcome to talk to us on WhatsApp about other options.",
	collateral: "Your loan needs collateral before we can send the money. Please sign in to your portal to upload proof of the item.",
	disbursed: "Your money has been sent. Sign in to your portal to see the payment reference and your repayment schedule.",
	paid: "Your loan is fully repaid. Thank you for banking with Avesta Enterprises — you are welcome to apply again any time."
};
function LoanStatusEmail({ name, status, amount, note }) {
	const line = STATUS_LINES[status ?? ""] ?? "There is an update on your loan with Avesta Enterprises.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Html, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Body, {
		style: {
			backgroundColor: "#f7f3e8",
			fontFamily: "Arial, sans-serif"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			style: {
				backgroundColor: "#ffffff",
				padding: "32px",
				borderRadius: "8px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
					style: { color: "#163e33" },
					children: "Avesta Enterprises"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, { children: [
					"Hello ",
					name || "there",
					","
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: line }),
				amount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, { children: ["Loan amount: K", amount] }) : null,
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, { children: ["Note from our team: ", note] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: "View your loan: https://avesta.solutions/portal — or message us on WhatsApp: 0971 013 108." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: {
						color: "#6b7280",
						fontSize: "12px"
					},
					children: "Avesta Enterprises, House No. 3, Thom Avenue, Kansenshi, Ndola, Zambia."
				})
			]
		})
	})] });
}
var template$1 = {
	component: LoanStatusEmail,
	subject: (data) => `Your Avesta loan update${data["status"] ? ` — ${data["status"]}` : ""}`,
	displayName: "Loan status update",
	previewData: {
		name: "Jane",
		status: "approved",
		amount: "1,000.00"
	}
};
function AdminAlertEmail({ title, body, link }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Html, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Body, {
		style: {
			backgroundColor: "#f7f3e8",
			fontFamily: "Arial, sans-serif"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			style: {
				backgroundColor: "#ffffff",
				padding: "32px",
				borderRadius: "8px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
					style: { color: "#163e33" },
					children: "Avesta Staff Alert"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: { fontWeight: "bold" },
					children: title || "New activity on avesta.solutions"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: body || "Open the Staff portal for details." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, { children: ["Open the Staff portal: ", link || "https://avesta.solutions/admin"] })
			]
		})
	})] });
}
/**
* Template registry — maps template names to their React Email components.
* Import and register new templates here after creating them in this directory.
*/
var TEMPLATES = {
	"loan-status": template$1,
	"admin-alert": {
		component: AdminAlertEmail,
		subject: (data) => `Avesta alert: ${data["title"] ?? "new activity"}`,
		displayName: "Staff alert",
		previewData: {
			title: "New loan application",
			body: "Jane applied for K1,000."
		},
		to: "avestaenterprises4@gmail.com"
	}
};
var SITE_NAME = "Avesta Enterprises";
/**
*/
/**
* Renders a registered template and sends it from Avesta's own mailbox over
* SMTP — the one that comes with the domain, so mail arrives from a real
* address customers can reply to, and nothing is routed through a third party.
*
* Without SMTP settings the site still runs: emails are skipped and the reason
* is logged, rather than a loan application failing because mail is down.
*/
var transport = null;
function mailer() {
	if (transport) return transport;
	const host = process.env["SMTP_HOST"];
	const user = process.env["SMTP_USER"];
	const pass = process.env["SMTP_PASS"];
	if (!host || !user || !pass) return null;
	const port = Number(process.env["SMTP_PORT"] || 465);
	transport = nodemailer.createTransport({
		host,
		port,
		secure: port === 465,
		auth: {
			user,
			pass
		}
	});
	return transport;
}
async function sendTemplateEmail(templateName, to, options = {}) {
	const template = TEMPLATES[templateName];
	if (!template) throw new Error(`Template '${templateName}' not found. Available: ${Object.keys(TEMPLATES).join(", ")}`);
	const recipient = template.to ?? to;
	const element = import_react.createElement(template.component, options.templateData ?? {});
	const html = await render(element);
	const text = await render(element, { plainText: true });
	const subject = typeof template.subject === "function" ? template.subject(options.templateData ?? {}) : template.subject;
	const post = mailer();
	if (!post) {
		console.warn(`[email] SMTP is not configured, so "${templateName}" was not sent to ${recipient}`);
		return {
			sent: false,
			reason: "not_configured"
		};
	}
	await post.sendMail({
		from: `${SITE_NAME} <${process.env["SMTP_FROM"] || process.env["SMTP_USER"]}>`,
		to: recipient,
		subject,
		html,
		text,
		...options.replyTo ? { replyTo: options.replyTo } : {}
	});
	return { sent: true };
}
//#endregion
export { sendTemplateEmail };
