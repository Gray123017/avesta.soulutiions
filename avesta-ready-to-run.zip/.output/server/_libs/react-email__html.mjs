import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "./@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "./@radix-ui/react-label+[...].mjs";
//#region node_modules/@react-email/html/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var Html = import_react.forwardRef(({ children, lang = "en", dir = "ltr", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("html", {
	...props,
	dir,
	lang,
	ref,
	children
}));
Html.displayName = "Html";
//#endregion
export { Html as t };
