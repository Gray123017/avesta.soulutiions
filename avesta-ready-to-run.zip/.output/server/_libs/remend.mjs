//#region node_modules/remend/dist/index.js
var dn = Object.defineProperty;
var gn = Object.defineProperties;
var hn = Object.getOwnPropertyDescriptors;
var M = Object.getOwnPropertySymbols;
var mn = Object.prototype.hasOwnProperty;
var pn = Object.prototype.propertyIsEnumerable;
var P = (n, r, e) => r in n ? dn(n, r, {
	enumerable: true,
	configurable: true,
	writable: true,
	value: e
}) : n[r] = e;
var I = (n, r) => {
	for (var e in r || (r = {})) mn.call(r, e) && P(n, e, r[e]);
	if (M) for (var e of M(r)) pn.call(r, e) && P(n, e, r[e]);
	return n;
};
var b = (n, r) => gn(n, hn(r));
var kn = (n) => {
	let r = new Uint8Array(n.length + 1), e = false, i = false, o = 0;
	for (; o < n.length;) {
		if (n[o] === "\\" && o + 1 < n.length && n[o + 1] === "`") {
			let s = e || i ? 1 : 0;
			r[o + 1] = s, r[o + 2] = s, o += 2;
			continue;
		}
		if (n.substring(o, o + 3) === "```") {
			i = !i;
			let s = e || i ? 1 : 0, t = Math.min(o + 3, n.length);
			for (let a = o + 1; a <= t; a += 1) r[a] = s;
			o = t;
			continue;
		}
		!i && n[o] === "`" && (e = !e), r[o + 1] = e || i ? 1 : 0, o += 1;
	}
	return r;
};
var $ = null;
var c = (n, r) => {
	let e = $;
	return (e === null || e.text !== n) && (e = {
		text: n,
		lookup: kn(n)
	}, $ = e), e.lookup[Math.min(r, n.length)] === 1;
};
var In = (n, r) => {
	let e = n.substring(r, r + 3) === "```", i = r > 0 && n.substring(r - 1, r + 2) === "```", o = r > 1 && n.substring(r - 2, r + 1) === "```";
	return e || i || o;
};
var E = (n) => {
	let r = 0;
	for (let e = 0; e < n.length; e += 1) {
		if (n[e] === "\\" && e + 1 < n.length && n[e + 1] === "`") {
			e += 1;
			continue;
		}
		n[e] === "`" && !In(n, e) && (r += 1);
	}
	return r;
};
var d = (n, r) => {
	let e = false, i = false, o = -1;
	for (let s = 0; s < n.length; s += 1) {
		if (n[s] === "\\" && s + 1 < n.length && n[s + 1] === "`") {
			s += 1;
			continue;
		}
		if (n.substring(s, s + 3) === "```") {
			i = !i, s += 2;
			continue;
		}
		if (!i && n[s] === "`") if (e) {
			if (o < r && r < s) return true;
			e = false, o = -1;
		} else e = true, o = s;
	}
	return false;
};
var bn = /^(\s*(?:[-*+]|\d+[.)]) +)>(=?\s*[$]?\d)/gm;
var y = (n) => !n || typeof n != "string" || !n.includes(">") ? n : n.replace(bn, (r, e, i, o) => c(n, o) ? r : `${e}\\>${i}`);
var N = /(\*\*)([^*]*\*?)$/;
var R = /(__)([^_]*?)$/;
var U = /(\*\*\*)([^*]*?)$/;
var W = /(\*)([^*]*?)$/;
var D = /(_)([^_]*?)$/;
var K = /(`)([^`]*?)$/;
var H = /(~~)([^~]*?)$/;
var g = /^[\s_~*`]*$/;
var C = /^[\s]*[-*+][\s]+$/;
var w = /[\p{L}\p{N}_]/u;
var G = /^```[^`\n]*```?$/;
var F = /^\*{4,}$/;
var X = /(__)([^_]+)_$/;
var z = /(~~)([^~]+)~$/;
var A = /~~/g;
var f = (n) => {
	if (!n) return false;
	let r = n.charCodeAt(0);
	return r >= 48 && r <= 57 || r >= 65 && r <= 90 || r >= 97 && r <= 122 || r === 95 ? true : w.test(n);
};
var Y = (n, r) => {
	let e = 1;
	for (let i = r - 1; i >= 0; i -= 1) if (n[i] === "]") e += 1;
	else if (n[i] === "[" && (e -= 1, e === 0)) return i;
	return -1;
};
var T = (n, r) => {
	let e = 1;
	for (let i = r + 1; i < n.length; i += 1) if (n[i] === "[") e += 1;
	else if (n[i] === "]" && (e -= 1, e === 0)) return i;
	return -1;
};
var An = (n) => n === "inlineLatex" || n === "blockLatex";
var Tn = (n, r) => r === "[" && n === "none" ? "blockLatex" : r === "]" && n === "blockLatex" ? "none" : r === "(" && n === "none" ? "inlineLatex" : r === ")" && n === "inlineLatex" ? "none" : null;
var Ln = (n, r) => r ? n === "blockDollar" ? "none" : "blockDollar" : n === "blockDollar" ? n : n === "inlineDollar" ? "none" : "inlineDollar";
var h = (n, r) => {
	let e = "none";
	for (let i = 0; i < n.length && i < r; i += 1) {
		if (n[i] === "\\" && n[i + 1] === "$") {
			i += 1;
			continue;
		}
		if (n[i] === "\\") {
			let o = Tn(e, n[i + 1]);
			if (o !== null) {
				e = o, i += 1;
				continue;
			}
		}
		if (n[i] === "$" && !An(e)) {
			let o = n[i + 1] === "$";
			e = Ln(e, o), o && (i += 1);
		}
	}
	return e !== "none";
};
var Bn = (n, r) => {
	for (let e = r; e < n.length; e += 1) {
		if (n[e] === ")") return true;
		if (n[e] === `
`) return false;
	}
	return false;
};
var m = (n, r) => {
	for (let e = r - 1; e >= 0; e -= 1) {
		if (n[e] === ")") return false;
		if (n[e] === "(") return e > 0 && n[e - 1] === "]" ? Bn(n, r) : false;
		if (n[e] === `
`) return false;
	}
	return false;
};
var j = (n, r) => {
	for (let e = r - 1; e >= 0; e -= 1) {
		if (n[e] === ">") return false;
		if (n[e] === "<") {
			let i = e + 1 < n.length ? n[e + 1] : "";
			return i >= "a" && i <= "z" || i >= "A" && i <= "Z" || i === "/";
		}
		if (n[e] === `
`) return false;
	}
	return false;
};
var p = (n, r, e) => {
	let i = 0;
	for (let l = r - 1; l >= 0; l -= 1) if (n[l] === `
`) {
		i = l + 1;
		break;
	}
	let o = n.length;
	for (let l = r; l < n.length; l += 1) if (n[l] === `
`) {
		o = l;
		break;
	}
	let s = n.substring(i, o), t = 0, a = false;
	for (let l of s) if (l === e) t += 1;
	else if (l !== " " && l !== "	") {
		a = true;
		break;
	}
	return t >= 3 && !a;
};
var Z = (n) => n.includes("$") || n.includes("\\(") || n.includes("\\[");
var Sn = (n, r, e, i) => e === "\\" || Z(n) && h(n, r) ? true : e !== "*" && i === "*" ? (r < n.length - 2 ? n[r + 2] : "") !== "*" : e === "*" || (!e || e === " " || e === "	" || e === `
`) && (!i || i === " " || i === "	" || i === `
`);
var k = (n) => n === " " || n === "	" || n === `
`;
var On = (n, r) => !!(n && r && f(n) && f(r));
var _n = (n, r, e, i) => {
	let o = On(n, r), s = !!r && !k(r), t = !!n && !k(n);
	return o && e % 2 === 0 && !i ? { count: false } : t && e % 2 === 1 || s ? {
		count: true,
		inWordAsteriskChain: o
	} : { count: false };
};
var v = (n) => {
	let r = 0, e = false, i = false, o = n.length;
	for (let s = 0; s < o; s += 1) {
		if (n[s] === "`" && s + 2 < o && n[s + 1] === "`" && n[s + 2] === "`") {
			e = !e, s += 2;
			continue;
		}
		if (e) continue;
		if (n[s] !== "*") {
			f(n[s]) || (i = false);
			continue;
		}
		let t = s > 0 ? n[s - 1] : "", a = s < o - 1 ? n[s + 1] : "";
		if (Sn(n, s, t, a)) continue;
		let l = _n(t, a, r, i);
		l.count && (r += 1, i = l.inWordAsteriskChain);
	}
	return r;
};
var Mn = (n, r, e, i) => !!(e === "\\" || Z(n) && h(n, r) || m(n, r) || j(n, r) || e === "_" || i === "_" || e && i && f(e) && f(i));
var Pn = (n) => {
	let r = 0, e = false, i = n.length;
	for (let o = 0; o < i; o += 1) {
		if (n[o] === "`" && o + 2 < i && n[o + 1] === "`" && n[o + 2] === "`") {
			e = !e, o += 2;
			continue;
		}
		if (e || n[o] !== "_") continue;
		let s = o > 0 ? n[o - 1] : "", t = o < i - 1 ? n[o + 1] : "";
		Mn(n, o, s, t) || (r += 1);
	}
	return r;
};
var $n = (n) => {
	let r = 0, e = 0, i = false;
	for (let o = 0; o < n.length; o += 1) {
		if (n[o] === "`" && o + 2 < n.length && n[o + 1] === "`" && n[o + 2] === "`") {
			e >= 3 && (r += Math.floor(e / 3)), e = 0, i = !i, o += 2;
			continue;
		}
		i || (n[o] === "*" ? e += 1 : (e >= 3 && (r += Math.floor(e / 3)), e = 0));
	}
	return e >= 3 && (r += Math.floor(e / 3)), r;
};
var L = (n) => {
	let r = 0, e = false;
	for (let i = 0; i < n.length; i += 1) {
		if (n[i] === "`" && i + 2 < n.length && n[i + 1] === "`" && n[i + 2] === "`") {
			e = !e, i += 2;
			continue;
		}
		e || n[i] === "*" && i + 1 < n.length && n[i + 1] === "*" && (r += 1, i += 1);
	}
	return r;
};
var Q = (n) => {
	let r = 0, e = false;
	for (let i = 0; i < n.length; i += 1) {
		if (n[i] === "`" && i + 2 < n.length && n[i + 1] === "`" && n[i + 2] === "`") {
			e = !e, i += 2;
			continue;
		}
		e || n[i] === "_" && i + 1 < n.length && n[i + 1] === "_" && (r += 1, i += 1);
	}
	return r;
};
var En = (n, r, e) => {
	if (!r || g.test(r)) return true;
	let o = n.substring(0, e).lastIndexOf(`
`), s = o === -1 ? 0 : o + 1, t = n.substring(s, e);
	return C.test(t) && r.includes(`
`) ? true : p(n, e, "*");
};
var q = (n) => {
	let r = n.match(N);
	if (!r) return n;
	let e = r[2], i = n.lastIndexOf(r[1]);
	return c(n, i) || d(n, i) || En(n, e, i) ? n : L(n) % 2 === 1 ? e.endsWith("*") ? `${n}*` : `${n}**` : n;
};
var yn = (n, r, e) => {
	if (!r || g.test(r)) return true;
	let o = n.substring(0, e).lastIndexOf(`
`), s = o === -1 ? 0 : o + 1, t = n.substring(s, e);
	return C.test(t) && r.includes(`
`) ? true : p(n, e, "_");
};
var J = (n) => {
	let r = n.match(R);
	if (!r) {
		let s = n.match(X);
		if (s) {
			let t = n.lastIndexOf(s[1]);
			if (!(c(n, t) || d(n, t)) && Q(n) % 2 === 1) return `${n}_`;
		}
		return n;
	}
	let e = r[2], i = n.lastIndexOf(r[1]);
	return c(n, i) || d(n, i) || yn(n, e, i) ? n : Q(n) % 2 === 1 ? `${n}__` : n;
};
var Nn = (n) => {
	let r = false;
	for (let e = 0; e < n.length; e += 1) {
		if (n[e] === "`" && e + 2 < n.length && n[e + 1] === "`" && n[e + 2] === "`") {
			r = !r, e += 2;
			continue;
		}
		if (!r && n[e] === "*" && n[e - 1] !== "*" && n[e + 1] !== "*" && n[e - 1] !== "\\" && !h(n, e)) {
			let i = e > 0 ? n[e - 1] : "", o = e < n.length - 1 ? n[e + 1] : "", s = !i || k(i), t = !o || k(o);
			if (s && t || i && o && f(i) && f(o) || t) continue;
			return e;
		}
	}
	return -1;
};
var V = (n) => {
	if (!n.match(W)) return n;
	let e = Nn(n);
	if (e === -1 || c(n, e) || d(n, e)) return n;
	let i = n.substring(e + 1);
	return !i || g.test(i) ? n : v(n) % 2 === 1 ? `${n}*` : n;
};
var x = (n) => {
	let r = false;
	for (let e = 0; e < n.length; e += 1) {
		if (n[e] === "`" && e + 2 < n.length && n[e + 1] === "`" && n[e + 2] === "`") {
			r = !r, e += 2;
			continue;
		}
		if (!r && n[e] === "_" && n[e - 1] !== "_" && n[e + 1] !== "_" && n[e - 1] !== "\\" && !h(n, e) && !m(n, e)) {
			let i = e > 0 ? n[e - 1] : "", o = e < n.length - 1 ? n[e + 1] : "";
			if (i && o && f(i) && f(o)) continue;
			return e;
		}
	}
	return -1;
};
var Rn = (n) => {
	let r = n.length;
	for (; r > 0 && n[r - 1] === `
`;) r -= 1;
	if (r < n.length) return `${n.slice(0, r)}_${n.slice(r)}`;
	return `${n}_`;
};
var Un = (n) => {
	if (!n.endsWith("**")) return null;
	let r = n.slice(0, -2);
	if (L(r) % 2 !== 1) return null;
	let i = r.indexOf("**"), o = x(r);
	return i !== -1 && o !== -1 && i < o ? `${r}_**` : null;
};
var nn = (n) => {
	if (!n.match(D)) return n;
	let e = x(n);
	if (e === -1) return n;
	let i = n.substring(e + 1);
	if (!i || g.test(i) || c(n, e) || d(n, e)) return n;
	if (Pn(n) % 2 === 1) {
		let s = Un(n);
		return s !== null ? s : Rn(n);
	}
	return n;
};
var Wn = (n) => {
	let r = L(n), e = v(n);
	return r % 2 === 0 && e % 2 === 0;
};
var Dn = (n, r, e) => !r || g.test(r) || c(n, e) || d(n, e) ? true : p(n, e, "*");
var en = (n) => {
	if (F.test(n)) return n;
	let r = n.match(U);
	if (!r) return n;
	let e = r[2];
	return Dn(n, e, n.lastIndexOf(r[1])) ? n : $n(n) % 2 === 1 ? Wn(n) ? n : `${n}***` : n;
};
var Kn = /<[a-zA-Z/][^>]*$/;
var rn = (n) => {
	let r = n.match(Kn);
	return !r || r.index === void 0 || c(n, r.index) ? n : n.substring(0, r.index).trimEnd();
};
var Hn = (n) => !n.match(G) || n.includes(`
`) ? null : n.endsWith("``") && !n.endsWith("```") ? `${n}\`` : n;
var wn = (n) => (n.match(/```/g) || []).length % 2 === 1;
var on = (n) => {
	let r = Hn(n);
	if (r !== null) return r;
	let e = n.match(K);
	if (e && !wn(n)) {
		let i = e[2];
		if (!i || g.test(i)) return n;
		if (E(n) % 2 === 1) return `${n}\``;
	}
	return n;
};
var sn = (n, r) => r >= 2 && n.substring(r - 2, r + 1) === "```" || r >= 1 && n.substring(r - 1, r + 2) === "```" || r <= n.length - 3 && n.substring(r, r + 3) === "```";
var Gn = (n) => {
	let r = 0, e = false;
	for (let i = 0; i < n.length - 1; i += 1) n[i] === "`" && !sn(n, i) && (e = !e), !e && n[i] === "$" && n[i + 1] === "$" && (r += 1, i += 1);
	return r;
};
var Fn = (n) => {
	let r = 0, e = false;
	for (let i = 0; i < n.length; i += 1) {
		if (n[i] === "\\") {
			i += 1;
			continue;
		}
		if (n[i] === "`" && !sn(n, i)) {
			e = !e;
			continue;
		}
		!e && n[i] === "$" && (i + 1 < n.length && n[i + 1] === "$" ? i += 1 : r += 1);
	}
	return r;
};
var Xn = (n) => {
	if (n.endsWith("$") && !n.endsWith("$$")) return `${n}$`;
	let r = n.indexOf("$$");
	return r !== -1 && n.indexOf(`
`, r) !== -1 && !n.endsWith(`
`) ? `${n}
$$` : `${n}$$`;
};
var tn = (n) => Gn(n) % 2 === 0 ? n : Xn(n);
var ln = (n) => Fn(n) % 2 === 1 ? `${n}$` : n;
var zn = (n, r, e) => {
	if (n.substring(r + 2).includes(")")) return null;
	let o = Y(n, r);
	if (o === -1 || c(n, o)) return null;
	let s = o > 0 && n[o - 1] === "!", t = s ? o - 1 : o, a = n.substring(0, t);
	if (s) return a;
	let l = n.substring(o + 1, r);
	return e === "text-only" ? `${a}${l}` : `${a}[${l}](streamdown:incomplete-link)`;
};
var an = (n, r) => {
	for (let e = 0; e < r; e++) if (n[e] === "[" && !c(n, e)) {
		if (e > 0 && n[e - 1] === "!") continue;
		let i = T(n, e);
		if (i === -1) return e;
		if (i + 1 < n.length && n[i + 1] === "(") {
			let o = n.indexOf(")", i + 2);
			o !== -1 && (e = o);
		}
	}
	return r;
};
var Yn = (n, r, e) => {
	let i = r > 0 && n[r - 1] === "!", o = i ? r - 1 : r;
	if (!n.substring(r + 1).includes("]")) {
		let a = n.substring(0, o);
		if (i) return a;
		if (e === "text-only") {
			let l = an(n, r);
			return n.substring(0, l) + n.substring(l + 1);
		}
		return `${n}](streamdown:incomplete-link)`;
	}
	if (T(n, r) === -1) {
		let a = n.substring(0, o);
		if (i) return a;
		if (e === "text-only") {
			let l = an(n, r);
			return n.substring(0, l) + n.substring(l + 1);
		}
		return `${n}](streamdown:incomplete-link)`;
	}
	return null;
};
var B = (n, r = "protocol") => {
	let e = n.lastIndexOf("](");
	if (e !== -1 && !c(n, e)) {
		let i = zn(n, e, r);
		if (i !== null) return i;
	}
	for (let i = n.length - 1; i >= 0; i -= 1) if (n[i] === "[" && !c(n, i)) {
		let o = Yn(n, i, r);
		if (o !== null) return o;
	}
	return n;
};
var jn = /^-{1,2}$/;
var Qn = /^[\s]*-{1,2}[\s]+$/;
var Zn = /^={1,2}$/;
var vn = /^[\s]*={1,2}[\s]+$/;
var cn = (n) => {
	if (!n || typeof n != "string") return n;
	let r = n.lastIndexOf(`
`);
	if (r === -1) return n;
	let e = n.substring(r + 1), i = n.substring(0, r), o = e.trim();
	if (jn.test(o) && !e.match(Qn)) {
		let t = i.split(`
`).at(-1);
		if (t && t.trim().length > 0) return `${n}\u200B`;
	}
	if (Zn.test(o) && !e.match(vn)) {
		let t = i.split(`
`).at(-1);
		if (t && t.trim().length > 0) return `${n}\u200B`;
	}
	return n;
};
var qn = /([\p{L}\p{N}_])~(?!~)(?=[\p{L}\p{N}_])/gu;
var un = (n) => !n || typeof n != "string" || !n.includes("~") ? n : n.replace(qn, (r, e, i) => {
	return c(n, i + e.length) ? r : `${e}\\~`;
});
var fn = (n) => {
	var e, i;
	let r = n.match(H);
	if (r) {
		let o = r[2];
		if (!o || g.test(o)) return n;
		let s = n.lastIndexOf(r[1]);
		if (c(n, s) || d(n, s)) return n;
		if (((e = n.match(A)) == null ? void 0 : e.length) % 2 === 1) return `${n}~~`;
	} else {
		let o = n.match(z);
		if (o) {
			let s = n.lastIndexOf(o[0].slice(0, 2));
			if (c(n, s) || d(n, s)) return n;
			if (((i = n.match(A)) == null ? void 0 : i.length) % 2 === 1) return `${n}~`;
		}
	}
	return n;
};
var S = (n) => n !== false;
var Jn = (n) => n === true;
var u = {
	SINGLE_TILDE: 0,
	COMPARISON_OPERATORS: 5,
	HTML_TAGS: 10,
	SETEXT_HEADINGS: 15,
	LINKS: 20,
	BOLD_ITALIC: 30,
	BOLD: 35,
	ITALIC_DOUBLE_UNDERSCORE: 40,
	ITALIC_SINGLE_ASTERISK: 41,
	ITALIC_SINGLE_UNDERSCORE: 42,
	INLINE_CODE: 50,
	STRIKETHROUGH: 60,
	KATEX: 70,
	INLINE_KATEX: 75,
	DEFAULT: 100
};
var Vn = [
	{
		handler: {
			name: "singleTilde",
			handle: un,
			priority: u.SINGLE_TILDE
		},
		optionKey: "singleTilde"
	},
	{
		handler: {
			name: "comparisonOperators",
			handle: y,
			priority: u.COMPARISON_OPERATORS
		},
		optionKey: "comparisonOperators"
	},
	{
		handler: {
			name: "htmlTags",
			handle: rn,
			priority: u.HTML_TAGS
		},
		optionKey: "htmlTags"
	},
	{
		handler: {
			name: "setextHeadings",
			handle: cn,
			priority: u.SETEXT_HEADINGS
		},
		optionKey: "setextHeadings"
	},
	{
		handler: {
			name: "links",
			handle: B,
			priority: u.LINKS
		},
		optionKey: "links",
		earlyReturn: (n) => n.endsWith("](streamdown:incomplete-link)")
	},
	{
		handler: {
			name: "boldItalic",
			handle: en,
			priority: u.BOLD_ITALIC
		},
		optionKey: "boldItalic"
	},
	{
		handler: {
			name: "bold",
			handle: q,
			priority: u.BOLD
		},
		optionKey: "bold"
	},
	{
		handler: {
			name: "italicDoubleUnderscore",
			handle: J,
			priority: u.ITALIC_DOUBLE_UNDERSCORE
		},
		optionKey: "italic"
	},
	{
		handler: {
			name: "italicSingleAsterisk",
			handle: V,
			priority: u.ITALIC_SINGLE_ASTERISK
		},
		optionKey: "italic"
	},
	{
		handler: {
			name: "italicSingleUnderscore",
			handle: nn,
			priority: u.ITALIC_SINGLE_UNDERSCORE
		},
		optionKey: "italic"
	},
	{
		handler: {
			name: "inlineCode",
			handle: on,
			priority: u.INLINE_CODE
		},
		optionKey: "inlineCode"
	},
	{
		handler: {
			name: "strikethrough",
			handle: fn,
			priority: u.STRIKETHROUGH
		},
		optionKey: "strikethrough"
	},
	{
		handler: {
			name: "katex",
			handle: tn,
			priority: u.KATEX
		},
		optionKey: "katex"
	},
	{
		handler: {
			name: "inlineKatex",
			handle: ln,
			priority: u.INLINE_KATEX
		},
		optionKey: "inlineKatex"
	}
];
var xn = (n) => {
	var e;
	let r = (e = n == null ? void 0 : n.linkMode) != null ? e : "protocol";
	return Vn.filter(({ handler: i, optionKey: o }) => i.name === "links" ? S(n == null ? void 0 : n.links) || S(n == null ? void 0 : n.images) : i.name === "inlineKatex" ? Jn(n == null ? void 0 : n.inlineKatex) : S(n == null ? void 0 : n[o])).map(({ handler: i, earlyReturn: o }) => i.name === "links" ? {
		handler: b(I({}, i), { handle: (s) => B(s, r) }),
		earlyReturn: r === "protocol" ? o : void 0
	} : {
		handler: i,
		earlyReturn: o
	});
};
var ne = (n, r) => {
	var t;
	if (!n || typeof n != "string") return n;
	let e = n.endsWith(" ") && !n.endsWith("  ") ? n.slice(0, -1) : n, i = xn(r), o = ((t = r == null ? void 0 : r.handlers) != null ? t : []).map((a) => {
		var l;
		return {
			handler: b(I({}, a), { priority: (l = a.priority) != null ? l : u.DEFAULT }),
			earlyReturn: void 0
		};
	}), s = [...i, ...o].sort((a, l) => {
		var O, _;
		return ((O = a.handler.priority) != null ? O : 0) - ((_ = l.handler.priority) != null ? _ : 0);
	});
	for (let { handler: a, earlyReturn: l } of s) if (e = a.handle(e), l != null && l(e)) return e;
	return e;
};
var We = ne;
//#endregion
export { We as t };
