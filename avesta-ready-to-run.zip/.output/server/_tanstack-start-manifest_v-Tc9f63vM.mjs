//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Tc9f63vM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/advisor",
			"/apply",
			"/auth",
			"/directory",
			"/it-help",
			"/legal",
			"/reset-password",
			"/tools"
		],
		preloads: [
			"/assets/index-BQY-HGa9.js",
			"/assets/rolldown-runtime-Dd_uD5pT.js",
			"/assets/jsx-runtime-DKj5X9O4.js",
			"/assets/bundle-mjs-qCzB-CxS.js",
			"/assets/useStore-BuTqJr0T.js",
			"/assets/qss-Bqk2G4CH.js",
			"/assets/matchContext-BONYEjyv.js",
			"/assets/redirect-Dhm19zUi.js",
			"/assets/button-6slv2djB.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQY-HGa9.js"
		} }]
	},
	"/": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BY-Xvk7T.js",
			"/assets/shield-check-C9ccAA36.js",
			"/assets/wallet-DHo63JaS.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/admin",
			"/_authenticated/dashboard",
			"/_authenticated/launch",
			"/_authenticated/portal",
			"/_authenticated/schedule/$loanId"
		],
		preloads: ["/assets/route-BE7Nkrbo.js"]
	},
	"/advisor": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/advisor.tsx",
		children: void 0,
		preloads: [
			"/assets/advisor-DooUMIc2.js",
			"/assets/createServerFn-BMmG-0u_.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useServerFn-_XWvE-VT.js",
			"/assets/useMutation-BZ_tQ4ZV.js",
			"/assets/textarea-6W_MQk3f.js"
		]
	},
	"/apply": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/apply.tsx",
		children: void 0,
		preloads: [
			"/assets/apply-D_E15pyY.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/input-GiMExoHM.js",
			"/assets/avesta-D3DkgQV6.js",
			"/assets/loan-emails.functions-zQwS-LiM.js",
			"/assets/label-B6X_b0Av.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-METxBrwu.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/input-GiMExoHM.js",
			"/assets/label-B6X_b0Av.js"
		]
	},
	"/directory": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/directory.tsx",
		children: void 0,
		preloads: [
			"/assets/directory-BgXs84YP.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/shield-check-C9ccAA36.js",
			"/assets/wallet-DHo63JaS.js",
			"/assets/x-CVVW_ZIe.js"
		]
	},
	"/it-help": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/it-help.tsx",
		children: void 0,
		preloads: [
			"/assets/it-help-AkdEu970.js",
			"/assets/createServerFn-BMmG-0u_.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useServerFn-_XWvE-VT.js",
			"/assets/chunk-YOKDWASO-DGFnLn36.js",
			"/assets/auth-middleware-CFX_znc8.js",
			"/assets/it-learn.functions-DikGHltL.js",
			"/assets/shield-check-C9ccAA36.js",
			"/assets/x-CVVW_ZIe.js",
			"/assets/input-GiMExoHM.js",
			"/assets/textarea-6W_MQk3f.js"
		]
	},
	"/legal": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/legal.tsx",
		children: void 0,
		preloads: ["/assets/legal-BZEr8bOX.js", "/assets/AppHeader-BA-BmqKg.js"]
	},
	"/reset-password": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DF9aUpCg.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/input-GiMExoHM.js",
			"/assets/label-B6X_b0Av.js"
		]
	},
	"/tools": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/tools.tsx",
		children: void 0,
		preloads: [
			"/assets/tools-C6I8tNAk.js",
			"/assets/createServerFn-BMmG-0u_.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useServerFn-_XWvE-VT.js",
			"/assets/input-GiMExoHM.js",
			"/assets/avesta-D3DkgQV6.js",
			"/assets/label-B6X_b0Av.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-bf6bDmEq.js",
			"/assets/createServerFn-BMmG-0u_.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useServerFn-_XWvE-VT.js",
			"/assets/useMutation-BZ_tQ4ZV.js",
			"/assets/auth-middleware-CFX_znc8.js",
			"/assets/it-learn.functions-DikGHltL.js",
			"/assets/input-GiMExoHM.js",
			"/assets/textarea-6W_MQk3f.js",
			"/assets/avesta-D3DkgQV6.js",
			"/assets/loan-emails.functions-zQwS-LiM.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BiTyDD5f.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useMutation-BZ_tQ4ZV.js",
			"/assets/input-GiMExoHM.js",
			"/assets/textarea-6W_MQk3f.js",
			"/assets/avesta-D3DkgQV6.js",
			"/assets/label-B6X_b0Av.js"
		]
	},
	"/_authenticated/launch": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/launch.tsx",
		children: void 0,
		preloads: [
			"/assets/launch-BJMHZUpC.js",
			"/assets/createServerFn-BMmG-0u_.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/useServerFn-_XWvE-VT.js",
			"/assets/auth-middleware-CFX_znc8.js"
		]
	},
	"/_authenticated/portal": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/portal.tsx",
		children: void 0,
		preloads: [
			"/assets/portal-CmZ9gYBk.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/avesta-D3DkgQV6.js"
		]
	},
	"/_authenticated/schedule/$loanId": {
		filePath: "/home/claude/kyc/avesta-site-export/src/routes/_authenticated/schedule.$loanId.tsx",
		children: void 0,
		preloads: [
			"/assets/schedule._loanId-ClCbGK3P.js",
			"/assets/AppHeader-BA-BmqKg.js",
			"/assets/input-GiMExoHM.js",
			"/assets/avesta-D3DkgQV6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
