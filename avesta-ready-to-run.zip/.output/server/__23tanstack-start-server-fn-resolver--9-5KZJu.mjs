//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver--9-5KZJu.js
var manifest = {
	"0c1622454411fadf13257888c96cb3e8749d28765bca3e88502ed8ccbe0ef6bb": {
		functionName: "autoReplyTicket_createServerFn_handler",
		importer: () => import("./_ssr/it-assist.functions-BulZDkdQ.mjs")
	},
	"11684e41ed203e62d7509cf305928814bd8c675219aed3c8af5d55b7f1152b28": {
		functionName: "promoteToTopic_createServerFn_handler",
		importer: () => import("./_ssr/it-learn.functions-BOgyzcWz.mjs")
	},
	"1b0f1285003491e80d9c5454741721d7a2ecbfb70d9b57b2c65196b724160f22": {
		functionName: "getAdvice_createServerFn_handler",
		importer: () => import("./_ssr/advisor.functions-ZpPa9v_i.mjs")
	},
	"1e0941a199f160fb788d4f4f39a3b00910ec53d0901baa56e06c4430e14dc7f8": {
		functionName: "getRates_createServerFn_handler",
		importer: () => import("./_ssr/rates.functions-dDZ2-sb2.mjs")
	},
	"2f1c73f9e24ebe72c705d295e336913c9c1e020140aca47d15ca892445dc6794": {
		functionName: "deleteCustomer_createServerFn_handler",
		importer: () => import("./_ssr/admin-tools.functions-7pZSiuET.mjs")
	},
	"33f85d20a6c0eabf1f0637584e258ff456e03893e25c5eb1ef6b660a171dde2d": {
		functionName: "learningQueue_createServerFn_handler",
		importer: () => import("./_ssr/it-learn.functions-BOgyzcWz.mjs")
	},
	"3a46d25e6804bae49baa23e35d434e5b5a3b4e1ffe6810a527b2f565f7d796ed": {
		functionName: "removeAdmin_createServerFn_handler",
		importer: () => import("./_ssr/admin-tools.functions-7pZSiuET.mjs")
	},
	"62bed3c1c0477d30bf1aef5d1c28d08f110afea4608e5fabd46ec233948169d8": {
		functionName: "itChat_createServerFn_handler",
		importer: () => import("./_ssr/it-assist.functions-BulZDkdQ.mjs")
	},
	"69793c98f1f20d448fcf554129068c698815fa86c684ebbf0e716f4e02a820f8": {
		functionName: "learnedTopics_createServerFn_handler",
		importer: () => import("./_ssr/it-learn.functions-BOgyzcWz.mjs")
	},
	"70a2e888f5b17f1d42c4b7d91733a75478930126c5885a27410ae82fc68cbad2": {
		functionName: "addAdmin_createServerFn_handler",
		importer: () => import("./_ssr/admin-tools.functions-7pZSiuET.mjs")
	},
	"775e3ec415bf10866650f14a6c56f70240c979393980b088f01e639562c6eb5b": {
		functionName: "checkDomain_createServerFn_handler",
		importer: () => import("./_ssr/domain.functions-CLR6wUlR.mjs")
	},
	"8b9041f9bd81c9775a830ec4399832d706290211a2b7fcfc32f5c8379302b5f1": {
		functionName: "notifyLoanApplied_createServerFn_handler",
		importer: () => import("./_ssr/loan-emails.functions-BZOpfpbB.mjs")
	},
	"a73d567cc28864a011e4fcedfbdcc42e1cbfd275c17e01f4e757761858ae5474": {
		functionName: "researchProblem_createServerFn_handler",
		importer: () => import("./_ssr/it-learn.functions-BOgyzcWz.mjs")
	},
	"ac5fc9a203621458bff34b85f2ddfab947f1d3af573647d0ab26dbc5c8026279": {
		functionName: "notifyLoanDecision_createServerFn_handler",
		importer: () => import("./_ssr/loan-emails.functions-BZOpfpbB.mjs")
	},
	"c8a7e24030f37de350fc982d3af5723fc27c506758ea41bd22ec73fd0618863f": {
		functionName: "listAdmins_createServerFn_handler",
		importer: () => import("./_ssr/admin-tools.functions-7pZSiuET.mjs")
	},
	"fcba44fb66e3d752caf4434acc8dcaa2bef62c5a9e5dec23c0de2fbff49abf06": {
		functionName: "logQuestion_createServerFn_handler",
		importer: () => import("./_ssr/it-learn.functions-BOgyzcWz.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
