/* Avesta service worker.
 *
 * Two jobs. It makes the site installable on a phone — Chrome only offers
 * "Install app" when a worker handles fetch — and it keeps the site usable
 * when the connection drops, which on Zambian mobile data it regularly does.
 *
 * Deliberately careful about what it keeps:
 *   · Built assets are content-hashed, so they can be served from the cache
 *     safely and refreshed in the background.
 *   · Pages always go to the network first, so nobody ever sees yesterday's
 *     loan balance from a cache. Only if the network fails do they get the
 *     offline page.
 *   · Anything to do with accounts or data — Supabase, server functions — is
 *     never cached at all.
 */
const VERSION = "avesta-v2";
const SHELL = ["/offline.html", "/icons/icon-192.png", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
      await self.clients.claim();
    })(),
  );
});

// Lets a new version take over without the person closing every tab.
self.addEventListener("message", (event) => {
  if (event.data === "skip-waiting") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;          // never another site's data
  if (url.pathname.startsWith("/_serverFn")) return;         // server functions: always live
  if (url.pathname.startsWith("/api")) return;

  // Pages: network first, cache only as a last resort
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).catch(async () => (await caches.match("/offline.html")) ?? Response.error()),
    );
    return;
  }

  // Built assets carry a hash in the name, so a cached copy is always the
  // right copy. Serve it immediately and refresh quietly behind the scenes.
  if (url.pathname.startsWith("/assets/") || url.pathname.startsWith("/icons/")) {
    event.respondWith(
      (async () => {
        const hit = await caches.match(req);
        const live = fetch(req)
          .then(async (res) => {
            if (res.ok) (await caches.open(VERSION)).put(req, res.clone());
            return res;
          })
          .catch(() => hit ?? Response.error());
        return hit ?? live;
      })(),
    );
  }
});
