@echo off
setlocal
rem G-IT visible, user-started checks only. No startup registration or remote access.
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0source\tests\Run-WindowsChecks.ps1"
pause