<# User-started validation on an authorized, clean Windows test PC or VM.
   Reports only OS/build, installer hash and test outcomes; never credentials. #>
$ErrorActionPreference = 'Stop'
$bundleRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$reportPath = Join-Path $bundleRoot 'Windows-validation-result.txt'
$exePath = Join-Path $bundleRoot 'G-IT-Setup-x64.exe'
$windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        $process = Start-Process -FilePath $windowsPowerShell -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"") -Verb RunAs -PassThru -Wait
        exit $process.ExitCode
    } catch {
        Write-Host 'Administrator permission was not granted. No checks were run.'
        exit 1
    }
}

Add-Type -AssemblyName System.Windows.Forms
$notice = @'
Run only on a clean test PC or VM you are authorized to manage.

These checks temporarily create a trusted localhost certificate, HTTPS binding,
protected agent files and a SYSTEM reporting task. They attempt cleanup afterward.
They refuse to overwrite an existing agent. No production code or credential
is needed. Use a VM snapshot or backup before testing.

This tests the reporting engine, NOT the EXE GUI or an actual reboot.
The result file includes a separate manual checklist.

Do you authorize these temporary changes on this test PC?
'@
$consent = [Windows.Forms.MessageBox]::Show($notice, 'Authorize G-IT Windows checks', [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Warning)
if ($consent -ne [Windows.Forms.DialogResult]::Yes) {
    Write-Host 'Authorization declined. No checks were run.'
    exit 1
}
if (-not (Test-Path -LiteralPath $exePath)) {
    Write-Host 'Extract the entire download ZIP before running these checks.'
    exit 1
}

$outcome = 'NOT RUN'
try {
    & $windowsPowerShell -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Test-WindowsLifecycle.ps1') -AuthorizeDisposableRunner
    if ($LASTEXITCODE -eq 0) { $outcome = 'PASS' } else { $outcome = 'FAIL (inspect the visible console for the failed check)' }
} catch {
    $outcome = 'FAIL (could not run checks; inspect the visible console)'
}

$hash = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash.ToLowerInvariant()
$os = Get-CimInstance Win32_OperatingSystem
$report = @"
G-IT WINDOWS VALIDATION
Generated: $(Get-Date -Format o)
Windows: $($os.Caption)
Version/build: $($os.Version) / $($os.BuildNumber)
OS architecture: $($os.OSArchitecture)
PowerShell test runtime: Windows PowerShell 5.1
Installer SHA-256: $hash

AUTOMATED LOCAL HTTPS FIXTURE CHECKS: $outcome
These checks cover parsing, authorization refusal, credential protection, ACL,
task configuration, fixture pairing, failed offline upload, SYSTEM recovery,
and reporting-engine removal. They do not prove production server pairing,
the real EXE GUI, package removal or a true reboot.
No username, hostname, serial number, server URL or credential is in this report.

MANUAL RESULTS
After the automated checks finish and clean up, use BUILD-AND-TEST.txt.
Replace NOT RUN with PASS or FAIL and add a brief observation for each test.
Do not enter enrollment codes, device tokens or private identifiers.

Consent refusal and cancel leave no installation: NOT RUN
EXE install, UAC, native GUI, Start menu and Apps entry: NOT RUN
Actual dashboard pairing and initial health snapshot: NOT RUN
Invalid, expired and consumed codes refused safely: NOT RUN
Duplicate pairing refused without changing existing enrollment: NOT RUN
True reboot sends a new report before manually running the agent: NOT RUN
Offline failure followed by automatic five-minute recovery: NOT RUN
Apps uninstall removes task, credentials, files, shortcuts and entry: NOT RUN
Reboot after uninstall sends no further reports: NOT RUN
Security-policy or unsigned-file warnings observed (no bypass): NOT RUN

Do not upload agent.json or local fixture events. Upload only this result file,
plus redacted evidence if needed. Passing engine checks alone is not a release.
"@
Set-Content -LiteralPath $reportPath -Value $report -Encoding UTF8
Write-Host "Result saved to $reportPath"
Write-Host 'Complete the manual checklist, then share Windows-validation-result.txt.'
if ($outcome -ne 'PASS') { exit 1 }
exit 0