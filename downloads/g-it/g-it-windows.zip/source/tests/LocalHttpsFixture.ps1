param(
    [Parameter(Mandatory=$true)][int]$Port,
    [Parameter(Mandatory=$true)][string]$EventPath,
    [Parameter(Mandatory=$true)][string]$DeviceToken
)

$ErrorActionPreference = 'Stop'
$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("https://localhost:$Port/")
$listener.Start()

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        try {
            if ($request.HttpMethod -eq 'GET' -and $request.Url.AbsolutePath -eq '/health') {
                $response.StatusCode = 200
                $bytes = [Text.Encoding]::UTF8.GetBytes('ready')
                $response.ContentType = 'text/plain'
                $response.ContentLength64 = $bytes.Length
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                continue
            }

            $reader = New-Object IO.StreamReader($request.InputStream, $request.ContentEncoding)
            $bodyText = $reader.ReadToEnd()
            $reader.Dispose()
            $body = $null
            if ($bodyText) { $body = $bodyText | ConvertFrom-Json }

            $event = [ordered]@{
                method = $request.HttpMethod
                path = $request.Url.AbsolutePath
                authorization = $request.Headers['Authorization']
                body = $body
            }
            Add-Content -LiteralPath $EventPath -Value (ConvertTo-Json -InputObject $event -Depth 8 -Compress) -Encoding UTF8

            if ($request.HttpMethod -eq 'POST' -and $request.Url.AbsolutePath -eq '/api/fleet/agents/enroll') {
                if ([string]$body.code -notmatch '^[A-Za-z0-9_-]{43}$') {
                    $response.StatusCode = 400
                    $responseText = '{"error":"invalid test enrollment"}'
                } else {
                    $response.StatusCode = 200
                    $responseText = ConvertTo-Json -InputObject @{ device = @{ id = 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee' }; deviceToken = $DeviceToken } -Compress
                }
            } elseif ($request.HttpMethod -eq 'PUT' -and $request.Url.AbsolutePath -eq '/api/fleet/agents/aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee/report') {
                if ($request.Headers['Authorization'] -cne "Bearer $DeviceToken") {
                    $response.StatusCode = 401
                    $responseText = '{"error":"unauthorized test report"}'
                } else {
                    $response.StatusCode = 200
                    $responseText = '{"accepted":true}'
                }
            } else {
                $response.StatusCode = 404
                $responseText = '{"error":"not found"}'
            }

            $bytes = [Text.Encoding]::UTF8.GetBytes($responseText)
            $response.ContentType = 'application/json'
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } finally {
            $response.Close()
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
}