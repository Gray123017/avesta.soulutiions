G-IT WINDOWS INSTALLER LIFECYCLE CI
==============================

For an ordinary authorized, clean Windows test PC/VM, extract the whole download
ZIP and open Run-WindowsChecks.cmd. This asks for UAC and explicit authorization,
runs the engine checks and writes Windows-validation-result.txt. Fill its
separate manual checklist after testing the actual EXE, pairing, reboot and
uninstall. Share only the result file, never credentials or fixture event logs.

Run Test-WindowsLifecycle.ps1 with built-in Windows PowerShell 5.1 from an
elevated, disposable Windows 10/11 x64 runner:

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File Test-WindowsLifecycle.ps1 -AuthorizeDisposableRunner

The required switch is explicit authorization to alter the disposable test
runner only. It authorizes direct exercise of the existing lifecycle engine; it
does not bypass installer consent and is never passed to the NSIS EXE. The test
creates a temporary localhost HTTPS fixture, temporary trusted certificate,
HTTP.sys binding/URL reservation, ProgramData state, and a SYSTEM scheduled
task. It validates PS1 AST parsing, rejection of Authorized=false without side
effects, DPAPI LocalMachine protection and restrictive ACL, boot and five-minute
task triggers, real HTTPS enrollment, offline failure and recovery, bearer-token
report delivery by the scheduled SYSTEM task, and local removal. Fixture state,
certificate, URL reservation, binding, and task are cleaned in finally.

CI builds and archives the real NSIS EXE and source package on windows-2022 and
windows-2025, then runs the lifecycle checks. CI does not execute the installer
GUI, perform a true reboot, or invoke /S. Those remain pending manual checks on
an authorized disposable VM: visually verify consent/UAC/session behavior and
the startup trigger after reboot. Do not invoke /S in automation: its intended
refusal uses a message box and may hang an unattended runner. Verify /S refusal
only with a controlled interactive UI test.

The HTTPS endpoint is a local test fixture with a disposable test-only token;
no production credentials or external service are used.