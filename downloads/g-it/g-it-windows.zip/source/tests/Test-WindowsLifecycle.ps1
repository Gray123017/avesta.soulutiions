param(
    [Parameter(Mandatory=$true)]
    [switch]$AuthorizeDisposableRunner
)

$ErrorActionPreference = 'Stop'
$windowsPowerShell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$testDirectory = $PSScriptRoot
$windowsDirectory = Split-Path -Parent $testDirectory
$lifecyclePath = Join-Path $windowsDirectory 'AgentLifecycle.ps1'
$agentPath = Join-Path $windowsDirectory 'Agent.ps1'
$fixturePath = Join-Path $testDirectory 'LocalHttpsFixture.ps1'
$taskName = 'Fleet Monitor - Visible System Health Reporting'
$homePath = Join-Path $env:ProgramData 'FleetMonitor'
$tempBase = $env:RUNNER_TEMP
if (-not $tempBase) { $tempBase = [IO.Path]::GetTempPath() }
$tempRoot = Join-Path $tempBase ("fleet-windows-lifecycle-" + [Guid]::NewGuid().ToString('N'))
$serverProcess = $null
$certificate = $null
$trustedCertificate = $null
$port = $null
$sslBindingAdded = $false
$sslBindingV6Added = $false
$urlAclAdded = $false
$failure = $null
$cleanupErrors = @()

function Assert-True([bool]$condition, [string]$message) {
    if (-not $condition) { throw "ASSERTION FAILED: $message" }
}

function Get-FixtureEvents([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return @() }
    $events = @()
    foreach ($line in (Get-Content -LiteralPath $path)) {
        if ($line.Trim()) { $events += ($line | ConvertFrom-Json) }
    }
    return $events
}

function Start-FixtureServer {
    $eventPath = Join-Path $tempRoot 'events.jsonl'
    $arguments = @(
        '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
        '-File', "`"$fixturePath`"",
        '-Port', [string]$port,
        '-EventPath', "`"$eventPath`"",
        '-DeviceToken', $script:deviceToken
    )
    $script:serverProcess = Start-Process -FilePath $windowsPowerShell -ArgumentList $arguments -WindowStyle Hidden -PassThru
    $healthUrl = "https://localhost:$port/health"
    $ready = $false
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        if ($script:serverProcess.HasExited) { throw 'Local HTTPS fixture exited before becoming ready.' }
        try {
            $null = Invoke-RestMethod -Uri $healthUrl -Method Get -TimeoutSec 2
            $ready = $true
            break
        } catch {
            Start-Sleep -Milliseconds 250
        }
    }
    Assert-True $ready 'Local trusted HTTPS fixture did not become ready.'
}

function Stop-FixtureServer {
    if ($script:serverProcess -and -not $script:serverProcess.HasExited) {
        Stop-Process -Id $script:serverProcess.Id -Force
        $script:serverProcess.WaitForExit()
    }
    $script:serverProcess = $null
}

function Wait-ForReport([int]$previousCount, [string]$eventPath) {
    for ($attempt = 0; $attempt -lt 120; $attempt++) {
        $reports = @(Get-FixtureEvents $eventPath | Where-Object { $_.method -eq 'PUT' -and $_.path -match '/report$' })
        if ($reports.Count -gt $previousCount) { return $reports }
        Start-Sleep -Milliseconds 500
    }
    throw 'Timed out waiting for the scheduled SYSTEM report to reach the HTTPS fixture.'
}

if (-not $AuthorizeDisposableRunner) {
    throw 'Explicitly pass -AuthorizeDisposableRunner only on an authorized disposable Windows CI runner. This authorizes the test runner, not the installer.'
}

if (-not [Environment]::Is64BitOperatingSystem -or [Environment]::OSVersion.Version.Major -lt 10) {
    throw 'Lifecycle tests require a disposable Windows 10/11 x64 runner.'
}
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Lifecycle tests require the disposable CI runner to have administrator privileges.'
}
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    throw "Refusing to overwrite existing scheduled task '$taskName'."
}
if (Test-Path -LiteralPath $homePath) {
    throw "Refusing to modify existing agent data at '$homePath'."
}

New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
$deviceToken = 'd' * 43
$enrollmentCode = 'e' * 43
$script:deviceToken = $deviceToken
$eventPath = Join-Path $tempRoot 'events.jsonl'

try {
    # Parse every PowerShell source and test file with the Windows PowerShell 5.1 parser.
    $psFiles = @(Get-ChildItem -Path $windowsDirectory -Filter '*.ps1' -File -Recurse)
    Assert-True ($psFiles.Count -gt 0) 'No PowerShell files were discovered for AST validation.'
    foreach ($file in $psFiles) {
        $tokens = $null
        $parseErrors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$parseErrors)
        Assert-True ($parseErrors.Count -eq 0) "PowerShell AST parse failed for $($file.FullName): $($parseErrors -join '; ')"
    }

    . $lifecyclePath
    . $agentPath

    # A rejected authorization must not create any local install state.
    $unauthorizedRejected = $false
    try {
        Install-FleetAgent -ServerUrl 'https://localhost' -EnrollmentCode $enrollmentCode -AgentSource $agentPath -Authorized $false
    } catch {
        $unauthorizedRejected = $_.Exception.Message -match 'Explicit authorization is required'
    }
    Assert-True $unauthorizedRejected 'Authorized=false was not rejected with the explicit-authorization guard.'
    Assert-True (-not (Test-Path -LiteralPath $homePath)) 'Authorized=false created installation files.'
    Assert-True (-not (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue)) 'Authorized=false created a scheduled task.'

    # Establish a short-lived localhost TLS identity trusted only for this test.
    $tcp = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, 0)
    $tcp.Start()
    $port = $tcp.LocalEndpoint.Port
    $tcp.Stop()
    $certificate = New-SelfSignedCertificate -DnsName 'localhost' -CertStoreLocation 'Cert:\LocalMachine\My' -FriendlyName 'G-IT CI lifecycle fixture'
    Export-Certificate -Cert $certificate -FilePath (Join-Path $tempRoot 'fixture.cer') | Out-Null
    $trustedCertificate = Import-Certificate -FilePath (Join-Path $tempRoot 'fixture.cer') -CertStoreLocation 'Cert:\LocalMachine\Root'
    $appId = '{58B2F9F7-0B9E-4626-9D61-1181D0D3B5CF}'
    & netsh.exe http add sslcert "ipport=0.0.0.0:$port" "appid=$appId" "certstorename=MY" "certhash=$($certificate.Thumbprint)" | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not bind the temporary HTTPS fixture certificate in HTTP.sys.' }
    $sslBindingAdded = $true
    & netsh.exe http add sslcert "ipport=[::]:$port" "appid=$appId" "certstorename=MY" "certhash=$($certificate.Thumbprint)" | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not bind the temporary HTTPS fixture certificate for IPv6 localhost.' }
    $sslBindingV6Added = $true
    & netsh.exe http add urlacl "url=https://localhost:$port/" 'user=BUILTIN\Administrators' | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not reserve the temporary localhost HTTPS fixture URL.' }
    $urlAclAdded = $true
    Start-FixtureServer

    Install-FleetAgent -ServerUrl "https://localhost:$port" -EnrollmentCode $enrollmentCode -AgentSource $agentPath -Authorized $true
    Assert-True (Test-Path -LiteralPath (Join-Path $homePath 'agent.json')) 'Pairing did not create agent configuration.'

    $config = Get-Content -LiteralPath (Join-Path $homePath 'agent.json') -Raw | ConvertFrom-Json
    $protected = [Convert]::FromBase64String($config.protectedToken)
    $unprotected = [Security.Cryptography.ProtectedData]::Unprotect($protected, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    try {
        $storedToken = [Text.Encoding]::UTF8.GetString($unprotected)
        Assert-True ($storedToken -ceq $deviceToken) 'Stored DPAPI credential did not decrypt to the fixture-issued token.'
    } finally {
        [Array]::Clear($unprotected, 0, $unprotected.Length)
    }

    $allowedSids = @('S-1-5-18', 'S-1-5-32-544')
    $acl = Get-Acl -LiteralPath $homePath
    $allowRules = @($acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]) | Where-Object { $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow })
    Assert-True ($allowRules.Count -gt 0) 'Agent data directory has no explicit allow rules.'
    $unexpectedSids = @($allowRules | ForEach-Object { $_.IdentityReference.Value } | Where-Object { $_ -notin $allowedSids } | Select-Object -Unique)
    Assert-True ($unexpectedSids.Count -eq 0) "Agent data ACL grants access outside SYSTEM/Administrators: $($unexpectedSids -join ', ')."
    Assert-True $acl.AreAccessRulesProtected 'Agent data directory still inherits permissions from its parent.'

    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
    Assert-True ($task.Principal.UserId -in @('SYSTEM', 'S-1-5-18')) 'Scheduled reporting task is not configured as SYSTEM.'
    Assert-True ($task.Actions.Count -eq 1 -and $task.Actions[0].Arguments -match 'Agent\.ps1.*-Report') 'Scheduled task does not run the installed reporting agent.'
    $taskXml = Export-ScheduledTask -TaskName $taskName
    Assert-True ($taskXml -match '<BootTrigger>') 'Scheduled task has no boot trigger.'
    Assert-True ($taskXml -match '<TimeTrigger>') 'Scheduled task has no periodic time trigger.'
    Assert-True ($taskXml -match '<Interval>PT5M</Interval>') 'Periodic task repetition is not every five minutes.'

    $events = @(Get-FixtureEvents $eventPath)
    $enrollments = @($events | Where-Object { $_.method -eq 'POST' -and $_.path -eq '/api/fleet/agents/enroll' })
    Assert-True ($enrollments.Count -eq 1) 'The local fixture did not receive exactly one enrollment request.'
    Assert-True ($enrollments[0].body.code -ceq $enrollmentCode) 'Enrollment request did not use the supplied disposable fixture code.'

    # Exercise an offline failed report, then recover and run the real SYSTEM task.
    Stop-FixtureServer
    $offlineProcess = Start-Process -FilePath $windowsPowerShell -ArgumentList @('-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', "`"$agentPath`"", '-Report') -WindowStyle Hidden -PassThru -Wait
    Assert-True ($offlineProcess.ExitCode -ne 0) 'Reporting unexpectedly succeeded while the HTTPS fixture was offline.'
    Assert-True ((Get-Content -LiteralPath (Join-Path $homePath 'last-report.txt') -Raw) -match 'Report failed') 'Offline reporting did not store the bounded failure status.'
    Start-FixtureServer
    $priorReports = @((Get-FixtureEvents $eventPath) | Where-Object { $_.method -eq 'PUT' -and $_.path -match '/report$' }).Count
    Start-ScheduledTask -TaskName $taskName
    $reports = Wait-ForReport -previousCount $priorReports -eventPath $eventPath
    $resumed = @($reports | Select-Object -Skip $priorReports | Select-Object -First 1)[0]
    Assert-True ($resumed.authorization -ceq "Bearer $deviceToken") 'Resumed SYSTEM report did not carry the expected bearer-token authorization.'
    Assert-True ($resumed.body.hostname -and $resumed.body.architecture -eq 'x64') 'Resumed SYSTEM report did not contain the health snapshot.'
    $accepted = $false
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        if ((Get-Content -LiteralPath (Join-Path $homePath 'last-report.txt') -Raw) -match 'Report accepted') {
            $accepted = $true
            break
        }
        Start-Sleep -Milliseconds 250
    }
    Assert-True $accepted 'Successful recovery did not store the accepted report status.'

    Remove-FleetAgent
    Assert-True (-not (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue)) 'Removal left the scheduled reporting task registered.'
    Assert-True (-not (Test-Path -LiteralPath $homePath)) 'Removal left agent credentials or state on disk.'
    Write-Host 'PASS: PowerShell AST, authorization guard, protected credential/ACL, boot and five-minute task configuration, HTTPS pairing, offline failure, SYSTEM report recovery, and removal.'
} catch {
    $failure = $_
} finally {
    try {
        Stop-FixtureServer
    } catch { $cleanupErrors += "Fixture process: $($_.Exception.Message)" }
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        try { Disable-ScheduledTask -TaskName $taskName -ErrorAction Stop | Out-Null } catch { $cleanupErrors += "Disable task: $($_.Exception.Message)" }
        try { Stop-ScheduledTask -TaskName $taskName -ErrorAction Stop } catch { }
        $stopDeadline = (Get-Date).AddSeconds(30)
        do {
            $remainingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
            if (-not $remainingTask -or $remainingTask.State -ne 'Running') { break }
            Start-Sleep -Milliseconds 250
        } while ((Get-Date) -lt $stopDeadline)
        try { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop } catch { $cleanupErrors += "Unregister task: $($_.Exception.Message)" }
    }
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        $cleanupErrors += 'Scheduled task remains registered'
    }
    if (Test-Path -LiteralPath $homePath) {
        try { Remove-Item -LiteralPath $homePath -Recurse -Force -ErrorAction Stop } catch { $cleanupErrors += "ProgramData state: $($_.Exception.Message)" }
    }
    if (Test-Path -LiteralPath $homePath) { $cleanupErrors += 'ProgramData agent state remains on disk' }
    if ($sslBindingAdded) {
        & netsh.exe http delete sslcert "ipport=0.0.0.0:$port" | Out-Null
        if ($LASTEXITCODE -ne 0) { $cleanupErrors += 'HTTP.sys certificate binding' }
    }
    if ($sslBindingV6Added) {
        & netsh.exe http delete sslcert "ipport=[::]:$port" | Out-Null
        if ($LASTEXITCODE -ne 0) { $cleanupErrors += 'IPv6 HTTP.sys certificate binding' }
    }
    if ($urlAclAdded) {
        & netsh.exe http delete urlacl "url=https://localhost:$port/" | Out-Null
        if ($LASTEXITCODE -ne 0) { $cleanupErrors += 'HTTP.sys URL reservation' }
    }
    if ($trustedCertificate) {
        try { Remove-Item -LiteralPath "Cert:\LocalMachine\Root\$($trustedCertificate.Thumbprint)" -Force -ErrorAction Stop } catch { $cleanupErrors += "Trusted certificate: $($_.Exception.Message)" }
    }
    if ($certificate) {
        try { Remove-Item -LiteralPath "Cert:\LocalMachine\My\$($certificate.Thumbprint)" -Force -ErrorAction Stop } catch { $cleanupErrors += "Certificate: $($_.Exception.Message)" }
    }
    if (Test-Path -LiteralPath $tempRoot) {
        try { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction Stop } catch { $cleanupErrors += "Temporary fixture files: $($_.Exception.Message)" }
    }
}

if ($failure) { throw $failure }
if ($cleanupErrors.Count -gt 0) { throw "Fixture cleanup failed: $($cleanupErrors -join '; ')" }