Unicode true
RequestExecutionLevel admin

!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "nsDialogs.nsh"
!include "WinVer.nsh"
!include "x64.nsh"

!ifndef SOURCE_DIR
!define SOURCE_DIR "."
!endif
!ifndef OUTPUT_EXE
!define OUTPUT_EXE "G-IT-Setup-x64.exe"
!endif

Name "G-IT"
Caption "G-IT Setup"
OutFile "${OUTPUT_EXE}"
InstallDir "$PROGRAMFILES64\FleetMonitor"
InstallDirRegKey HKLM "Software\FleetMonitor" "InstallLocation"
ShowInstDetails show
ShowUninstDetails show

!define PRODUCT_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\FleetMonitor"
!define APP_KEY "Software\FleetMonitor"

Var ConsentCheckbox
Var ConsentDialog

!insertmacro MUI_PAGE_WELCOME
Page custom ConsentPageCreate ConsentPageLeave
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TITLE "G-IT is ready"
!define MUI_FINISHPAGE_TEXT "The native G-IT setup window will open. Review its reporting notice before connecting this PC."
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

Function .onInit
    IfSilent silent_install
    ReadEnvStr $0 "USERNAME"
    StrCmp $0 "SYSTEM" system_context interactive_context

silent_install:
    MessageBox MB_ICONSTOP|MB_TOPMOST "G-IT setup requires an interactive administrator to read the disclosure and explicitly authorize installation. Silent (/S) installation is not permitted."
    Abort

system_context:
    MessageBox MB_ICONSTOP|MB_TOPMOST "G-IT's native setup window must run in an interactive administrator session, not as SYSTEM. Start this installer from the authorized user's desktop."
    Abort

interactive_context:
    ${IfNot} ${IsNativeAMD64}
        MessageBox MB_ICONSTOP|MB_TOPMOST "G-IT requires 64-bit Windows 10 or Windows 11."
        Abort
    ${EndIf}
    ${IfNot} ${AtLeastWin10}
        MessageBox MB_ICONSTOP|MB_TOPMOST "G-IT requires Windows 10 or Windows 11."
        Abort
    ${EndIf}
    SetRegView 64
FunctionEnd

Function ConsentPageCreate
    nsDialogs::Create 1018
    Pop $ConsentDialog
    ${If} $ConsentDialog == error
        Abort
    ${EndIf}

    !insertmacro MUI_HEADER_TEXT "Authorization and reporting disclosure" "Read the notice and explicitly authorize this installation to continue."
    ${NSD_CreateLabel} 0 0 100% 22u "G-IT collects and reports visible system-health information every five minutes."
    Pop $0
    ${NSD_CreateLabel} 0 28u 100% 92u "Reports: PC name, Windows version, hardware and BIOS/serial identifiers, aggregate resource usage, disk status, network-route status, and Defender status/threat names.$\r$\n$\r$\nNever collects: keystrokes, browsing, passwords, user identities, file contents, screenshots or process history. No remote commands or repairs.$\r$\n$\r$\nThe named task runs as SYSTEM at boot and every five minutes. Remove through Windows Installed apps. Pairing requires a separate authorization in the native setup window."
    Pop $0
    ${NSD_CreateCheckbox} 0 125u 100% 24u "I am authorized to manage this PC and approve this installation."
    Pop $ConsentCheckbox
    nsDialogs::Show
FunctionEnd

Function ConsentPageLeave
    ${NSD_GetState} $ConsentCheckbox $0
    ${If} $0 != ${BST_CHECKED}
        MessageBox MB_ICONEXCLAMATION|MB_OK "You must explicitly confirm authorization before installation can write files to this PC."
        Abort
    ${EndIf}
FunctionEnd

Section "Install G-IT"
    SetRegView 64
    SetShellVarContext all
    SetOutPath "$INSTDIR"
    File "${SOURCE_DIR}/FleetMonitorSetup.ps1"
    File "${SOURCE_DIR}/Agent.ps1"
    File "${SOURCE_DIR}/AgentLifecycle.ps1"
    File "${SOURCE_DIR}/Uninstall-FleetMonitor.ps1"

    WriteUninstaller "$INSTDIR\Uninstall.exe"

    ; Remove only the known legacy shortcut files on an explicitly authorized reinstall.
    Delete "$SMPROGRAMS\Fleet Monitor\Fleet Monitor Setup.lnk"
    Delete "$SMPROGRAMS\Fleet Monitor\Uninstall Fleet Monitor.lnk"
    RMDir "$SMPROGRAMS\Fleet Monitor"
    CreateDirectory "$SMPROGRAMS\G-IT"
    CreateShortCut "$SMPROGRAMS\G-IT\G-IT Setup.lnk" "$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" '-NoProfile -STA -ExecutionPolicy Bypass -File "$INSTDIR\FleetMonitorSetup.ps1"' "$INSTDIR\FleetMonitorSetup.ps1" 0 SW_SHOWNORMAL
    CreateShortCut "$SMPROGRAMS\G-IT\Uninstall G-IT.lnk" "$INSTDIR\Uninstall.exe"

    WriteRegStr HKLM "${APP_KEY}" "InstallLocation" "$INSTDIR"
    WriteRegStr HKLM "${PRODUCT_KEY}" "DisplayName" "G-IT"
    WriteRegStr HKLM "${PRODUCT_KEY}" "DisplayVersion" "1.0.0"
    WriteRegStr HKLM "${PRODUCT_KEY}" "Publisher" "G-IT"
    WriteRegStr HKLM "${PRODUCT_KEY}" "InstallLocation" "$INSTDIR"
    WriteRegStr HKLM "${PRODUCT_KEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
    WriteRegDWORD HKLM "${PRODUCT_KEY}" "NoModify" 1
    WriteRegDWORD HKLM "${PRODUCT_KEY}" "NoRepair" 1

    ${DisableX64FSRedirection}
    ExecShell "open" "$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" '-NoProfile -STA -ExecutionPolicy Bypass -File "$INSTDIR\FleetMonitorSetup.ps1"'
    ${EnableX64FSRedirection}
SectionEnd

Section "Uninstall"
    SetRegView 64
    SetShellVarContext all
    IfFileExists "$INSTDIR\Uninstall-FleetMonitor.ps1" uninstall_engine_ready uninstall_engine_missing
uninstall_engine_missing:
    MessageBox MB_ICONSTOP|MB_TOPMOST "The G-IT uninstall engine is missing. No program files, shortcuts, or uninstall registry entries were removed."
    Abort
uninstall_engine_ready:
    ${DisableX64FSRedirection}
    ClearErrors
    StrCpy $0 1
    ExecWait '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\Uninstall-FleetMonitor.ps1" -NonInteractive' $0
    ${EnableX64FSRedirection}
    IfErrors uninstall_engine_failed
    ${If} $0 != 0
uninstall_engine_failed:
        MessageBox MB_ICONSTOP|MB_TOPMOST "G-IT's uninstall engine failed (exit code $0). No program files, shortcuts, or uninstall registry entries were removed. Resolve the error and try again."
        Abort
    ${EndIf}

    Delete "$SMPROGRAMS\G-IT\G-IT Setup.lnk"
    Delete "$SMPROGRAMS\G-IT\Uninstall G-IT.lnk"
    RMDir "$SMPROGRAMS\G-IT"
    Delete "$SMPROGRAMS\Fleet Monitor\Fleet Monitor Setup.lnk"
    Delete "$SMPROGRAMS\Fleet Monitor\Uninstall Fleet Monitor.lnk"
    RMDir "$SMPROGRAMS\Fleet Monitor"
    DeleteRegKey HKLM "${PRODUCT_KEY}"
    DeleteRegKey HKLM "${APP_KEY}"
    Delete "$INSTDIR\FleetMonitorSetup.ps1"
    Delete "$INSTDIR\Agent.ps1"
    Delete "$INSTDIR\AgentLifecycle.ps1"
    Delete "$INSTDIR\Uninstall-FleetMonitor.ps1"
    Delete "$INSTDIR\Uninstall.exe"
    RMDir "$INSTDIR"
SectionEnd