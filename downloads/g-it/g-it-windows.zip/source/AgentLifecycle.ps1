<# Local installation lifecycle. Invoked only after explicit setup authorization.
   Never accepts remote commands; credentials are not passed on command lines. #>
$ErrorActionPreference = 'Stop'
$TaskName = 'Fleet Monitor - Visible System Health Reporting'
$HomePath = Join-Path $env:ProgramData 'FleetMonitor'

function Assert-FleetAdministrator {
    if (-not [Environment]::Is64BitOperatingSystem -or $env:PROCESSOR_ARCHITECTURE -ne 'AMD64' -or [Environment]::OSVersion.Version.Major -lt 10) {
        throw 'G-IT requires Windows 10/11 on an x64 PC and 64-bit Windows PowerShell.'
    }
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Administrator permission is required.'
    }
}

function Remove-FleetAgent {
    Assert-FleetAdministrator
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($task) {
        # Disable first, then wait for the reporting process to stop before deleting credentials.
        Disable-ScheduledTask -TaskName $TaskName | Out-Null
        Stop-ScheduledTask -TaskName $TaskName
        $deadline = (Get-Date).AddSeconds(30)
        do {
            $task = Get-ScheduledTask -TaskName $TaskName
            if ($task.State -ne 'Running') { break }
            Start-Sleep -Milliseconds 250
        } while ((Get-Date) -lt $deadline)
        if ($task.State -eq 'Running') { throw 'The reporting task did not stop. Retry removal.' }
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    }
    if (Test-Path -LiteralPath $HomePath) {
        Remove-Item -LiteralPath $HomePath -Recurse -Force
    }
}

function Install-FleetAgent {
    param(
        [Parameter(Mandatory=$true)][string]$ServerUrl,
        [Parameter(Mandatory=$true)][string]$EnrollmentCode,
        [Parameter(Mandatory=$true)][string]$AgentSource,
        [Parameter(Mandatory=$true)][bool]$Authorized
    )
    Assert-FleetAdministrator
    if (-not $Authorized) { throw 'Explicit authorization is required before pairing and reporting.' }
    if (Test-Path -LiteralPath $HomePath) {
        throw 'An agent or incomplete installation already exists. Remove it before pairing again.'
    }
    if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
        throw 'A reporting task already exists. Remove the old installation before pairing again.'
    }
    $uri = $null
    $ServerUrl = $ServerUrl.Trim().TrimEnd('/')
    if (-not [Uri]::TryCreate($ServerUrl, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') {
        throw 'Enter an HTTPS root URL without credentials, query strings or paths.'
    }
    if ($EnrollmentCode -notmatch '^[A-Za-z0-9_-]{43}$') { throw 'Invalid one-time enrollment code.' }
    Add-Type -AssemblyName System.Security
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $bytes = $null
    $enrollment = $null
    $body = $null
    $created = $false
    try {
        # Secure storage before consuming a one-time code; do not adopt an existing directory.
        New-Item -Path $HomePath -ItemType Directory -ErrorAction Stop | Out-Null
        $created = $true
        & icacls.exe $HomePath /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'Could not restrict the agent folder to SYSTEM and administrators.' }
        Copy-Item -LiteralPath $AgentSource -Destination (Join-Path $HomePath 'Agent.ps1')
        $snapshot = Get-FleetHealthSnapshot
        $body = @{ code = $EnrollmentCode; report = $snapshot } | ConvertTo-Json -Depth 6 -Compress
        $enrollment = Invoke-RestMethod -Uri "$ServerUrl/api/fleet/agents/enroll" -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 60
        $id = [Guid]::Empty
        if (-not [Guid]::TryParse([string]$enrollment.device.id, [ref]$id) -or [string]$enrollment.deviceToken -notmatch '^[A-Za-z0-9_-]{43}$') {
            throw 'The server did not return a valid device ID and credential.'
        }
        $bytes = [Text.Encoding]::UTF8.GetBytes([string]$enrollment.deviceToken)
        $encrypted = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
        @{
            serverUrl = $ServerUrl
            deviceId = $id.ToString()
            protectedToken = [Convert]::ToBase64String($encrypted)
        } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $HomePath 'agent.json') -Encoding UTF8
        $agentFile = Join-Path $HomePath 'Agent.ps1'
        # The named task is visible in Task Scheduler; no hidden task or hidden process flags.
        $arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$agentFile`" -Report"
        $action = New-ScheduledTaskAction -Execute "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $arguments
        $startup = New-ScheduledTaskTrigger -AtStartup
        $periodic = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
        $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 4) -MultipleInstances IgnoreNew
        $taskPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($startup, $periodic) -Settings $settings -Principal $taskPrincipal -Description 'G-IT user-authorized hardware and health reporting at boot and every 5 minutes. No activity collection or remote commands. Remove through G-IT or Windows Installed apps.' | Out-Null
        Set-Content -LiteralPath (Join-Path $HomePath 'last-report.txt') -Value "$(Get-Date -Format o) Enrollment snapshot accepted. Scheduled reporting enabled."
    } catch {
        if ($created) {
            try { Remove-FleetAgent } catch {
                throw 'Setup failed and cleanup could not finish. Use Uninstall this agent before trying again. The server record may remain offline.'
            }
        }
        # Never expose server response bodies or tokens in a GUI or log.
        throw 'Setup did not complete and local changes were removed. Check connectivity, storage permissions and the server URL. Use a new code if pairing consumed the old one; a server inventory record may remain.'
    } finally {
        if ($null -ne $bytes) { [Array]::Clear($bytes, 0, $bytes.Length) }
        $enrollment = $null
        $EnrollmentCode = $null
        $body = $null
    }
}