<# Called by the visible Windows uninstaller. No network request is made. #>
param([switch]$NonInteractive)
$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $PSScriptRoot 'AgentLifecycle.ps1')
    if (-not $NonInteractive) {
        Add-Type -AssemblyName System.Windows.Forms
        $result = [Windows.Forms.MessageBox]::Show('Stop reporting and remove the local task and device credential? The server record will remain offline.', 'Remove G-IT', [Windows.Forms.MessageBoxButtons]::YesNo)
        if ($result -ne [Windows.Forms.DialogResult]::Yes) { exit 1 }
    }
    Remove-FleetAgent
    exit 0
} catch {
    # Do not log exceptions that could contain credential material.
    Write-Error 'G-IT could not be removed. Run removal as an administrator and retry.'
    exit 1
}