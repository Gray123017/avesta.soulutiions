<# G-IT setup wizard. Windows 10/11 x64, built-in Windows PowerShell 5.1.
   An administrator must explicitly authorize installation. #>
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitOperatingSystem) {
    Write-Error 'This installer requires 64-bit Windows 10 or 11.'
    exit 1
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"") -Verb RunAs
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Security
[Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

. (Join-Path $PSScriptRoot 'AgentLifecycle.ps1')
Assert-FleetAdministrator
$AgentSource = Join-Path $PSScriptRoot 'Agent.ps1'
. $AgentSource

$form = New-Object Windows.Forms.Form
$form.Text = 'G-IT | Windows setup'
$form.Size = New-Object Drawing.Size(660, 680)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('Segoe UI', 10)
$form.BackColor = [Drawing.Color]::FromArgb(244, 247, 251)

function New-Label([string]$text, [int]$top, [int]$height) {
    $label = New-Object Windows.Forms.Label
    $label.Text = $text
    $label.Location = New-Object Drawing.Point(30, $top)
    $label.Size = New-Object Drawing.Size(580, $height)
    $form.Controls.Add($label)
    return $label
}

$title = New-Label 'G-IT' 24 42
$title.Font = New-Object Drawing.Font('Segoe UI', 24, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(16, 48, 70)
$null = New-Label 'Connect this PC to your authorized fleet dashboard.' 78 32
$privacy = New-Label "Transparent system health reporting`r`nReports: PC specifications, BIOS/serial number, resource usage, disk status, network-route status, and Windows Defender status/threat names.`r`nNever collects: keystrokes, browsing history, passwords, file contents, user identities, or process history. No remote commands or repairs are executed." 120 135
$privacy.ForeColor = [Drawing.Color]::FromArgb(35, 59, 75)
$null = New-Label 'Server URL (HTTPS, for example https://your-server.example)' 272 25
$serverBox = New-Object Windows.Forms.TextBox
$serverBox.Location = New-Object Drawing.Point(30, 302)
$serverBox.Size = New-Object Drawing.Size(580, 30)
$form.Controls.Add($serverBox)
$null = New-Label 'One-time enrollment code from your dashboard' 346 25
$codeBox = New-Object Windows.Forms.TextBox
$codeBox.Location = New-Object Drawing.Point(30, 376)
$codeBox.Size = New-Object Drawing.Size(580, 30)
$codeBox.UseSystemPasswordChar = $true
$form.Controls.Add($codeBox)

$consent = New-Object Windows.Forms.CheckBox
$consent.Text = 'I am authorized to manage this PC and approve visible reporting every 5 minutes.'
$consent.Location = New-Object Drawing.Point(30, 425)
$consent.Size = New-Object Drawing.Size(580, 42)
$form.Controls.Add($consent)

$install = New-Object Windows.Forms.Button
$install.Text = 'Install and connect'
$install.Location = New-Object Drawing.Point(30, 492)
$install.Size = New-Object Drawing.Size(280, 44)
$install.BackColor = [Drawing.Color]::FromArgb(13, 101, 113)
$install.ForeColor = [Drawing.Color]::White
$install.FlatStyle = 'Flat'
$form.Controls.Add($install)
$remove = New-Object Windows.Forms.Button
$remove.Text = 'Uninstall this agent'
$remove.Location = New-Object Drawing.Point(330, 492)
$remove.Size = New-Object Drawing.Size(280, 44)
$form.Controls.Add($remove)
$status = New-Label 'Requires an administrator. View upload status in C:\ProgramData\FleetMonitor\last-report.txt.' 555 70
$status.ForeColor = [Drawing.Color]::FromArgb(50, 75, 95)
if (Test-Path -LiteralPath (Join-Path $HomePath 'agent.json')) {
    $status.Text = 'An agent is installed. Windows Task Scheduler shows the reporting task. Uninstall before pairing this PC with a different account.'
}

$install.Add_Click({
    if (-not $consent.Checked) {
        [Windows.Forms.MessageBox]::Show('Confirm that you are authorized to manage this PC and approve reporting.', 'Authorization required') | Out-Null
        return
    }
    if (Test-Path -LiteralPath (Join-Path $HomePath 'agent.json')) {
        [Windows.Forms.MessageBox]::Show('An agent is already installed. Uninstall it before enrolling again.', 'Already installed') | Out-Null
        return
    }
    $uri = $null
    $rawUrl = $serverBox.Text.Trim().TrimEnd('/')
    if (-not [Uri]::TryCreate($rawUrl, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne '/') {
        [Windows.Forms.MessageBox]::Show('Enter the HTTPS root URL of your server, without /api or other paths.', 'Invalid server URL') | Out-Null
        return
    }
    if ($codeBox.Text.Trim() -notmatch '^[A-Za-z0-9_-]{43}$') {
        [Windows.Forms.MessageBox]::Show('Paste a valid one-time enrollment code from your dashboard.', 'Invalid code') | Out-Null
        return
    }
    $install.Enabled = $false
    $status.Text = 'Checking this PC and connecting securely...'
    $form.Refresh()
    try {
        Install-FleetAgent -ServerUrl $rawUrl -EnrollmentCode $codeBox.Text.Trim() -AgentSource $AgentSource -Authorized $consent.Checked
        $codeBox.Clear()
        $enrollment = $null
        $status.Text = 'Connected. Reporting runs at boot and every 5 minutes. View the named task in Task Scheduler and upload status in C:\ProgramData\FleetMonitor\last-report.txt. Remove through Windows Installed apps.'
        [Windows.Forms.MessageBox]::Show('This PC is connected. Refresh the dashboard to see its first health snapshot.', 'G-IT installed') | Out-Null
    } catch {
        $status.Text = 'Installation did not complete. Check your server URL and use a new enrollment code if the old one was consumed.'
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Setup failed') | Out-Null
    } finally { $install.Enabled = $true }
})

$remove.Add_Click({
    $result = [Windows.Forms.MessageBox]::Show('Stop reporting and remove the local G-IT task, files, and device credential? The server inventory record will remain and become offline.', 'Uninstall G-IT', [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Question)
    if ($result -ne [Windows.Forms.DialogResult]::Yes) { return }
    try {
        Remove-FleetAgent
        $status.Text = 'Reporting and credentials removed. Use Windows Installed apps to also remove the setup program.'
    } catch {
        [Windows.Forms.MessageBox]::Show("Uninstall failed: $($_.Exception.Message)", 'Uninstall failed') | Out-Null
    }
})

$form.AcceptButton = $install
[Windows.Forms.Application]::Run($form)