#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
OUTPUT_DIR="$REPO_ROOT/artifacts/fleet-monitor/public/downloads"
EXE_NAME="G-IT-Setup-x64.exe"
ZIP_NAME="g-it-windows.zip"
LEGACY_EXE_NAME="FleetMonitorSetup-x64.exe"
LEGACY_ZIP_NAME="fleet-monitor-windows.zip"
EXE_OUT="$OUTPUT_DIR/$EXE_NAME"
ZIP_OUT="$OUTPUT_DIR/$ZIP_NAME"

if ! command -v makensis >/dev/null 2>&1; then
    echo "makensis is required to build the Windows installer (install NSIS and retry)." >&2
    exit 127
fi
if ! command -v zip >/dev/null 2>&1; then
    echo "zip is required to create the source package." >&2
    exit 127
fi
if ! command -v sha256sum >/dev/null 2>&1; then
    echo "sha256sum is required to create the installer checksum." >&2
    exit 127
fi

mkdir -p "$OUTPUT_DIR"
makensis "-DSOURCE_DIR=$SCRIPT_DIR" "-DOUTPUT_EXE=$EXE_OUT" "$SCRIPT_DIR/installer.nsi"
test -s "$EXE_OUT"

STAGE_DIR="$(mktemp -d)"
trap 'rm -rf "$STAGE_DIR"' EXIT
mkdir -p "$STAGE_DIR/source"
cp "$EXE_OUT" "$STAGE_DIR/$EXE_NAME"
cp "$SCRIPT_DIR/README.txt" "$STAGE_DIR/README.txt"
cp "$SCRIPT_DIR/Run-WindowsChecks.cmd" "$STAGE_DIR/Run-WindowsChecks.cmd"
cp "$SCRIPT_DIR/BUILD-AND-TEST.txt" "$STAGE_DIR/BUILD-AND-TEST.txt"
cp "$SCRIPT_DIR/BUILD-AND-TEST.txt" "$STAGE_DIR/source/BUILD-AND-TEST.txt"
cp "$SCRIPT_DIR/Agent.ps1" \
   "$SCRIPT_DIR/AgentLifecycle.ps1" \
   "$SCRIPT_DIR/FleetMonitorSetup.ps1" \
   "$SCRIPT_DIR/Uninstall-FleetMonitor.ps1" \
   "$SCRIPT_DIR/installer.nsi" \
   "$SCRIPT_DIR/build-installer.sh" \
   "$STAGE_DIR/source/"

(cd "$STAGE_DIR" && sha256sum "$EXE_NAME" > SHA256SUMS.txt)
cp "$STAGE_DIR/SHA256SUMS.txt" "$OUTPUT_DIR/SHA256SUMS.txt"
if [[ -d "$SCRIPT_DIR/tests" ]]; then cp -R "$SCRIPT_DIR/tests" "$STAGE_DIR/source/tests"; fi

rm -f "$ZIP_OUT"
(cd "$STAGE_DIR" && zip -qr "$ZIP_OUT" "$EXE_NAME" README.txt Run-WindowsChecks.cmd BUILD-AND-TEST.txt SHA256SUMS.txt source)
cp "$EXE_OUT" "$OUTPUT_DIR/$LEGACY_EXE_NAME"
cp "$ZIP_OUT" "$OUTPUT_DIR/$LEGACY_ZIP_NAME"
echo "Built $EXE_OUT (also refreshed $OUTPUT_DIR/$LEGACY_EXE_NAME)"
echo "Packaged $ZIP_OUT (also refreshed $OUTPUT_DIR/$LEGACY_ZIP_NAME)"