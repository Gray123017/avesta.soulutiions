<# G-IT: explicitly installed, read-only system health reporting.
   No keystrokes, browsing history, user identities, file contents, or process history. #>
param([switch]$Report)
$ErrorActionPreference = 'Stop'
$HomePath = Join-Path $env:ProgramData 'FleetMonitor'
$ConfigPath = Join-Path $HomePath 'agent.json'

function Get-FleetHealthSnapshot {
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw 'G-IT requires a 64-bit Windows operating system.'
    }
    $computer = Get-CimInstance Win32_ComputerSystem
    $os = Get-CimInstance Win32_OperatingSystem
    $bios = Get-CimInstance Win32_BIOS
    $processors = @(Get-CimInstance Win32_Processor)
    $memoryMb = [int][math]::Round([double]$computer.TotalPhysicalMemory / 1MB)
    $memoryUsed = [math]::Round(100 * (1 - ([double]$os.FreePhysicalMemory * 1KB / [double]$computer.TotalPhysicalMemory)), 1)
    $cpu = $null
    $cpuValues = @($processors | Where-Object { $null -ne $_.LoadPercentage })
    if ($cpuValues.Count -gt 0) {
        $cpu = [math]::Round(($cpuValues | Measure-Object -Property LoadPercentage -Average).Average, 1)
    }
    $freePercent = $null
    $diskStatus = 'unknown'
    try {
        $volume = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($os.SystemDrive)'"
        if ($volume -and $volume.Size -gt 0) {
            $freePercent = [math]::Round(100 * [double]$volume.FreeSpace / [double]$volume.Size, 1)
        }
        $physicalDisks = @(Get-PhysicalDisk -ErrorAction Stop)
        if ($physicalDisks.Count -gt 0) {
            if (@($physicalDisks | Where-Object { $_.HealthStatus -in @('Unhealthy', 'Warning') }).Count -gt 0) {
                $diskStatus = 'attention'
            } elseif (@($physicalDisks | Where-Object { $_.HealthStatus -ne 'Healthy' }).Count -eq 0) {
                $diskStatus = 'healthy'
            }
        }
        if ($null -ne $freePercent -and $freePercent -lt 10) { $diskStatus = 'attention' }
    } catch { $diskStatus = 'unknown' }

    $defenderStatus = 'unknown'
    $malwareNames = @()
    $malwareFindings = 0
    try {
        $defender = Get-MpComputerStatus -ErrorAction Stop
        if ($defender.AMServiceEnabled -and $defender.AntivirusEnabled -and $defender.RealTimeProtectionEnabled -and -not $defender.DefenderSignaturesOutOfDate) {
            $defenderStatus = 'healthy'
        } else { $defenderStatus = 'attention' }
        $activeThreats = @(Get-MpThreat -ErrorAction Stop | Where-Object { $_.IsActive })
        $malwareFindings = [math]::Min($activeThreats.Count, 10000)
        $malwareNames = @($activeThreats | Select-Object -First 100 | ForEach-Object { [string]$_.ThreatName })
    } catch { $defenderStatus = 'unknown' }

    $networkStatus = 'unknown'
    try {
        $routes = @(Get-NetRoute -ErrorAction Stop | Where-Object { $_.DestinationPrefix -in @('0.0.0.0/0', '::/0') })
        if ($routes.Count -gt 0) { $networkStatus = 'healthy' } else { $networkStatus = 'degraded' }
    } catch { $networkStatus = 'unknown' }

    return @{
        hostname = [string]$env:COMPUTERNAME
        osName = [string]$os.Caption
        osVersion = [string]$os.Version
        architecture = 'x64'
        manufacturer = [string]$computer.Manufacturer
        model = [string]$computer.Model
        serialNumber = [string]$bios.SerialNumber
        biosVersion = [string]$bios.SMBIOSBIOSVersion
        processor = [string](($processors | Select-Object -ExpandProperty Name) -join ', ')
        memoryTotalMb = [math]::Max(1, $memoryMb)
        diskFreePercent = $freePercent
        cpuUsagePercent = $cpu
        memoryUsagePercent = [math]::Max(0, [math]::Min(100, $memoryUsed))
        defenderStatus = $defenderStatus
        networkStatus = $networkStatus
        diskStatus = $diskStatus
        malwareFindings = $malwareFindings
        malwareNames = @($malwareNames)
    }
}

function Send-FleetHealthSnapshot {
    Add-Type -AssemblyName System.Security
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
    $encrypted = [Convert]::FromBase64String($config.protectedToken)
    $plain = [Security.Cryptography.ProtectedData]::Unprotect($encrypted, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
    $token = [Text.Encoding]::UTF8.GetString($plain)
    try {
        $uri = "$($config.serverUrl)/api/fleet/agents/$($config.deviceId)/report"
        $body = Get-FleetHealthSnapshot | ConvertTo-Json -Depth 5 -Compress
        Invoke-RestMethod -Uri $uri -Method Put -Headers @{ Authorization = "Bearer $token" } -ContentType 'application/json' -Body $body -TimeoutSec 60 | Out-Null
        Set-Content -LiteralPath (Join-Path $HomePath 'last-report.txt') -Value "$(Get-Date -Format o) Report accepted."
    } finally {
        [Array]::Clear($plain, 0, $plain.Length)
        $token = $null
    }
}

if ($Report) {
    try {
        Send-FleetHealthSnapshot
        exit 0
    } catch {
        # Keep only a bounded local status message. Credentials and payloads are never logged.
        if (Test-Path -LiteralPath $HomePath) {
            Set-Content -LiteralPath (Join-Path $HomePath 'last-report.txt') -Value "$(Get-Date -Format o) Report failed. Check server availability and enrollment."
        }
        exit 1
    }
}